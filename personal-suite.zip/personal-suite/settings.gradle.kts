pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "personal-suite"

include(":app", ":core")
include(":feature:files", ":feature:gallery", ":feature:music")
include(":feature:player", ":feature:documents", ":feature:terminal")
