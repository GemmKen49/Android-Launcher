package com.personal.suite.launcher

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent

fun Context.holdsHomeRole(): Boolean =
    getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_HOME)

/** Intent for the system "make this your home app" dialog, or null if the role can't be requested. */
fun Context.homeRoleIntent(): Intent? {
    val roleManager = getSystemService(RoleManager::class.java)
    return if (roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
        roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME)
    } else {
        null
    }
}
