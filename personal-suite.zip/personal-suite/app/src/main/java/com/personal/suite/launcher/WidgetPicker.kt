package com.personal.suite.launcher

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.pm.PackageManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private data class WidgetEntry(val info: AppWidgetProviderInfo, val label: String, val app: String)

/** Every home-screen widget installed on the device, by name. */
@Composable
internal fun WidgetPickerDialog(onPick: (AppWidgetProviderInfo) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val entries = remember {
        val pm = context.packageManager
        AppWidgetManager.getInstance(context).installedProviders
            .filter { (it.widgetCategory and AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN) != 0 }
            .map { WidgetEntry(it, it.loadLabel(pm).toString(), appLabel(pm, it.provider.packageName)) }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add widget") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(entries, key = { it.info.provider.flattenToString() }) { entry ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(entry.info) }
                            .padding(vertical = 8.dp),
                    ) {
                        Text(entry.label)
                        Text(entry.app, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

private fun appLabel(pm: PackageManager, packageName: String): String =
    try {
        pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        packageName
    }
