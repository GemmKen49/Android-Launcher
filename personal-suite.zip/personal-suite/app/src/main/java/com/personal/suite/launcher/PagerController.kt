package com.personal.suite.launcher

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.util.addPointerInputChange
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

private const val FLING_VELOCITY = 800f // px/s

/**
 * Horizontal position of the launcher's three pages: -1 = screen time, 0 = home, 1 = app drawer.
 * It follows the finger, so a page can be held half way or dragged back; on release it settles on
 * a page depending on position and fling speed.
 */
class PagerController(private val scope: CoroutineScope) {

    var position by mutableFloatStateOf(0f)
        private set

    private var job: Job? = null

    fun dragBy(fraction: Float) {
        job?.cancel()
        position = (position + fraction).coerceIn(-1f, 1f)
    }

    fun release(velocityX: Float) {
        settle(
            when {
                velocityX < -FLING_VELOCITY -> floor(position).toInt() + 1
                velocityX > FLING_VELOCITY -> ceil(position).toInt() - 1
                else -> position.roundToInt()
            }
        )
    }

    /** Animates to [page]: -1, 0 or 1. */
    fun settle(page: Int) {
        val target = page.coerceIn(-1, 1).toFloat()
        job?.cancel()
        job = scope.launch {
            animate(position, target, animationSpec = tween(200)) { value, _ -> position = value }
        }
    }
}

/**
 * Horizontal swipe that drives [controller] (swipe left moves toward the drawer, right toward screen time).
 * Ignores gestures a child already consumed (e.g. a vertical list scroll).
 */
fun Modifier.pageSwipe(controller: PagerController): Modifier = pointerInput(controller) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        val tracker = VelocityTracker()
        tracker.addPointerInputChange(down)
        val slop = viewConfiguration.touchSlop
        var totalX = 0f
        var totalY = 0f
        var dragging = false

        while (true) {
            val event = awaitPointerEvent()
            val change = event.changes.firstOrNull { it.id == down.id } ?: break
            if (change.isConsumed || !change.pressed) break
            tracker.addPointerInputChange(change)
            val delta = change.positionChange()

            if (!dragging) {
                totalX += delta.x
                totalY += delta.y
                if (abs(totalX) > slop && abs(totalX) > abs(totalY)) {
                    dragging = true
                } else if (abs(totalY) > slop) {
                    break // vertical gesture: not ours
                }
            }
            if (dragging) {
                change.consume()
                controller.dragBy(-delta.x / size.width)
            }
        }

        if (dragging) controller.release(tracker.calculateVelocity().x)
    }
}
