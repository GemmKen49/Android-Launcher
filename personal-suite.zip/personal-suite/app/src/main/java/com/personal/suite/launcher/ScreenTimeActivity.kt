package com.personal.suite.launcher

import android.os.Bundle
import android.text.format.DateFormat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.personal.suite.core.apps.AppCatalog
import com.personal.suite.core.apps.AppIcon
import com.personal.suite.core.design.SuiteTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Date

/** Every app used today with its total time and the time of each session. Refreshes only while on screen. */
class ScreenTimeActivity : ComponentActivity() {

    private var isActive by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { SuiteTheme { ScreenTimeScreen(active = isActive) } }
    }

    override fun onResume() {
        super.onResume()
        isActive = true
    }

    override fun onPause() {
        isActive = false
        super.onPause()
    }
}

@Composable
private fun ScreenTimeScreen(active: Boolean) {
    val context = LocalContext.current
    val catalogItems by remember { AppCatalog.get(context).items }.collectAsState()
    var summary by remember { mutableStateOf(UsageCache.last) }
    var granted by remember { mutableStateOf(hasUsageAccess(context)) }

    LaunchedEffect(active, catalogItems) {
        if (!active) return@LaunchedEffect
        while (true) {
            granted = hasUsageAccess(context)
            if (granted) {
                val fresh = withContext(Dispatchers.IO) { computeUsage(context) }
                UsageCache.last = fresh
                summary = fresh
            }
            delay(10_000)
        }
    }

    val data = summary
    val timeFormat = remember { DateFormat.getTimeFormat(context) }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Column {
                    Text("Screen Time", style = MaterialTheme.typography.headlineMedium)
                    val dayText = data?.let { DateFormat.getLongDateFormat(context).format(Date(it.dayStart)) }
                    Text(
                        text = listOfNotNull("Today", dayText, data?.let { formatDuration(it.totalMs) }).joinToString(" · "),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        text = "Resets at 00:00. Updates only while this screen is open.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (!granted) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Allow usage access to see how long you use each app. It stays on this device.")
                        Button(onClick = { context.openUsageAccessSettings() }) { Text("Grant usage access") }
                    }
                }
            } else if (data == null || data.apps.isEmpty()) {
                item { Text("No usage recorded yet today.") }
            } else {
                items(data.apps, key = { it.key }) { app ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(app.item, size = 36.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = app.label,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                            Text(formatDuration(app.total), style = MaterialTheme.typography.titleMedium)
                        }
                        app.sessions.forEach { session ->
                            Text(
                                text = "${timeFormat.format(Date(session.start))} – ${timeFormat.format(Date(session.end))}" +
                                    "  ·  ${formatDuration(session.duration)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}
