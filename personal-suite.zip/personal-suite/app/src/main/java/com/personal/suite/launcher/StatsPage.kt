package com.personal.suite.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.personal.suite.core.apps.AppCatalog
import com.personal.suite.core.apps.AppIcon
import com.personal.suite.core.apps.LauncherItem
import com.personal.suite.core.prefs.LocalAppearance
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

private const val TOP_APPS = 10
private const val REFRESH_MS = 5_000L

data class PieSlice(val value: Long, val color: Color)

/** Flat 2D pie chart; slices start at 12 o'clock and run clockwise. */
@Composable
fun PieChart(slices: List<PieSlice>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val total = slices.sumOf { it.value }.toFloat()
        if (total <= 0f) return@Canvas
        val diameter = minOf(size.width, size.height)
        val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
        var start = -90f
        slices.forEach { slice ->
            val sweep = 360f * slice.value / total
            drawArc(
                color = slice.color,
                startAngle = start,
                sweepAngle = sweep,
                useCenter = true,
                topLeft = topLeft,
                size = Size(diameter, diameter),
            )
            start += sweep
        }
    }
}

/**
 * The page left of home: today's screen time, a pie chart and the ten most-used apps.
 * It only refreshes while it is on screen and the launcher is in the foreground ([displayed]);
 * the page is not even composed otherwise, so nothing updates in the background.
 */
@Composable
fun StatsPage(displayed: Boolean, pager: PagerController, onShowMore: () -> Unit) {
    val context = LocalContext.current
    val appearance = LocalAppearance.current
    val catalogItems by remember { AppCatalog.get(context).items }.collectAsState()
    var summary by remember { mutableStateOf(UsageCache.last) }
    var granted by remember { mutableStateOf(hasUsageAccess(context)) }

    LaunchedEffect(displayed, catalogItems) {
        if (!displayed) return@LaunchedEffect
        while (true) {
            granted = hasUsageAccess(context)
            if (granted) {
                val fresh = withContext(Dispatchers.IO) { computeUsage(context) }
                UsageCache.last = fresh
                summary = fresh
            }
            delay(REFRESH_MS)
        }
    }

    val data = summary
    val top = data?.apps.orEmpty().take(TOP_APPS)
    val others = data?.apps.orEmpty().drop(TOP_APPS).sumOf { it.total }
    val total = data?.totalMs ?: 0L

    val fallbacks = listOf(
        MaterialTheme.colorScheme.primary,
        MaterialTheme.colorScheme.tertiary,
        MaterialTheme.colorScheme.secondary,
        MaterialTheme.colorScheme.inversePrimary,
    )
    val palette by produceState(emptyMap<String, Color>(), top.map { it.key }) {
        value = withContext(Dispatchers.IO) {
            val dominant = top.associate { it.key to dominantColor(context, it.item) }
            buildPalette(dominant, top.map { it.key }, fallbacks)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = appearance.drawerScrim))
            .pageSwipe(pager),
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Column {
                    Text("Screen time", color = Color.White, style = MaterialTheme.typography.headlineSmall)
                    Text(
                        text = if (granted) "Today · ${formatDuration(total)}" else "Today",
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }

            if (!granted) {
                item {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(appearance.cardCornerRadius.dp))
                            .background(cardColor())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            "Allow usage access to see how long you use each app. It stays on this device.",
                            color = Color.White,
                        )
                        Button(onClick = { context.openUsageAccessSettings() }) { Text("Grant usage access") }
                    }
                }
            } else if (top.isEmpty()) {
                item { Text("No usage recorded yet today.", color = Color.White.copy(alpha = 0.7f)) }
            } else {
                item {
                    val slices = top.map { PieSlice(it.total, palette[it.key] ?: Color.Gray) } +
                        if (others > 0) listOf(PieSlice(others, Color(0xFF8A8F98))) else emptyList()
                    Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                        PieChart(slices, Modifier.size(200.dp))
                    }
                }
                items(top, key = { it.key }) { app ->
                    UsageRow(app, palette[app.key] ?: Color.Gray, total)
                }
                if (others > 0) {
                    item {
                        Text(
                            text = "Other apps · ${formatDuration(others)}",
                            color = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.padding(start = 4.dp),
                        )
                    }
                }
                item {
                    TextButton(
                        onClick = onShowMore,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White),
                    ) { Text("Show more") }
                }
            }
        }
    }
}

@Composable
private fun UsageRow(app: AppUsage, color: Color, total: Long) {
    val appearance = LocalAppearance.current
    val percent = if (total > 0) (app.total * 100f / total).roundToInt() else 0
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(appearance.cardCornerRadius.dp))
            .background(cardColor())
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(10.dp))
        AppIcon(app.item, size = 32.dp)
        Spacer(Modifier.width(10.dp))
        Text(
            text = app.label,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Text(formatDuration(app.total), color = Color.White)
        Text("  $percent%", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall)
    }
}

/** Average colour of an app icon's saturated pixels, or null for grey / monochrome icons. */
internal fun dominantColor(context: Context, item: LauncherItem): Color? {
    val drawable: Drawable = when (item) {
        is LauncherItem.Installed -> runCatching { context.packageManager.getActivityIcon(item.component) }.getOrNull()
        is LauncherItem.Internal -> context.getDrawable(item.entry.iconRes)
    } ?: return null

    val size = 24
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    drawable.setBounds(0, 0, size, size)
    drawable.draw(AndroidCanvas(bitmap))
    val pixels = IntArray(size * size)
    bitmap.getPixels(pixels, 0, size, 0, 0, size, size)

    val hsv = FloatArray(3)
    var r = 0.0
    var g = 0.0
    var b = 0.0
    var weight = 0.0
    for (pixel in pixels) {
        if (android.graphics.Color.alpha(pixel) < 200) continue
        android.graphics.Color.colorToHSV(pixel, hsv)
        val w = (hsv[1] * hsv[2]).toDouble()
        r += android.graphics.Color.red(pixel) * w
        g += android.graphics.Color.green(pixel) * w
        b += android.graphics.Color.blue(pixel) * w
        weight += w
    }
    if (weight < 15.0) return null
    return Color((r / weight).toInt(), (g / weight).toInt(), (b / weight).toInt())
}

/**
 * One colour per app: its icon colour, made bright enough for a dark background, with near-identical
 * hues nudged apart. Apps with grey icons take colours from the current theme.
 */
internal fun buildPalette(dominant: Map<String, Color?>, order: List<String>, fallbacks: List<Color>): Map<String, Color> {
    val usedHues = mutableListOf<Float>()
    var fallbackIndex = 0
    val result = LinkedHashMap<String, Color>()
    for (key in order) {
        val base = dominant[key] ?: fallbacks[fallbackIndex++ % fallbacks.size]
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(base.toArgb(), hsv)
        hsv[1] = hsv[1].coerceAtLeast(0.45f)
        hsv[2] = hsv[2].coerceIn(0.6f, 0.95f)
        var tries = 0
        while (usedHues.any { hueDistance(it, hsv[0]) < 16f } && tries < 12) {
            hsv[0] = (hsv[0] + 22f) % 360f
            tries++
        }
        usedHues += hsv[0]
        result[key] = Color(android.graphics.Color.HSVToColor(hsv))
    }
    return result
}

private fun hueDistance(a: Float, b: Float): Float {
    val d = abs(a - b) % 360f
    return if (d > 180f) 360f - d else d
}
