package com.personal.suite.launcher

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.personal.suite.core.apps.AppCatalog
import com.personal.suite.core.apps.LauncherItem
import com.personal.suite.core.apps.openAppInfo
import com.personal.suite.core.prefs.SuitePrefs
import com.personal.suite.core.registry.AppRegistry
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private const val HOME_ROWS = 5

private data class PinnedState(val keys: List<String>?)

@Composable
fun LauncherScreen(
    drawerOpen: Boolean,
    onDrawerOpenChange: (Boolean) -> Unit,
    isDefaultHome: Boolean,
    onRequestDefault: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { SuitePrefs.get(context) }
    val catalog = remember { AppCatalog.get(context) }

    val items by catalog.items.collectAsState()
    val hidden by prefs.hiddenApps.collectAsState(initial = emptySet())
    val columns by prefs.gridColumns.collectAsState(initial = SuitePrefs.DEFAULT_COLUMNS)
    val pinnedState by remember { prefs.pinnedKeys.map { PinnedState(it) } }.collectAsState(initial = null)

    // Until the user customizes the home screen, the built-in apps are pinned.
    val pinnedKeys: List<String>? = pinnedState?.let { state ->
        state.keys ?: AppRegistry.entries.map { "internal:${it.id}" }
    }
    val byKey = remember(items) { items.associateBy { it.key } }
    val maxPins = columns * HOME_ROWS
    val pinned = pinnedKeys.orEmpty().mapNotNull { byKey[it] }.take(maxPins)
    val drawerItems = remember(items, hidden) { items.filter { it.key !in hidden } }

    fun togglePin(item: LauncherItem) {
        val keys = pinnedKeys ?: return
        when {
            item.key in keys -> scope.launch { prefs.setPinned(keys - item.key) }
            keys.size >= maxPins -> Toast.makeText(context, "Home screen is full", Toast.LENGTH_SHORT).show()
            else -> scope.launch { prefs.setPinned(keys + item.key) }
        }
    }

    fun actionsFor(item: LauncherItem, showHide: Boolean): List<CellAction> = buildList {
        val isPinned = item.key in pinnedKeys.orEmpty()
        add(CellAction(if (isPinned) "Unpin from home" else "Pin to home") { togglePin(item) })
        if (showHide) add(CellAction("Hide from drawer") { scope.launch { prefs.setHidden(item.key, true) } })
        if (item is LauncherItem.Installed) add(CellAction("App info") { context.openAppInfo(item) })
    }

    val currentOnDrawerChange by rememberUpdatedState(onDrawerOpenChange)
    val currentOnSettings by rememberUpdatedState(onOpenSettings)

    // A launcher is the root of the back stack: back only closes the drawer.
    BackHandler { if (drawerOpen) onDrawerOpenChange(false) }

    Box(Modifier.fillMaxSize()) {
        // Home layer: wallpaper shows through the transparent window.
        Column(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { currentOnSettings() })
                }
                .pointerInput(Unit) {
                    val threshold = 80.dp.toPx()
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total < -threshold) currentOnDrawerChange(true) },
                        onDragCancel = { total = 0f },
                        onVerticalDrag = { _, amount -> total += amount },
                    )
                }
                .windowInsetsPadding(WindowInsets.systemBars)
                .padding(horizontal = 8.dp, vertical = 16.dp),
        ) {
            if (!isDefaultHome) {
                Text(
                    text = "Tap to set as default launcher",
                    color = Color.White,
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier
                        .clickable(onClick = onRequestDefault)
                        .padding(8.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            if (pinnedKeys != null && pinned.isEmpty()) {
                Text(
                    text = "Swipe up for all apps",
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(16.dp),
                )
            }
            pinned.chunked(columns).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { item ->
                        AppCell(
                            item = item,
                            onWallpaper = true,
                            actions = actionsFor(item, showHide = false),
                            modifier = Modifier.weight(1f),
                        )
                    }
                    repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }

        // App drawer overlay.
        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            Surface(
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                modifier = Modifier.fillMaxSize(),
            ) {
                Column(Modifier.windowInsetsPadding(WindowInsets.systemBars)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 24.dp, end = 8.dp, top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Apps", style = MaterialTheme.typography.titleLarge)
                        TextButton(onClick = onOpenSettings) { Text("Settings") }
                    }
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(columns),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(drawerItems, key = { it.key }) { item ->
                            AppCell(
                                item = item,
                                onWallpaper = false,
                                actions = actionsFor(item, showHide = true),
                            )
                        }
                    }
                }
            }
        }
    }
}
