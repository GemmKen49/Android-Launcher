package com.personal.suite.launcher

import android.appwidget.AppWidgetProviderInfo
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.personal.suite.core.apps.AppCatalog
import com.personal.suite.core.apps.LauncherItem
import com.personal.suite.core.apps.openAppInfo
import com.personal.suite.core.prefs.LocalAppearance
import com.personal.suite.core.prefs.SuitePrefs
import com.personal.suite.core.registry.AppRegistry
import com.personal.suite.core.search.SearchCategory
import com.personal.suite.core.search.SearchEngine
import com.personal.suite.core.search.SearchRegistry
import com.personal.suite.core.search.SearchResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private const val DOCK_SLOTS = 8

private data class PinnedState(val keys: List<String>?)

@Composable
fun LauncherScreen(
    homeTick: Int,
    isActive: Boolean,
    isDefaultHome: Boolean,
    onRequestDefault: () -> Unit,
    onOpenSettings: () -> Unit,
    widgetHost: SuiteWidgetHost,
    onAddWidget: (AppWidgetProviderInfo) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawer = remember { DrawerController(scope) }
    val prefs = remember { SuitePrefs.get(context) }
    val catalog = remember { AppCatalog.get(context) }

    val items by catalog.items.collectAsState()
    val hidden by prefs.hiddenApps.collectAsState(initial = emptySet())
    val widgetIds by prefs.widgetIds.collectAsState(initial = emptyList())
    val pinnedState by remember { prefs.pinnedKeys.map { PinnedState(it) } }.collectAsState(initial = null)

    // Until the user customizes the dock, the built-in apps are pinned.
    val pinnedKeys: List<String>? = pinnedState?.let { state ->
        state.keys ?: AppRegistry.entries.map { "internal:${it.id}" }
    }
    val byKey = remember(items) { items.associateBy { it.key } }
    val dock = pinnedKeys.orEmpty().mapNotNull { byKey[it] }.take(DOCK_SLOTS)
    val drawerItems = remember(items, hidden) { items.filter { it.key !in hidden } }

    fun togglePin(item: LauncherItem) {
        val keys = pinnedKeys ?: return
        when {
            item.key in keys -> scope.launch { prefs.setPinned(keys - item.key) }
            keys.size >= DOCK_SLOTS -> Toast.makeText(context, "Dock is full", Toast.LENGTH_SHORT).show()
            else -> scope.launch { prefs.setPinned(keys + item.key) }
        }
    }

    fun actionsFor(item: LauncherItem, showHide: Boolean): List<CellAction> = buildList {
        val isPinned = item.key in pinnedKeys.orEmpty()
        add(CellAction(if (isPinned) "Unpin from dock" else "Pin to dock") { togglePin(item) })
        if (showHide) add(CellAction("Hide from drawer") { scope.launch { prefs.setHidden(item.key, true) } })
        if (item is LauncherItem.Installed) add(CellAction("App info") { context.openAppInfo(item) })
    }

    fun removeWidget(id: Int) {
        widgetHost.deleteAppWidgetId(id)
        scope.launch { prefs.removeWidget(id) }
    }

    val drawerVisible by remember { derivedStateOf { drawer.progress > 0f } }

    // A launcher is the root of the back stack: back only closes the drawer.
    BackHandler { }
    BackHandler(enabled = drawerVisible) { drawer.settle(false) }

    Box(Modifier.fillMaxSize()) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val pageHeight = maxHeight
            val widgetWidthDp = (maxWidth.value - 32f).toInt()
            val scrollState = rememberScrollState()
            val fling = ScrollableDefaults.flingBehavior()

            // Pressing Home closes the drawer and scrolls back to the clock.
            LaunchedEffect(homeTick) {
                if (homeTick > 0) {
                    drawer.settle(false)
                    scrollState.animateScrollTo(0)
                }
            }

            Column(
                Modifier
                    .fillMaxSize()
                    .pageScroll(scrollState, fling, scope)
                    .verticalScroll(scrollState, enabled = false),
            ) {
                HomePage(
                    height = pageHeight,
                    active = isActive,
                    isDefaultHome = isDefaultHome,
                    dock = dock,
                    actionsFor = { actionsFor(it, showHide = false) },
                    onRequestDefault = onRequestDefault,
                    drawer = drawer,
                )
                WidgetsSection(
                    host = widgetHost,
                    widgetIds = widgetIds,
                    widthDp = widgetWidthDp,
                    onAdd = onAddWidget,
                    onRemove = ::removeWidget,
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                )
            }
        }

        if (drawerVisible) {
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        translationX = (1f - drawer.progress) * size.width
                        alpha = (drawer.progress * 2f).coerceIn(0f, 1f)
                    },
            ) {
                Drawer(
                    drawer = drawer,
                    items = drawerItems,
                    actionsFor = { actionsFor(it, showHide = true) },
                    onOpenSettings = onOpenSettings,
                )
            }
        }
    }
}

/** First screen: clock, date and dock. Swipe left drags the drawer in; it can stop halfway or be dragged back. */
@Composable
private fun HomePage(
    height: Dp,
    active: Boolean,
    isDefaultHome: Boolean,
    dock: List<LauncherItem>,
    actionsFor: (LauncherItem) -> List<CellAction>,
    onRequestDefault: () -> Unit,
    drawer: DrawerController,
) {
    val appearance = LocalAppearance.current

    Box(
        Modifier
            .fillMaxWidth()
            .height(height)
            .drawerSwipe(drawer)
            .windowInsetsPadding(WindowInsets.systemBars),
    ) {
        if (!isDefaultHome) {
            Text(
                text = "Tap to set as default launcher",
                color = Color.White,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .clickable(onClick = onRequestDefault)
                    .padding(8.dp),
            )
        }

        StackedClock(active = active, modifier = Modifier.align(BiasAlignment(0f, appearance.clockVerticalBias)))

        if (dock.isEmpty()) {
            Text(
                text = "Swipe left for all apps",
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 24.dp),
            )
        } else {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                dock.forEach { item ->
                    AppCell(item = item, style = CellStyle.Dock, actions = actionsFor(item))
                }
            }
        }
    }
}

/**
 * All apps as translucent cards (column count from settings), with an A-Z scroller on the right
 * and search at the bottom. Search mode (bar focused, text typed or a filter chosen) replaces the
 * grid with results. Swipe right (or Back) closes the drawer; Back first leaves search mode.
 */
@Composable
private fun Drawer(
    drawer: DrawerController,
    items: List<LauncherItem>,
    actionsFor: (LauncherItem) -> List<CellAction>,
    onOpenSettings: () -> Unit,
) {
    val appearance = LocalAppearance.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    var query by remember { mutableStateOf("") }
    var filters by remember { mutableStateOf(emptySet<SearchCategory>()) }
    var focused by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var activeLetter by remember { mutableStateOf<Char?>(null) }
    val gridState = rememberLazyGridState()
    val searching = focused || query.isNotEmpty() || filters.isNotEmpty()

    val results by produceState(emptyList<SearchResult>(), query, filters, searching) {
        if (!searching) {
            value = emptyList()
            return@produceState
        }
        if (query.isNotEmpty()) delay(120)
        value = SearchEngine.search(query, filters)
    }

    fun exitSearch() {
        query = ""
        filters = emptySet()
        focusManager.clearFocus()
    }

    BackHandler(enabled = searching) { exitSearch() }

    // Section letters for the A-Z scroller (the list is sorted by label).
    val sections = remember(items) { items.map { sectionLetter(it.label) } }
    val letters = remember(sections) { sections.distinct() }
    val firstIndex = remember(sections, letters) { letters.associateWith { sections.indexOf(it) } }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = appearance.drawerScrim))
            .drawerSwipe(drawer),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars.union(WindowInsets.ime)),
        ) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (searching) {
                    if (query.isNotEmpty() && results.isEmpty()) {
                        Text(
                            text = "No results",
                            color = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.align(Alignment.Center),
                        )
                    }
                    LazyColumn(
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(results, key = { it.key }) { result ->
                            SearchResultCard(
                                result = result,
                                actions = result.item?.let(actionsFor).orEmpty(),
                                onOpened = { drawer.settle(false) },
                            )
                        }
                    }
                } else {
                    Row(Modifier.fillMaxSize()) {
                        LazyVerticalGrid(
                            state = gridState,
                            columns = GridCells.Fixed(appearance.drawerColumns.coerceAtLeast(1)),
                            contentPadding = PaddingValues(start = 12.dp, top = 12.dp, end = 4.dp, bottom = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                        ) {
                            items(items, key = { it.key }) { item ->
                                // While dragging the A-Z scroller, apps outside the chosen letter fade back.
                                val dim by animateFloatAsState(
                                    targetValue = if (activeLetter == null || sectionLetter(item.label) == activeLetter) 1f else 0.25f,
                                    label = "dim",
                                )
                                AppCell(
                                    item = item,
                                    style = CellStyle.Card,
                                    actions = actionsFor(item),
                                    modifier = Modifier.alpha(dim),
                                    onLaunched = { drawer.settle(false) },
                                )
                            }
                        }
                        AlphabetScroller(
                            letters = letters,
                            active = activeLetter,
                            onActiveChange = { letter ->
                                if (letter != activeLetter) {
                                    activeLetter = letter
                                    letter?.let { firstIndex[it] }?.let { index ->
                                        scope.launch { gridState.scrollToItem(index) }
                                    }
                                }
                            },
                            modifier = Modifier.padding(vertical = 8.dp),
                        )
                    }
                }
            }

            if (searching) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(SearchCategory.entries) { category ->
                        FilterChip(
                            selected = category in filters,
                            enabled = SearchRegistry.isAvailable(category),
                            onClick = {
                                filters = if (category in filters) filters - category else filters + category
                            },
                            label = { Text(category.label) },
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .height(52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(cardColor())
                    .padding(start = 20.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = Color.White),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier
                        .weight(1f)
                        .onFocusChanged { focused = it.isFocused },
                    decorationBox = { innerTextField ->
                        Box {
                            if (query.isEmpty()) {
                                Text(
                                    text = "Search",
                                    color = Color.White.copy(alpha = 0.6f),
                                    style = MaterialTheme.typography.bodyLarge,
                                )
                            }
                            innerTextField()
                        }
                    },
                )
                if (searching) {
                    Text(
                        text = "Clear",
                        color = Color.White,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier
                            .clickable(onClick = ::exitSearch)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                    )
                }
                // Settings live here, like Kvaesitso's search bar menu.
                Box {
                    Text(
                        text = "⋮",
                        color = Color.White,
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier
                            .clickable { menuOpen = true }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                    )
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Settings") },
                            onClick = {
                                menuOpen = false
                                onOpenSettings()
                            },
                        )
                    }
                }
            }
        }
    }
}
