package com.personal.suite.launcher

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.personal.suite.core.apps.AppCatalog
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.prefs.Appearance
import com.personal.suite.core.prefs.SuitePrefs
import com.personal.suite.core.prefs.ThemeMode
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class SettingsActivity : ComponentActivity() {

    private var isHomeApp by mutableStateOf(false)

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        isHomeApp = holdsHomeRole()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuiteTheme {
                SettingsScreen(
                    isDefaultHome = isHomeApp,
                    onRequestDefault = { homeRoleIntent()?.let { roleLauncher.launch(it) } },
                    onOpenDefaultAppsSettings = { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        isHomeApp = holdsHomeRole()
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp))
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Slider that only saves when released, so dragging doesn't write settings on every frame. */
@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    display: (Float) -> String,
    onCommit: (Float) -> Unit,
    steps: Int = 0,
) {
    var current by remember(value) { mutableFloatStateOf(value) }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(display(current), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(
            value = current,
            onValueChange = { current = it },
            onValueChangeFinished = { onCommit(current) },
            valueRange = range,
            steps = steps,
        )
    }
}

@Composable
private fun SettingsScreen(
    isDefaultHome: Boolean,
    onRequestDefault: () -> Unit,
    onOpenDefaultAppsSettings: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { SuitePrefs.get(context) }
    val catalog = remember { AppCatalog.get(context) }

    val themeMode by prefs.themeMode.collectAsState(initial = ThemeMode.System)
    val appearance by prefs.appearance.collectAsState(initial = Appearance())
    val hidden by prefs.hiddenApps.collectAsState(initial = emptySet())
    val items by catalog.items.collectAsState()
    val hiddenItems = items.filter { it.key in hidden }

    fun update(change: Appearance.() -> Appearance) {
        scope.launch { prefs.setAppearance(appearance.change()) }
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { Text("Launcher settings", style = MaterialTheme.typography.headlineMedium) }

            item { SectionTitle("Default launcher") }
            item {
                Text(if (isDefaultHome) "This app is your home app." else "This app is not your home app yet.")
            }
            if (!isDefaultHome) {
                item { Button(onClick = onRequestDefault) { Text("Set as default launcher") } }
                item { TextButton(onClick = onOpenDefaultAppsSettings) { Text("Open default apps settings") } }
            }

            item { SectionTitle("Theme") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = themeMode == mode,
                            onClick = { scope.launch { prefs.setThemeMode(mode) } },
                            label = { Text(mode.name) },
                        )
                    }
                }
            }
            item {
                SwitchRow("Dynamic colors (from wallpaper)", appearance.dynamicColor) { update { copy(dynamicColor = it) } }
            }

            item { SectionTitle("Clock") }
            item { SwitchRow("Monospace font", appearance.clockMonospace) { update { copy(clockMonospace = it) } } }
            item {
                SliderRow("Size", appearance.clockSize, 40f..120f, { "${it.roundToInt()} sp" }, { update { copy(clockSize = it) } })
            }
            item {
                SliderRow(
                    "Line spacing", appearance.clockLineSpacing, 0.6f..1.2f,
                    { "%.2f".format(it) }, { update { copy(clockLineSpacing = it) } },
                )
            }
            item {
                SliderRow(
                    "Vertical position", appearance.clockVerticalBias, -0.6f..0.9f,
                    { "%.2f".format(it) }, { update { copy(clockVerticalBias = it) } },
                )
            }
            item { SwitchRow("Show seconds", appearance.clockShowSeconds) { update { copy(clockShowSeconds = it) } } }
            item { SwitchRow("Show date", appearance.clockShowDate) { update { copy(clockShowDate = it) } } }

            item { SectionTitle("Dock") }
            item {
                SliderRow("Icon size", appearance.dockIconSize, 32f..64f, { "${it.roundToInt()} dp" }, { update { copy(dockIconSize = it) } })
            }

            item { SectionTitle("App drawer") }
            item {
                SliderRow(
                    "Columns", appearance.drawerColumns.toFloat(), 1f..4f,
                    { it.roundToInt().toString() }, { update { copy(drawerColumns = it.roundToInt()) } }, steps = 2,
                )
            }
            item {
                SliderRow("Icon size", appearance.drawerIconSize, 28f..56f, { "${it.roundToInt()} dp" }, { update { copy(drawerIconSize = it) } })
            }
            item {
                SliderRow(
                    "Card opacity", appearance.cardOpacity, 0.2f..1f,
                    { "${(it * 100).roundToInt()}%" }, { update { copy(cardOpacity = it) } },
                )
            }
            item {
                SliderRow(
                    "Card corner radius", appearance.cardCornerRadius, 0f..28f,
                    { "${it.roundToInt()} dp" }, { update { copy(cardCornerRadius = it) } },
                )
            }
            item {
                SliderRow(
                    "Background dimming", appearance.drawerScrim, 0f..0.9f,
                    { "${(it * 100).roundToInt()}%" }, { update { copy(drawerScrim = it) } },
                )
            }

            item {
                OutlinedButton(onClick = { scope.launch { prefs.setAppearance(Appearance()) } }) {
                    Text("Reset appearance")
                }
            }

            item { SectionTitle("Hidden apps") }
            if (hiddenItems.isEmpty()) {
                item { Text("None. Long-press an app in the drawer to hide it.") }
            }
            items(hiddenItems, key = { it.key }) { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(item.label)
                    TextButton(onClick = { scope.launch { prefs.setHidden(item.key, false) } }) {
                        Text("Unhide")
                    }
                }
            }
        }
    }
}
