package com.personal.suite.launcher

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.personal.suite.core.apps.AppCatalog
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.prefs.SuitePrefs
import com.personal.suite.core.prefs.ThemeMode
import kotlinx.coroutines.launch

class SettingsActivity : ComponentActivity() {

    private var isHomeApp by mutableStateOf(false)

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        isHomeApp = holdsHomeRole()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuiteTheme {
                SettingsScreen(
                    isDefaultHome = isHomeApp,
                    onRequestDefault = { homeRoleIntent()?.let { roleLauncher.launch(it) } },
                    onOpenDefaultAppsSettings = { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        isHomeApp = holdsHomeRole()
    }
}

@Composable
private fun SettingsScreen(
    isDefaultHome: Boolean,
    onRequestDefault: () -> Unit,
    onOpenDefaultAppsSettings: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { SuitePrefs.get(context) }
    val catalog = remember { AppCatalog.get(context) }

    val themeMode by prefs.themeMode.collectAsState(initial = ThemeMode.System)
    val columns by prefs.gridColumns.collectAsState(initial = SuitePrefs.DEFAULT_COLUMNS)
    val hidden by prefs.hiddenApps.collectAsState(initial = emptySet())
    val items by catalog.items.collectAsState()
    val hiddenItems = items.filter { it.key in hidden }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { Text("Launcher settings", style = MaterialTheme.typography.headlineMedium) }

            item { Text("Default launcher", style = MaterialTheme.typography.titleMedium) }
            item {
                Text(if (isDefaultHome) "This app is your home app." else "This app is not your home app yet.")
            }
            if (!isDefaultHome) {
                item { Button(onClick = onRequestDefault) { Text("Set as default launcher") } }
                item { TextButton(onClick = onOpenDefaultAppsSettings) { Text("Open default apps settings") } }
            }

            item { Text("Theme", style = MaterialTheme.typography.titleMedium) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = themeMode == mode,
                            onClick = { scope.launch { prefs.setThemeMode(mode) } },
                            label = { Text(mode.name) },
                        )
                    }
                }
            }

            item { Text("Grid columns", style = MaterialTheme.typography.titleMedium) }
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Button(
                        onClick = { scope.launch { prefs.setGridColumns(columns - 1) } },
                        enabled = columns > SuitePrefs.MIN_COLUMNS,
                    ) { Text("-") }
                    Text("$columns", style = MaterialTheme.typography.titleMedium)
                    Button(
                        onClick = { scope.launch { prefs.setGridColumns(columns + 1) } },
                        enabled = columns < SuitePrefs.MAX_COLUMNS,
                    ) { Text("+") }
                }
            }

            item { Text("Hidden apps", style = MaterialTheme.typography.titleMedium) }
            if (hiddenItems.isEmpty()) {
                item { Text("None. Long-press an app in the drawer to hide it.") }
            }
            items(hiddenItems, key = { it.key }) { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(item.label)
                    TextButton(onClick = { scope.launch { prefs.setHidden(item.key, false) } }) {
                        Text("Unhide")
                    }
                }
            }
        }
    }
}
