package com.personal.suite.launcher

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.personal.suite.core.apps.AppCatalog
import com.personal.suite.core.apps.LauncherItem
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.prefs.Appearance
import com.personal.suite.core.prefs.FilesPrefs
import com.personal.suite.core.prefs.LocalAppearance
import com.personal.suite.core.prefs.SortBy
import com.personal.suite.core.prefs.SuitePrefs
import com.personal.suite.core.prefs.ThemeMode
import com.personal.suite.core.prefs.WidgetPlacement
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class SettingsActivity : ComponentActivity() {

    private var isHomeApp by mutableStateOf(false)
    private val scope = MainScope()
    private lateinit var widgetHost: SuiteWidgetHost
    private var pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        isHomeApp = holdsHomeRole()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        widgetHost = SuiteWidgetHost(applicationContext)
        setContent {
            SuiteTheme {
                SettingsScreen(
                    isDefaultHome = isHomeApp,
                    onRequestDefault = { homeRoleIntent()?.let { roleLauncher.launch(it) } },
                    onOpenDefaultAppsSettings = { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) },
                    widgetHost = widgetHost,
                    onAddWidget = ::startAddWidget,
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        isHomeApp = holdsHomeRole()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // --- Adding a widget: allocate id -> bind (user consent) -> configure (if needed) -> save ---

    private fun startAddWidget(info: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        pendingWidgetId = id
        if (AppWidgetManager.getInstance(this).bindAppWidgetIdIfAllowed(id, info.provider)) {
            onWidgetBound(id)
        } else {
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQUEST_BIND)
        }
    }

    private fun onWidgetBound(id: Int) {
        val info = AppWidgetManager.getInstance(this).getAppWidgetInfo(id)
        if (info?.configure != null) {
            widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQUEST_CONFIGURE, null)
        } else {
            commitWidget(id)
        }
    }

    private fun commitWidget(id: Int) {
        pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
        scope.launch { SuitePrefs.get(applicationContext).addWidget(id) }
    }

    private fun cancelPendingWidget() {
        if (pendingWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            widgetHost.deleteAppWidgetId(pendingWidgetId)
            pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = pendingWidgetId
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return
        when (requestCode) {
            REQUEST_BIND -> if (resultCode == RESULT_OK) onWidgetBound(id) else cancelPendingWidget()
            REQUEST_CONFIGURE -> if (resultCode == RESULT_OK) commitWidget(id) else cancelPendingWidget()
        }
    }

    private companion object {
        const val REQUEST_BIND = 1
        const val REQUEST_CONFIGURE = 2
    }
}

private enum class SettingsTab(val label: String) {
    General("General"),
    Launcher("Launcher"),
    File("File"),
    Gallery("Gallery"),
    Media("Media"),
    Document("Document"),
    Terminal("Terminal"),
}

private enum class LauncherPage(val label: String, val summary: String) {
    Clock("Clock", "Font, size, digit width, spacing, position"),
    Dock("Dock", "Icon size"),
    Drawer("App drawer", "Columns, cards, dimming"),
    Widgets("Widgets", "Add, columns, sizes"),
    Hidden("Hidden apps", "Apps hidden from the drawer"),
}

/**
 * Edits an [Appearance] draft. [edit] changes the draft only (previews update live while dragging);
 * [commit] saves it; [set] does both.
 */
private class Editor(
    private val read: () -> Appearance,
    private val write: (Appearance) -> Unit,
    private val save: () -> Unit,
) {
    val draft: Appearance get() = read()
    fun edit(change: Appearance.() -> Appearance) = write(read().change())
    fun commit() = save()
    fun set(change: Appearance.() -> Appearance) {
        edit(change)
        save()
    }
}

@Composable
private fun SettingsScreen(
    isDefaultHome: Boolean,
    onRequestDefault: () -> Unit,
    onOpenDefaultAppsSettings: () -> Unit,
    widgetHost: SuiteWidgetHost,
    onAddWidget: (AppWidgetProviderInfo) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { SuitePrefs.get(context) }

    val saved by prefs.appearance.collectAsState(initial = Appearance())
    var draft by remember { mutableStateOf(saved) }
    LaunchedEffect(saved) { draft = saved }
    val editor = remember {
        Editor(
            read = { draft },
            write = { draft = it },
            save = { scope.launch { prefs.setAppearance(draft) } },
        )
    }

    var tab by rememberSaveable { mutableStateOf(SettingsTab.General) }
    var page by rememberSaveable { mutableStateOf<LauncherPage?>(null) }

    BackHandler(enabled = tab == SettingsTab.Launcher && page != null) { page = null }

    Scaffold { padding ->
        Column(Modifier.padding(padding)) {
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(start = 24.dp, top = 16.dp, bottom = 4.dp),
            )
            SettingsTabBar(selected = tab, onSelect = { tab = it })
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    SettingsTab.General -> GeneralPage(isDefaultHome, onRequestDefault, onOpenDefaultAppsSettings, editor)
                    SettingsTab.Launcher -> LauncherSettings(page, { page = it }, editor, widgetHost, onAddWidget)
                    SettingsTab.File -> FilePage()
                    else -> PlaceholderPage(tab.label)
                }
            }
        }
    }
}

@Composable
private fun SettingsTabBar(selected: SettingsTab, onSelect: (SettingsTab) -> Unit) {
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp),
        ) {
            SettingsTab.entries.forEach { tab ->
                val isSelected = tab == selected
                Column(
                    modifier = Modifier
                        .clickable { onSelect(tab) }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = tab.label,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    )
                    Spacer(Modifier.height(6.dp))
                    Box(
                        Modifier
                            .height(2.dp)
                            .width(24.dp)
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent),
                    )
                }
            }
        }
        HorizontalDivider()
    }
}

// ---------------- small building blocks ----------------

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun DetailHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = "‹",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier
                .clickable(onClick = onBack)
                .padding(end = 14.dp, top = 4.dp, bottom = 4.dp),
        )
        Text(title, style = MaterialTheme.typography.headlineSmall)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** [onChange] runs while dragging (live preview); [onCommit] when the finger lifts (save). */
@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    display: (Float) -> String,
    onChange: (Float) -> Unit,
    onCommit: () -> Unit,
    steps: Int = 0,
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(display(value), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(
            value = value.coerceIn(range),
            onValueChange = onChange,
            onValueChangeFinished = onCommit,
            valueRange = range,
            steps = steps,
        )
    }
}

// ---------------- previews ----------------

@Composable
private fun PreviewBox(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF4A5A7A), Color(0xFF2B2F45)))),
        content = content,
    )
}

/** Shows [content] but swallows touches, so previews never launch apps. */
@Composable
private fun NonInteractive(content: @Composable () -> Unit) {
    Box {
        content()
        Box(Modifier.matchParentSize().pointerInput(Unit) {})
    }
}

@Composable
private fun rememberSampleItems(): List<LauncherItem> {
    val context = LocalContext.current
    val items by remember { AppCatalog.get(context).items }.collectAsState()
    return items.take(6)
}

@Composable
private fun ClockPreview(a: Appearance) {
    CompositionLocalProvider(LocalAppearance provides a) {
        PreviewBox {
            NonInteractive {
                Box(Modifier.fillMaxWidth().padding(vertical = 24.dp), contentAlignment = Alignment.Center) {
                    StackedClock(active = true)
                }
            }
        }
    }
}

@Composable
private fun DockPreview(a: Appearance) {
    val samples = rememberSampleItems()
    CompositionLocalProvider(LocalAppearance provides a) {
        PreviewBox {
            NonInteractive {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    samples.take(5).forEach { AppCell(item = it, style = CellStyle.Dock, actions = emptyList()) }
                }
            }
        }
    }
}

@Composable
private fun DrawerPreview(a: Appearance) {
    val samples = rememberSampleItems()
    val columns = a.drawerColumns.coerceAtLeast(1)
    CompositionLocalProvider(LocalAppearance provides a) {
        PreviewBox {
            Box(Modifier.fillMaxWidth().background(Color.Black.copy(alpha = a.drawerScrim))) {
                NonInteractive {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        samples.chunked(columns).forEach { row ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                row.forEach { item ->
                                    AppCell(
                                        item = item,
                                        style = CellStyle.Card,
                                        actions = emptyList(),
                                        modifier = Modifier.weight(1f),
                                    )
                                }
                                repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Where the widgets will sit, using the same grid, spans and limits as the home screen. */
@Composable
private fun WidgetsPreview(slots: List<WidgetSlot>, a: Appearance, containerDp: Float) {
    val context = LocalContext.current
    PreviewBox {
        NonInteractive {
            if (slots.isEmpty()) {
                Text(
                    text = "Added widgets are laid out here",
                    color = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.padding(24.dp),
                )
            } else {
                WidgetGrid(
                    slots = slots,
                    columns = a.widgetColumns,
                    gap = a.widgetGap.dp,
                    containerWidth = containerDp.dp,
                ) { slot, _ ->
                    val name = slot.info?.loadLabel(context.packageManager) ?: "Unavailable"
                    Box(
                        Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = "$name · ${slot.span} col",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(8.dp),
                        )
                    }
                }
            }
        }
    }
}

// ---------------- General ----------------

@Composable
private fun GeneralPage(
    isDefaultHome: Boolean,
    onRequestDefault: () -> Unit,
    onOpenDefaultAppsSettings: () -> Unit,
    editor: Editor,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { SuitePrefs.get(context) }
    val themeMode by prefs.themeMode.collectAsState(initial = ThemeMode.System)
    val a = editor.draft

    LazyColumn(
        contentPadding = PaddingValues(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { SectionTitle("Default launcher") }
        item { Text(if (isDefaultHome) "This app is your home app." else "This app is not your home app yet.") }
        if (!isDefaultHome) {
            item { Button(onClick = onRequestDefault) { Text("Set as default launcher") } }
            item { TextButton(onClick = onOpenDefaultAppsSettings) { Text("Open default apps settings") } }
        }

        item { SectionTitle("Theme") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = themeMode == mode,
                        onClick = { scope.launch { prefs.setThemeMode(mode) } },
                        label = { Text(mode.name) },
                    )
                }
            }
        }
        item {
            SwitchRow("Dynamic colors (from wallpaper)", a.dynamicColor) { editor.set { copy(dynamicColor = it) } }
        }

        item { SectionTitle("Reset") }
        item {
            OutlinedButton(onClick = { editor.set { Appearance() } }) { Text("Reset all appearance settings") }
        }
    }
}

// ---------------- Launcher ----------------

@Composable
private fun LauncherSettings(
    page: LauncherPage?,
    onPage: (LauncherPage?) -> Unit,
    editor: Editor,
    widgetHost: SuiteWidgetHost,
    onAddWidget: (AppWidgetProviderInfo) -> Unit,
) {
    when (page) {
        null -> LazyColumn(contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp)) {
            items(LauncherPage.entries) { entry ->
                Column {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPage(entry) }
                            .padding(vertical = 14.dp),
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(entry.label, style = MaterialTheme.typography.titleMedium)
                            Text("›", style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            text = entry.summary,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    HorizontalDivider()
                }
            }
        }
        LauncherPage.Clock -> ClockPage(editor) { onPage(null) }
        LauncherPage.Dock -> DockPage(editor) { onPage(null) }
        LauncherPage.Drawer -> DrawerPage(editor) { onPage(null) }
        LauncherPage.Widgets -> WidgetsPage(editor, widgetHost, onAddWidget) { onPage(null) }
        LauncherPage.Hidden -> HiddenPage { onPage(null) }
    }
}

@Composable
private fun ClockPage(editor: Editor, onBack: () -> Unit) {
    val a = editor.draft
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { DetailHeader("Clock", onBack) }
        item { ClockPreview(a) }
        item {
            SwitchRow("Fixed digit positions (monospace)", a.clockMonospace) { editor.set { copy(clockMonospace = it) } }
        }
        if (a.clockMonospace) {
            item {
                SliderRow(
                    "Digit width", a.clockDigitWidth, 0.45f..0.9f, { "%.2f".format(it) },
                    { v -> editor.edit { copy(clockDigitWidth = v) } }, editor::commit,
                )
            }
        }
        item {
            SliderRow(
                "Size", a.clockSize, 40f..120f, { "${it.roundToInt()} sp" },
                { v -> editor.edit { copy(clockSize = v) } }, editor::commit,
            )
        }
        item {
            SliderRow(
                "Gap between hours, minutes and seconds", a.clockLineGap, 0f..60f, { "${it.roundToInt()} dp" },
                { v -> editor.edit { copy(clockLineGap = v) } }, editor::commit,
            )
        }
        item {
            SliderRow(
                "Seconds size", a.clockSecondsScale, 0.3f..1f, { "${(it * 100).roundToInt()}%" },
                { v -> editor.edit { copy(clockSecondsScale = v) } }, editor::commit,
            )
        }
        item {
            SliderRow(
                "Vertical position", a.clockVerticalBias, -0.6f..0.9f, { "%.2f".format(it) },
                { v -> editor.edit { copy(clockVerticalBias = v) } }, editor::commit,
            )
        }
        item { SwitchRow("Show seconds", a.clockShowSeconds) { editor.set { copy(clockShowSeconds = it) } } }
        item { SwitchRow("Show date", a.clockShowDate) { editor.set { copy(clockShowDate = it) } } }
    }
}

@Composable
private fun DockPage(editor: Editor, onBack: () -> Unit) {
    val a = editor.draft
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { DetailHeader("Dock", onBack) }
        item { DockPreview(a) }
        item {
            SliderRow(
                "Icon size", a.dockIconSize, 32f..64f, { "${it.roundToInt()} dp" },
                { v -> editor.edit { copy(dockIconSize = v) } }, editor::commit,
            )
        }
    }
}

@Composable
private fun DrawerPage(editor: Editor, onBack: () -> Unit) {
    val a = editor.draft
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { DetailHeader("App drawer", onBack) }
        item { DrawerPreview(a) }
        item {
            SliderRow(
                "Columns", a.drawerColumns.toFloat(), 1f..4f, { it.roundToInt().toString() },
                { v -> editor.edit { copy(drawerColumns = v.roundToInt()) } }, editor::commit, steps = 2,
            )
        }
        item {
            SliderRow(
                "Icon size", a.drawerIconSize, 28f..56f, { "${it.roundToInt()} dp" },
                { v -> editor.edit { copy(drawerIconSize = v) } }, editor::commit,
            )
        }
        item {
            SliderRow(
                "Card opacity", a.cardOpacity, 0.2f..1f, { "${(it * 100).roundToInt()}%" },
                { v -> editor.edit { copy(cardOpacity = v) } }, editor::commit,
            )
        }
        item {
            SliderRow(
                "Card corner radius", a.cardCornerRadius, 0f..28f, { "${it.roundToInt()} dp" },
                { v -> editor.edit { copy(cardCornerRadius = v) } }, editor::commit,
            )
        }
        item {
            SliderRow(
                "Background dimming", a.drawerScrim, 0f..0.9f, { "${(it * 100).roundToInt()}%" },
                { v -> editor.edit { copy(drawerScrim = v) } }, editor::commit,
            )
        }
    }
}

@Composable
private fun WidgetsPage(
    editor: Editor,
    widgetHost: SuiteWidgetHost,
    onAddWidget: (AppWidgetProviderInfo) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { SuitePrefs.get(context) }
    val placements by prefs.widgets.collectAsState(initial = emptyList())
    val a = editor.draft
    // Same container width as the home screen (screen width minus 16dp padding each side).
    val containerDp = LocalConfiguration.current.screenWidthDp - 32f
    val slots = remember(placements, a.widgetColumns, a.widgetGap, containerDp) {
        resolveSlots(context, placements, a.widgetColumns, containerDp, a.widgetGap)
    }
    var showPicker by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { DetailHeader("Widgets", onBack) }
        item { WidgetsPreview(slots, a, containerDp) }
        item { Button(onClick = { showPicker = true }) { Text("Add widgets") } }
        item {
            SliderRow(
                "Columns", a.widgetColumns.toFloat(), 1f..4f, { it.roundToInt().toString() },
                { v -> editor.edit { copy(widgetColumns = v.roundToInt()) } }, editor::commit, steps = 2,
            )
        }
        item {
            Text(
                text = "Several widgets share a row when they fit. Each widget's own limits decide how few columns it can use.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item {
            SliderRow(
                "Gap", a.widgetGap, 0f..24f, { "${it.roundToInt()} dp" },
                { v -> editor.edit { copy(widgetGap = v) } }, editor::commit,
            )
        }

        item { SectionTitle("Placed widgets") }
        if (slots.isEmpty()) item { Text("No widgets yet.") }
        items(slots, key = { it.placement.id }) { slot ->
            WidgetSettingsRow(
                slot = slot,
                a = a,
                containerDp = containerDp,
                onUpdate = { placement -> scope.launch { prefs.updateWidget(placement) } },
                onRemove = {
                    widgetHost.deleteAppWidgetId(slot.placement.id)
                    scope.launch { prefs.removeWidget(slot.placement.id) }
                },
            )
        }
    }

    if (showPicker) {
        WidgetPickerDialog(
            onPick = { info ->
                showPicker = false
                onAddWidget(info)
            },
            onDismiss = { showPicker = false },
        )
    }
}

/** Per-widget size settings, limited to what that widget supports at the current column count. */
@Composable
private fun WidgetSettingsRow(
    slot: WidgetSlot,
    a: Appearance,
    containerDp: Float,
    onUpdate: (WidgetPlacement) -> Unit,
    onRemove: () -> Unit,
) {
    val context = LocalContext.current
    val info = slot.info
    val label = info?.loadLabel(context.packageManager) ?: "Unavailable widget"

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            TextButton(onClick = onRemove) { Text("Remove") }
        }
        if (info != null) {
            val spans = spanLimits(context, info, a.widgetColumns, containerDp, a.widgetGap)
            val heights = heightLimits(context, info)

            if (spans.first < spans.last) {
                var span by remember(slot.span) { mutableFloatStateOf(slot.span.toFloat()) }
                SliderRow(
                    label = "Columns",
                    value = span,
                    range = spans.first.toFloat()..spans.last.toFloat(),
                    display = { "${it.roundToInt()} of ${a.widgetColumns}" },
                    onChange = { span = it },
                    onCommit = { onUpdate(slot.placement.copy(span = span.roundToInt())) },
                    steps = spans.last - spans.first - 1,
                )
            } else {
                Text(
                    text = "Columns: ${spans.first} (fixed by this widget)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            if (heights.first < heights.last) {
                var height by remember(slot.height) { mutableFloatStateOf(slot.height.value) }
                SliderRow(
                    label = "Height",
                    value = height,
                    range = heights.first.toFloat()..heights.last.toFloat(),
                    display = { "${it.roundToInt()} dp" },
                    onChange = { height = it },
                    onCommit = { onUpdate(slot.placement.copy(heightDp = height.roundToInt())) },
                )
            } else {
                Text(
                    text = "Height: ${heights.first} dp (fixed by this widget)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        HorizontalDivider(Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun HiddenPage(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { SuitePrefs.get(context) }
    val hidden by prefs.hiddenApps.collectAsState(initial = emptySet())
    val catalog = remember { AppCatalog.get(context) }
    val all by catalog.items.collectAsState()
    val hiddenItems = all.filter { it.key in hidden }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { DetailHeader("Hidden apps", onBack) }
        if (hiddenItems.isEmpty()) {
            item { Text("None. Long-press an app in the drawer to hide it.") }
        }
        items(hiddenItems, key = { it.key }) { item ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(item.label)
                TextButton(onClick = { scope.launch { prefs.setHidden(item.key, false) } }) { Text("Unhide") }
            }
        }
    }
}

// ---------------- File / placeholders ----------------

@Composable
private fun FilePage() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { SuitePrefs.get(context) }
    val fp by prefs.filesPrefs.collectAsState(initial = FilesPrefs())

    fun update(change: FilesPrefs.() -> FilesPrefs) {
        scope.launch { prefs.setFilesPrefs(fp.change()) }
    }

    LazyColumn(
        contentPadding = PaddingValues(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { SectionTitle("File manager") }
        item { SwitchRow("Show hidden files", fp.showHidden) { update { copy(showHidden = it) } } }
        item { SectionTitle("Sort by") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SortBy.entries.forEach { sort ->
                    FilterChip(
                        selected = fp.sortBy == sort,
                        onClick = { update { copy(sortBy = sort) } },
                        label = { Text(sort.name) },
                    )
                }
            }
        }
        item { SwitchRow("Descending", fp.descending) { update { copy(descending = it) } } }
        item { SwitchRow("Folders first", fp.foldersFirst) { update { copy(foldersFirst = it) } } }
    }
}

@Composable
private fun PlaceholderPage(name: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(
            text = "$name settings will appear here once that app is built.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
