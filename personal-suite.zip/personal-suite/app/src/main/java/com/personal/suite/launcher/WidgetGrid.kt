package com.personal.suite.launcher

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.personal.suite.core.prefs.WidgetPlacement
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

/** A placed widget with its size resolved against the provider's limits and the current column count. [info] is null if the provider is gone. */
internal data class WidgetSlot(
    val placement: WidgetPlacement,
    val info: AppWidgetProviderInfo?,
    val span: Int,
    val height: Dp,
)

private fun Context.px2dp(px: Int): Float = px / resources.displayMetrics.density

internal fun cellWidthDp(containerDp: Float, columns: Int, gapDp: Float): Float =
    ((containerDp - gapDp * (columns - 1)) / columns).coerceAtLeast(1f)

/**
 * How many columns the widget may span. A widget that can't be resized horizontally has one fixed span;
 * otherwise the range comes from its declared minimum (and maximum, Android 12+) resize width.
 */
internal fun spanLimits(context: Context, info: AppWidgetProviderInfo, columns: Int, containerDp: Float, gapDp: Float): IntRange {
    val cell = cellWidthDp(containerDp, columns, gapDp)
    fun spanFor(widthDp: Float) = ceil((widthDp + gapDp) / (cell + gapDp)).toInt().coerceIn(1, columns)

    val resizable = (info.resizeMode and AppWidgetProviderInfo.RESIZE_HORIZONTAL) != 0
    val minWidthPx = if (resizable && info.minResizeWidth > 0) info.minResizeWidth else info.minWidth
    val min = spanFor(context.px2dp(minWidthPx))
    if (!resizable) return min..min

    var max = columns
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && info.maxResizeWidth > 0) {
        val maxWidth = context.px2dp(info.maxResizeWidth)
        max = floor((maxWidth + gapDp) / (cell + gapDp)).toInt().coerceIn(min, columns)
    }
    return min..max
}

internal fun defaultHeightDp(context: Context, info: AppWidgetProviderInfo): Int =
    context.px2dp(info.minHeight).roundToInt().coerceAtLeast(72)

/** Allowed heights in dp: fixed unless the widget can be resized vertically. */
internal fun heightLimits(context: Context, info: AppWidgetProviderInfo): IntRange {
    val default = defaultHeightDp(context, info)
    if ((info.resizeMode and AppWidgetProviderInfo.RESIZE_VERTICAL) == 0) return default..default
    val min = (if (info.minResizeHeight > 0) context.px2dp(info.minResizeHeight).roundToInt() else default)
        .coerceIn(48, default)
    val max = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && info.maxResizeHeight > 0) {
        context.px2dp(info.maxResizeHeight).roundToInt()
    } else {
        default * 3
    }).coerceAtLeast(default)
    return min..max
}

internal fun resolveSlots(
    context: Context,
    placements: List<WidgetPlacement>,
    columns: Int,
    containerDp: Float,
    gapDp: Float,
): List<WidgetSlot> {
    val manager = AppWidgetManager.getInstance(context)
    return placements.map { placement ->
        val info = manager.getAppWidgetInfo(placement.id)
        if (info == null) {
            WidgetSlot(placement, null, 1, 72.dp)
        } else {
            val spans = spanLimits(context, info, columns, containerDp, gapDp)
            val span = if (placement.span > 0) placement.span.coerceIn(spans.first, spans.last) else spans.first
            val heights = heightLimits(context, info)
            val height = if (placement.heightDp > 0) {
                placement.heightDp.coerceIn(heights.first, heights.last)
            } else {
                defaultHeightDp(context, info)
            }
            WidgetSlot(placement, info, span, height.dp)
        }
    }
}

private fun packRows(slots: List<WidgetSlot>, columns: Int): List<List<WidgetSlot>> {
    val rows = mutableListOf<MutableList<WidgetSlot>>()
    var used = 0
    for (slot in slots) {
        if (rows.isEmpty() || used + slot.span > columns) {
            rows.add(mutableListOf())
            used = 0
        }
        rows.last().add(slot)
        used += slot.span
    }
    return rows
}

/** Lays widgets out left to right in a grid of [columns]; a widget takes its span, and a new row starts when one is full. */
@Composable
internal fun WidgetGrid(
    slots: List<WidgetSlot>,
    columns: Int,
    gap: Dp,
    containerWidth: Dp,
    modifier: Modifier = Modifier,
    item: @Composable (slot: WidgetSlot, width: Dp) -> Unit,
) {
    val cell = (containerWidth - gap * (columns - 1)) / columns
    Column(modifier, verticalArrangement = Arrangement.spacedBy(gap)) {
        packRows(slots, columns).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                row.forEach { slot ->
                    val width = cell * slot.span + gap * (slot.span - 1)
                    Box(Modifier.width(width).height(slot.height)) { item(slot, width) }
                }
            }
        }
    }
}
