package com.personal.suite.launcher

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.util.addPointerInputChange
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Vertical page scrolling that works even when the touch starts on an Android widget (a View).
 * Watches in the Initial pass, so taps still reach widgets; once a vertical drag is recognised it
 * consumes the gesture, which cancels the widget's touch and scrolls [state] instead.
 * Pair with `verticalScroll(state, enabled = false)`.
 */
fun Modifier.pageScroll(state: ScrollState, fling: FlingBehavior, scope: CoroutineScope): Modifier =
    pointerInput(state) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val tracker = VelocityTracker()
            tracker.addPointerInputChange(down)
            val slop = viewConfiguration.touchSlop
            var totalX = 0f
            var totalY = 0f
            var dragging = false

            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                if (!change.pressed) break
                tracker.addPointerInputChange(change)
                val delta = change.positionChange()

                if (!dragging) {
                    totalX += delta.x
                    totalY += delta.y
                    if (abs(totalY) > slop && abs(totalY) > abs(totalX)) {
                        dragging = true
                    } else if (abs(totalX) > slop) {
                        break // horizontal gesture: not ours
                    }
                }
                if (dragging) {
                    change.consume()
                    state.dispatchRawDelta(-delta.y)
                }
            }

            if (dragging) {
                val velocity = tracker.calculateVelocity().y
                scope.launch {
                    state.scroll { with(fling) { performFling(-velocity) } }
                }
            }
        }
    }
