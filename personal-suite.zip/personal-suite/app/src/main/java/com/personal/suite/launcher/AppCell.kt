package com.personal.suite.launcher

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.personal.suite.core.apps.AppIcon
import com.personal.suite.core.apps.LauncherItem
import com.personal.suite.core.apps.launchItem

data class CellAction(val label: String, val onClick: () -> Unit)

enum class CellStyle {
    /** Icon only, used in the home dock. */
    Dock,

    /** Translucent rounded card with icon and label, used in the drawer. */
    Card,
}

private val CardColor = Color(0xFF202020).copy(alpha = 0.75f)

/** Tap launches, long-press shows [actions]. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(
    item: LauncherItem,
    style: CellStyle,
    actions: List<CellAction>,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var menuOpen by remember { mutableStateOf(false) }
    val click = Modifier.combinedClickable(
        onClick = { context.launchItem(item) },
        onLongClick = { menuOpen = true },
    )

    Box(modifier) {
        when (style) {
            CellStyle.Dock -> Box(click.padding(6.dp)) {
                AppIcon(item, size = 44.dp)
            }
            CellStyle.Card -> Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CardColor)
                    .then(click)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AppIcon(item, size = 40.dp)
                Spacer(Modifier.width(12.dp))
                Text(
                    text = item.label,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            actions.forEach { action ->
                DropdownMenuItem(
                    text = { Text(action.label) },
                    onClick = {
                        menuOpen = false
                        action.onClick()
                    },
                )
            }
        }
    }
}
