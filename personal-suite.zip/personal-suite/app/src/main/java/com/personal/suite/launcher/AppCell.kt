package com.personal.suite.launcher

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.personal.suite.core.apps.AppIcon
import com.personal.suite.core.apps.LauncherItem
import com.personal.suite.core.apps.launchItem

data class CellAction(val label: String, val onClick: () -> Unit)

/** Icon + label. Tap launches, long-press shows [actions]. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(
    item: LauncherItem,
    onWallpaper: Boolean,
    actions: List<CellAction>,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var menuOpen by remember { mutableStateOf(false) }

    val labelStyle = if (onWallpaper) {
        MaterialTheme.typography.labelMedium.copy(
            color = Color.White,
            shadow = Shadow(Color.Black.copy(alpha = 0.7f), Offset(0f, 2f), 6f),
        )
    } else {
        MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurface)
    }

    Box(modifier) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .combinedClickable(
                    onClick = { context.launchItem(item) },
                    onLongClick = { menuOpen = true },
                )
                .padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AppIcon(item)
            Spacer(Modifier.height(4.dp))
            Text(
                text = item.label,
                style = labelStyle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            actions.forEach { action ->
                DropdownMenuItem(
                    text = { Text(action.label) },
                    onClick = {
                        menuOpen = false
                        action.onClick()
                    },
                )
            }
        }
    }
}
