package com.personal.suite.launcher

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Section letter of an app label: A-Z (any script), or '#' for digits and symbols. */
internal fun sectionLetter(label: String): Char =
    label.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() } ?: '#'

/**
 * Letter strip for jumping through the sorted app list. While a finger is down, [onActiveChange]
 * reports the letter under it; on release it reports null.
 */
@Composable
fun AlphabetScroller(
    letters: List<Char>,
    active: Char?,
    onActiveChange: (Char?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val currentLetters by rememberUpdatedState(letters)
    val currentOnChange by rememberUpdatedState(onActiveChange)

    Column(
        modifier = modifier
            .width(28.dp)
            .fillMaxHeight()
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    fun pick(y: Float) {
                        val all = currentLetters
                        if (all.isNotEmpty()) {
                            val index = (y / size.height * all.size).toInt().coerceIn(0, all.lastIndex)
                            currentOnChange(all[index])
                        }
                    }
                    pick(down.position.y)
                    down.consume()
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) break
                        pick(change.position.y)
                        change.consume()
                    }
                    currentOnChange(null)
                }
            },
    ) {
        letters.forEach { letter ->
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    text = letter.toString(),
                    style = TextStyle(
                        fontSize = if (letter == active) 14.sp else 11.sp,
                        fontWeight = if (letter == active) FontWeight.Bold else FontWeight.Normal,
                        color = if (letter == active) Color.White else Color.White.copy(alpha = 0.6f),
                    ),
                )
            }
        }
    }
}
