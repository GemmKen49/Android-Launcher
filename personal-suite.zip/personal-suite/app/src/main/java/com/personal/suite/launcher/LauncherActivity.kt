package com.personal.suite.launcher

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.prefs.SuitePrefs
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Home screen + app drawer. Declared singleTask: it is the root of the HOME task. */
class LauncherActivity : ComponentActivity() {

    private var drawerOpen by mutableStateOf(false)
    private var isHomeApp by mutableStateOf(false)
    private var isActive by mutableStateOf(false)
    private var homeTick by mutableIntStateOf(0)

    private val scope = MainScope()
    private lateinit var widgetHost: SuiteWidgetHost
    private var pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        isHomeApp = holdsHomeRole()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        widgetHost = SuiteWidgetHost(applicationContext)
        setContent {
            SuiteTheme {
                LauncherScreen(
                    drawerOpen = drawerOpen,
                    onDrawerOpenChange = { drawerOpen = it },
                    homeTick = homeTick,
                    isActive = isActive,
                    isDefaultHome = isHomeApp,
                    onRequestDefault = { homeRoleIntent()?.let { roleLauncher.launch(it) } },
                    onOpenSettings = { startActivity(Intent(this, SettingsActivity::class.java)) },
                    widgetHost = widgetHost,
                    onAddWidget = ::startAddWidget,
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        widgetHost.startListening()
    }

    override fun onStop() {
        widgetHost.stopListening()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        isActive = true
        isHomeApp = holdsHomeRole()
    }

    override fun onPause() {
        isActive = false
        super.onPause()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Pressing Home closes the drawer and scrolls back to the clock.
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            drawerOpen = false
            homeTick++
        }
    }

    // --- Adding a widget: allocate id -> bind (user consent) -> configure (if needed) -> save ---

    private fun startAddWidget(info: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        pendingWidgetId = id
        if (AppWidgetManager.getInstance(this).bindAppWidgetIdIfAllowed(id, info.provider)) {
            onWidgetBound(id)
        } else {
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQUEST_BIND)
        }
    }

    private fun onWidgetBound(id: Int) {
        val info = AppWidgetManager.getInstance(this).getAppWidgetInfo(id)
        if (info?.configure != null) {
            widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQUEST_CONFIGURE, null)
        } else {
            commitWidget(id)
        }
    }

    private fun commitWidget(id: Int) {
        pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
        scope.launch { SuitePrefs.get(applicationContext).addWidget(id) }
    }

    private fun cancelPendingWidget() {
        if (pendingWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            widgetHost.deleteAppWidgetId(pendingWidgetId)
            pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = pendingWidgetId
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return
        when (requestCode) {
            REQUEST_BIND -> if (resultCode == RESULT_OK) onWidgetBound(id) else cancelPendingWidget()
            REQUEST_CONFIGURE -> if (resultCode == RESULT_OK) commitWidget(id) else cancelPendingWidget()
        }
    }

    private companion object {
        const val REQUEST_BIND = 1
        const val REQUEST_CONFIGURE = 2
    }
}
