package com.personal.suite.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.personal.suite.core.design.SuiteTheme

/** Home screen + app drawer. Declared singleTask: it is the root of the HOME task. */
class LauncherActivity : ComponentActivity() {

    private var drawerOpen by mutableStateOf(false)
    private var isHomeApp by mutableStateOf(false)

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        isHomeApp = holdsHomeRole()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuiteTheme {
                LauncherScreen(
                    drawerOpen = drawerOpen,
                    onDrawerOpenChange = { drawerOpen = it },
                    isDefaultHome = isHomeApp,
                    onRequestDefault = { homeRoleIntent()?.let { roleLauncher.launch(it) } },
                    onOpenSettings = { startActivity(Intent(this, SettingsActivity::class.java)) },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Pressing Home while the drawer is open returns to the home screen.
        if (intent.hasCategory(Intent.CATEGORY_HOME)) drawerOpen = false
    }

    override fun onResume() {
        super.onResume()
        isHomeApp = holdsHomeRole()
    }
}
