package com.personal.suite.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.personal.suite.core.design.SuiteTheme

/** Home screen + app drawer. Declared singleTask: it is the root of the HOME task. */
class LauncherActivity : ComponentActivity() {

    private var isHomeApp by mutableStateOf(false)
    private var isActive by mutableStateOf(false)
    private var homeTick by mutableIntStateOf(0)

    private lateinit var widgetHost: SuiteWidgetHost

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        isHomeApp = holdsHomeRole()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        widgetHost = SuiteWidgetHost(applicationContext)
        setContent {
            SuiteTheme {
                LauncherScreen(
                    homeTick = homeTick,
                    isActive = isActive,
                    isDefaultHome = isHomeApp,
                    onRequestDefault = { homeRoleIntent()?.let { roleLauncher.launch(it) } },
                    onOpenSettings = { startActivity(Intent(this, SettingsActivity::class.java)) },
                    widgetHost = widgetHost,
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        widgetHost.startListening()
    }

    override fun onStop() {
        widgetHost.stopListening()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        isActive = true
        isHomeApp = holdsHomeRole()
    }

    override fun onPause() {
        isActive = false
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Pressing Home closes the drawer and scrolls back to the clock.
        if (intent.hasCategory(Intent.CATEGORY_HOME)) homeTick++
    }
}
