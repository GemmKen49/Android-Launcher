package com.personal.suite.launcher

import android.os.Bundle
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.personal.suite.core.prefs.WidgetPlacement

/**
 * Widgets below the first home page, in the columns and sizes chosen in Settings > Launcher > Widgets.
 * Long-press a widget to remove it. Adding widgets happens in Settings.
 */
@Composable
fun WidgetsSection(
    host: SuiteWidgetHost,
    placements: List<WidgetPlacement>,
    columns: Int,
    gapDp: Float,
    containerWidthDp: Float,
    onRemove: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var confirmRemove by remember { mutableStateOf<Int?>(null) }
    val slots = remember(placements, columns, containerWidthDp, gapDp) {
        resolveSlots(context, placements, columns, containerWidthDp, gapDp)
    }

    // Provider app was uninstalled: drop the widget.
    LaunchedEffect(slots) {
        slots.filter { it.info == null }.forEach { onRemove(it.placement.id) }
    }

    Box(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        WidgetGrid(
            slots = slots.filter { it.info != null },
            columns = columns,
            gap = gapDp.dp,
            containerWidth = containerWidthDp.dp,
        ) { slot, width ->
            key(slot.placement.id) {
                HostedWidget(host, slot, width, onLongPress = { confirmRemove = slot.placement.id })
            }
        }
    }

    confirmRemove?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmRemove = null },
            title = { Text("Remove widget?") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRemove = null
                    onRemove(id)
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun HostedWidget(host: SuiteWidgetHost, slot: WidgetSlot, width: Dp, onLongPress: () -> Unit) {
    val info = slot.info ?: return
    val widthDp = width.value.toInt()
    val heightDp = slot.height.value.toInt()
    val currentLongPress by rememberUpdatedState(onLongPress)

    AndroidView(
        factory = { ctx -> host.createView(ctx, slot.placement.id, info) },
        update = { view ->
            (view as? SuiteWidgetHostView)?.onLongPress = { currentLongPress() }
            view.updateAppWidgetSize(Bundle(), widthDp, heightDp, widthDp, heightDp)
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(slot.height)
            .clip(RoundedCornerShape(24.dp)),
    )
}
