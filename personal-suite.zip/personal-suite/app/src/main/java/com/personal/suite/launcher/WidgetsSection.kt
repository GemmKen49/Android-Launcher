package com.personal.suite.launcher

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

/** Widgets placed below the first home page. Long-press a widget to remove it. */
@Composable
fun WidgetsSection(
    host: SuiteWidgetHost,
    widgetIds: List<Int>,
    widthDp: Int,
    onAdd: (AppWidgetProviderInfo) -> Unit,
    onRemove: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var showPicker by remember { mutableStateOf(false) }
    var confirmRemove by remember { mutableStateOf<Int?>(null) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        widgetIds.forEach { id ->
            key(id) {
                WidgetItem(
                    host = host,
                    id = id,
                    widthDp = widthDp,
                    onLongPress = { confirmRemove = id },
                    onMissing = { onRemove(id) },
                )
            }
        }
        TextButton(
            onClick = { showPicker = true },
            colors = ButtonDefaults.textButtonColors(contentColor = Color.White),
        ) { Text("Add widget") }
    }

    if (showPicker) {
        WidgetPickerDialog(
            onPick = { info ->
                showPicker = false
                onAdd(info)
            },
            onDismiss = { showPicker = false },
        )
    }

    confirmRemove?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmRemove = null },
            title = { Text("Remove widget?") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRemove = null
                    onRemove(id)
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun WidgetItem(
    host: SuiteWidgetHost,
    id: Int,
    widthDp: Int,
    onLongPress: () -> Unit,
    onMissing: () -> Unit,
) {
    val context = LocalContext.current
    val info = remember(id) { AppWidgetManager.getInstance(context).getAppWidgetInfo(id) }

    if (info == null) {
        // Provider app was uninstalled: drop the widget.
        LaunchedEffect(id) { onMissing() }
    } else {
        val density = LocalDensity.current
        val height = with(density) { info.minHeight.toDp() }.coerceAtLeast(72.dp)
        val heightDp = height.value.toInt()
        val currentLongPress by rememberUpdatedState(onLongPress)

        AndroidView(
            factory = { ctx -> host.createView(ctx, id, info) },
            update = { view ->
                (view as? SuiteWidgetHostView)?.onLongPress = { currentLongPress() }
                view.updateAppWidgetSize(Bundle(), widthDp, heightDp, widthDp, heightDp)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(height)
                .clip(RoundedCornerShape(24.dp)),
        )
    }
}

private data class WidgetEntry(val info: AppWidgetProviderInfo, val label: String, val app: String)

@Composable
private fun WidgetPickerDialog(onPick: (AppWidgetProviderInfo) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val entries = remember {
        val pm = context.packageManager
        AppWidgetManager.getInstance(context).installedProviders
            .filter { (it.widgetCategory and AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN) != 0 }
            .map { WidgetEntry(it, it.loadLabel(pm).toString(), appLabel(pm, it.provider.packageName)) }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add widget") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(entries, key = { it.info.provider.flattenToString() }) { entry ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(entry.info) }
                            .padding(vertical = 8.dp),
                    ) {
                        Text(entry.label)
                        Text(entry.app, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

private fun appLabel(pm: PackageManager, packageName: String): String =
    try {
        pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        packageName
    }
