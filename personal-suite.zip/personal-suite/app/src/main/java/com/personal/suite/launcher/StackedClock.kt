package com.personal.suite.launcher

import android.text.format.DateFormat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.suite.core.prefs.Appearance
import com.personal.suite.core.prefs.LocalAppearance
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 3f), 10f)

/**
 * Hours / minutes / seconds stacked vertically, with the date underneath.
 * Everything (font, size, digit width, line gap, parts shown) comes from [LocalAppearance]. Ticks only while [active].
 */
@Composable
fun StackedClock(active: Boolean, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val appearance = LocalAppearance.current
    val is24Hour = remember { DateFormat.is24HourFormat(context) }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault()) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }

    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        while (true) {
            now = LocalDateTime.now()
            delay(1000 - System.currentTimeMillis() % 1000)
        }
    }

    val hour = if (is24Hour) now.hour else (now.hour % 12).let { if (it == 0) 12 else it }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(appearance.clockLineGap.dp),
    ) {
        ClockLine("%02d".format(hour), appearance.clockSize, appearance)
        ClockLine("%02d".format(now.minute), appearance.clockSize, appearance)
        if (appearance.clockShowSeconds) {
            ClockLine("%02d".format(now.second), appearance.clockSize * appearance.clockSecondsScale, appearance)
        }
        if (appearance.clockShowDate) {
            Text(
                text = now.format(dateFormatter),
                style = TextStyle(
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    shadow = shadow,
                ),
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

/**
 * One row of digits. With [Appearance.clockMonospace] each digit is centred in its own fixed-width
 * cell, so the digits never move each other as the time changes (works with any font).
 * The cell height is the digit height, so the vertical gap between rows is exactly the gap setting.
 */
@Composable
private fun ClockLine(text: String, size: Float, appearance: Appearance) {
    val density = LocalDensity.current
    val style = TextStyle(
        color = Color.White,
        fontFamily = if (appearance.clockMonospace) FontFamily.Monospace else FontFamily.SansSerif,
        fontWeight = FontWeight.Black,
        fontSize = size.sp,
        shadow = shadow,
    )
    val cellHeight = with(density) { (size * 0.78f).sp.toDp() }
    // Centre the glyphs even though the text box is taller than the cell.
    val glyph = Modifier.wrapContentSize(Alignment.Center, unbounded = true)

    if (appearance.clockMonospace) {
        val cellWidth = with(density) { (size * appearance.clockDigitWidth).sp.toDp() }
        Row {
            text.forEach { digit ->
                Box(Modifier.size(cellWidth, cellHeight)) {
                    Text(
                        text = digit.toString(),
                        style = style,
                        softWrap = false,
                        maxLines = 1,
                        overflow = TextOverflow.Visible,
                        modifier = glyph,
                    )
                }
            }
        }
    } else {
        Box(Modifier.height(cellHeight)) {
            Text(
                text = text,
                style = style,
                softWrap = false,
                maxLines = 1,
                overflow = TextOverflow.Visible,
                modifier = glyph,
            )
        }
    }
}
