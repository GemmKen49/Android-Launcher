package com.personal.suite.launcher

import android.text.format.DateFormat
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.personal.suite.core.prefs.LocalAppearance
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private fun clockStyle(family: FontFamily, size: TextUnit, lineHeight: TextUnit) = TextStyle(
    color = Color.White,
    fontFamily = family,
    fontWeight = FontWeight.Black,
    fontSize = size,
    lineHeight = lineHeight,
    textAlign = TextAlign.Center,
    shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 3f), 10f),
)

/**
 * Hours / minutes / seconds stacked vertically, with the date underneath.
 * Font, size, spacing and which parts show come from [LocalAppearance]. Ticks only while [active].
 */
@Composable
fun StackedClock(active: Boolean, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val appearance = LocalAppearance.current
    val is24Hour = remember { DateFormat.is24HourFormat(context) }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault()) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }

    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        while (true) {
            now = LocalDateTime.now()
            delay(1000 - System.currentTimeMillis() % 1000)
        }
    }

    val hour = if (is24Hour) now.hour else (now.hour % 12).let { if (it == 0) 12 else it }
    val family = if (appearance.clockMonospace) FontFamily.Monospace else FontFamily.SansSerif
    val size = appearance.clockSize
    val spacing = appearance.clockLineSpacing

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("%02d".format(hour), style = clockStyle(family, size.sp, (size * spacing).sp))
        Text("%02d".format(now.minute), style = clockStyle(family, size.sp, (size * spacing).sp))
        if (appearance.clockShowSeconds) {
            Text(
                text = "%02d".format(now.second),
                style = clockStyle(family, (size * 0.5f).sp, (size * 0.5f * spacing).sp),
            )
        }
        if (appearance.clockShowDate) {
            Text(
                text = now.format(dateFormatter),
                style = clockStyle(FontFamily.SansSerif, 14.sp, 20.sp).copy(fontWeight = FontWeight.Medium),
            )
        }
    }
}
