package com.personal.suite

import android.app.Application
import com.personal.suite.core.registry.AppRegistry
import com.personal.suite.feature.files.FilesApp
import com.personal.suite.feature.gallery.GalleryApp
import com.personal.suite.feature.music.MusicApp

class SuiteApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppRegistry.register(listOf(FilesApp, GalleryApp, MusicApp))
    }
}
