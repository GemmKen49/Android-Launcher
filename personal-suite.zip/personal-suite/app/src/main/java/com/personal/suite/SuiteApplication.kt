package com.personal.suite

import android.app.Application
import com.personal.suite.core.registry.AppRegistry
import com.personal.suite.core.search.AppsProvider
import com.personal.suite.core.search.PlaceholderSearchProvider
import com.personal.suite.core.search.SearchCategory
import com.personal.suite.core.search.SearchRegistry
import com.personal.suite.core.search.ShortcutsProvider
import com.personal.suite.feature.files.FilesApp
import com.personal.suite.feature.gallery.GalleryApp
import com.personal.suite.feature.music.MusicApp

class SuiteApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppRegistry.register(listOf(FilesApp, GalleryApp, MusicApp))

        SearchRegistry.register(AppsProvider(this))
        SearchRegistry.register(ShortcutsProvider(this))
        // Replace each placeholder with the feature's real provider when that feature is built.
        listOf(
            SearchCategory.Files,
            SearchCategory.Images,
            SearchCategory.Videos,
            SearchCategory.Music,
            SearchCategory.Documents,
        ).forEach { SearchRegistry.register(PlaceholderSearchProvider(it)) }
    }
}
