package com.personal.suite

import android.app.Application
import com.personal.suite.core.registry.AppRegistry
import com.personal.suite.core.search.AppsProvider
import com.personal.suite.core.search.PlaceholderSearchProvider
import com.personal.suite.core.search.SearchCategory
import com.personal.suite.core.search.SearchRegistry
import com.personal.suite.core.search.ShortcutsProvider
import com.personal.suite.feature.files.FilesApp
import com.personal.suite.feature.files.FilesSearchProvider
import com.personal.suite.feature.gallery.GalleryApp
import com.personal.suite.feature.gallery.GallerySearchProvider
import com.personal.suite.feature.documents.DocumentsApp
import com.personal.suite.feature.music.MusicApp
import com.personal.suite.feature.player.PlayerApp
import com.personal.suite.feature.terminal.TerminalApp

class SuiteApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppRegistry.register(listOf(FilesApp, GalleryApp, MusicApp, PlayerApp, DocumentsApp, TerminalApp))

        SearchRegistry.register(AppsProvider(this))
        SearchRegistry.register(ShortcutsProvider(this))
        SearchRegistry.register(FilesSearchProvider(this))
        SearchRegistry.register(GallerySearchProvider(this))
        // Replace each placeholder with the feature's real provider when that feature is built.
        listOf(
            SearchCategory.Videos,
            SearchCategory.Music,
            SearchCategory.Documents,
        ).forEach { SearchRegistry.register(PlaceholderSearchProvider(it)) }
    }
}
