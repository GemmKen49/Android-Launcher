package com.personal.suite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.design.TaskProbeScreen
import com.personal.suite.core.prefs.SuitePrefs
import com.personal.suite.core.prefs.ThemeMode
import kotlinx.coroutines.launch

/** Phase 1 hub: lists registered apps and exposes the shared theme setting. */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuiteTheme {
                val context = LocalContext.current
                val prefs = remember { SuitePrefs.get(context) }
                val scope = rememberCoroutineScope()
                val mode by prefs.themeMode.collectAsState(initial = ThemeMode.System)

                TaskProbeScreen(
                    activity = this,
                    title = "Suite hub",
                    launchMode = "standard (default task)",
                ) {
                    Button(onClick = { scope.launch { prefs.setThemeMode(mode.next()) } }) {
                        Text("Theme: $mode")
                    }
                }
            }
        }
    }
}
