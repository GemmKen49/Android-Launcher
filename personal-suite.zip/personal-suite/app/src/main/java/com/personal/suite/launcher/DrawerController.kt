package com.personal.suite.launcher

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.util.addPointerInputChange
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs

private const val FLING_VELOCITY = 800f // px/s

/**
 * Drawer position, 0 = closed, 1 = fully open. It follows the finger, so it can be held half open
 * or dragged back; on release it settles open or closed depending on position and fling speed.
 */
class DrawerController(private val scope: CoroutineScope) {

    var progress by mutableFloatStateOf(0f)
        private set

    private var job: Job? = null

    fun dragBy(fraction: Float) {
        job?.cancel()
        progress = (progress + fraction).coerceIn(0f, 1f)
    }

    fun release(velocityX: Float) {
        settle(
            when {
                velocityX < -FLING_VELOCITY -> true
                velocityX > FLING_VELOCITY -> false
                else -> progress >= 0.5f
            }
        )
    }

    fun settle(open: Boolean) {
        job?.cancel()
        job = scope.launch {
            animate(progress, if (open) 1f else 0f, animationSpec = tween(200)) { value, _ -> progress = value }
        }
    }
}

/**
 * Horizontal swipe that drives [controller] (swipe left opens, swipe right closes).
 * Ignores gestures a child already consumed (e.g. a vertical list scroll).
 */
fun Modifier.drawerSwipe(controller: DrawerController): Modifier = pointerInput(controller) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        val tracker = VelocityTracker()
        tracker.addPointerInputChange(down)
        val slop = viewConfiguration.touchSlop
        var totalX = 0f
        var totalY = 0f
        var dragging = false

        while (true) {
            val event = awaitPointerEvent()
            val change = event.changes.firstOrNull { it.id == down.id } ?: break
            if (change.isConsumed || !change.pressed) break
            tracker.addPointerInputChange(change)
            val delta = change.positionChange()

            if (!dragging) {
                totalX += delta.x
                totalY += delta.y
                if (abs(totalX) > slop && abs(totalX) > abs(totalY)) {
                    dragging = true
                } else if (abs(totalY) > slop) {
                    break // vertical gesture: not ours
                }
            }
            if (dragging) {
                change.consume()
                controller.dragBy(-delta.x / size.width)
            }
        }

        if (dragging) controller.release(tracker.calculateVelocity().x)
    }
}
