package com.personal.suite.launcher

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Process
import android.provider.Settings
import com.personal.suite.core.apps.AppCatalog
import com.personal.suite.core.apps.LauncherItem
import java.time.LocalDate
import java.time.ZoneId

/** One stretch of time an app was on screen. */
data class UsageSession(val start: Long, val end: Long) {
    val duration: Long get() = end - start
}

data class AppUsage(
    val key: String,
    val label: String,
    val item: LauncherItem,
    val total: Long,
    val sessions: List<UsageSession>,
)

/** Today's usage (since 00:00 local time), most-used app first. Apps under one second are left out. */
data class UsageSummary(val apps: List<AppUsage>, val dayStart: Long) {
    val totalMs: Long get() = apps.sumOf { it.total }
}

/** Last result, so a page can show something instantly. Only written while a page is actually displayed. */
object UsageCache {
    @Volatile
    var last: UsageSummary? = null
}

fun hasUsageAccess(context: Context): Boolean {
    val ops = context.getSystemService(AppOpsManager::class.java)
    val mode = ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}

fun Context.openUsageAccessSettings() {
    try {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName")))
    } catch (e: ActivityNotFoundException) {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }
}

fun formatDuration(ms: Long): String {
    val totalSeconds = ms / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return when {
        hours > 0 -> "${hours}h ${minutes}m"
        minutes > 0 -> "${minutes}m ${seconds}s"
        else -> "${seconds}s"
    }
}

/**
 * Builds today's usage from activity foreground events. Blocking: call off the main thread.
 *
 * - Only apps the launcher can list count; the launcher's own screens (home, settings) are ignored,
 *   but the suite's built-in apps (Files, Gallery, ...) count as separate apps.
 * - A session starts when an app's first activity resumes and ends when its last one pauses.
 *   Sessions less than 2 seconds apart are merged (switching screens inside an app).
 */
fun computeUsage(context: Context): UsageSummary {
    val zone = ZoneId.systemDefault()
    val dayStart = LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli()
    val now = System.currentTimeMillis()
    val manager = context.getSystemService(UsageStatsManager::class.java)
        ?: return UsageSummary(emptyList(), dayStart)

    val catalog = AppCatalog.get(context).items.value
    val byPackage = HashMap<String, LauncherItem>()
    catalog.filterIsInstance<LauncherItem.Installed>().forEach { byPackage.putIfAbsent(it.component.packageName, it) }
    val byClass = HashMap<String, LauncherItem>()
    catalog.filterIsInstance<LauncherItem.Internal>().forEach { byClass[it.entry.activityClassName] = it }
    val own = context.packageName

    val items = HashMap<String, LauncherItem>()
    val activeClasses = HashMap<String, MutableSet<String>>()
    val sessionStart = HashMap<String, Long>()
    val seen = HashSet<String>()
    val sessions = HashMap<String, MutableList<UsageSession>>()

    fun addSession(key: String, start: Long, end: Long) {
        if (end <= start) return
        val list = sessions.getOrPut(key) { mutableListOf() }
        val previous = list.lastOrNull()
        if (previous != null && start - previous.end <= 2000) {
            list[list.lastIndex] = UsageSession(previous.start, maxOf(previous.end, end))
        } else {
            list += UsageSession(start, end)
        }
    }

    val events = manager.queryEvents(dayStart, now)
    val event = UsageEvents.Event()
    while (events.hasNextEvent()) {
        events.getNextEvent(event)
        val type = event.eventType
        if (type != UsageEvents.Event.ACTIVITY_RESUMED &&
            type != UsageEvents.Event.ACTIVITY_PAUSED &&
            type != UsageEvents.Event.ACTIVITY_STOPPED
        ) continue

        val className = event.className ?: ""
        val item = (if (event.packageName == own) byClass[className] else byPackage[event.packageName]) ?: continue
        val key = item.key
        items[key] = item
        val time = event.timeStamp.coerceIn(dayStart, now)
        val classes = activeClasses.getOrPut(key) { mutableSetOf() }

        if (type == UsageEvents.Event.ACTIVITY_RESUMED) {
            if (classes.isEmpty()) sessionStart[key] = time
            classes.add(className)
            seen.add(key)
        } else {
            if (seen.add(key)) {
                // The first thing we see is a pause: the app was already open at midnight.
                sessionStart[key] = dayStart
                classes.add(className)
            }
            classes.remove(className)
            if (classes.isEmpty()) sessionStart.remove(key)?.let { addSession(key, it, time) }
        }
    }
    // Apps still open right now.
    for ((key, start) in sessionStart) {
        if (activeClasses[key].orEmpty().isNotEmpty()) addSession(key, start, now)
    }

    val apps = sessions.mapNotNull { (key, list) ->
        val item = items[key] ?: return@mapNotNull null
        val total = list.sumOf { it.duration }
        if (total < 1000) null else AppUsage(key, item.label, item, total, list.toList())
    }.sortedByDescending { it.total }

    return UsageSummary(apps, dayStart)
}
