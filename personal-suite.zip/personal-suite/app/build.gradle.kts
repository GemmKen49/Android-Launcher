import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.personal.suite"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.personal.suite"
        minSdk = 29
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Stable signing key so builds update over each other. Set by CI from GitHub secrets;
    // without these variables (e.g. local builds) the default debug key is used.
    signingConfigs {
        val keystorePath = System.getenv("SUITE_KEYSTORE_PATH")
        if (keystorePath != null) {
            create("suite") {
                storeFile = file(keystorePath)
                storePassword = System.getenv("SUITE_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("SUITE_KEY_ALIAS")
                keyPassword = System.getenv("SUITE_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfigs.findByName("suite")?.let { signingConfig = it }
        }
    }

    buildFeatures {
        compose = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation(project(":core"))
    implementation(project(":feature:files"))
    implementation(project(":feature:gallery"))
    implementation(project(":feature:music"))
}
