package com.personal.suite.feature.files

import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.ViewConfiguration
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.personal.suite.core.media.MediaDetailsScreen
import com.personal.suite.core.prefs.FilesPrefs
import com.personal.suite.core.prefs.SuitePrefs
import com.personal.suite.core.tabs.Tab
import com.personal.suite.core.tabs.TabsController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.file.Files
import java.text.DateFormat
import java.util.Date

private sealed interface PaneDialog {
    data class Rename(val file: File) : PaneDialog
    data object NewFolder : PaneDialog
    data class ConfirmDelete(val files: List<File>) : PaneDialog
    data class Properties(val entry: FileEntry) : PaneDialog
    data class Details(val file: File) : PaneDialog
}

private fun Set<String>.toggle(path: String): Set<String> = if (path in this) this - path else this + path

/**
 * One tab: a folder browser. The current folder is the tab's data (so it is saved with the session).
 * Long-press selects; selecting shows copy / cut / trash / more. Pasting goes into this pane's folder.
 */
@Composable
internal fun FilesPane(tab: Tab, roots: List<StorageRoot>, controller: TabsController, focused: Boolean) {
    val context = LocalContext.current
    val prefs = remember { SuitePrefs.get(context) }
    val filesPrefs by prefs.filesPrefs.collectAsState(initial = FilesPrefs())
    val changeTick by FileOps.changes.collectAsState()
    val clipboard by FileOps.clipboard.collectAsState()

    // The File settings decide how quickly the second tap of a double tap must land.
    val baseConfig = LocalViewConfiguration.current
    val tapConfig = remember(baseConfig, filesPrefs.doubleTapMs) {
        object : ViewConfiguration by baseConfig {
            override val doubleTapTimeoutMillis: Long = filesPrefs.doubleTapMs.toLong()
        }
    }

    val currentPath = tab.data
    val current = File(currentPath)
    val root = roots.rootOf(current) ?: roots.first()

    var selection by remember { mutableStateOf(emptySet<String>()) }
    var dialog by remember { mutableStateOf<PaneDialog?>(null) }
    var moreOpen by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    // Single tap on a file only highlights it; double tap opens it.
    var highlighted by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }

    fun navigate(path: String) {
        selection = emptySet()
        highlighted = null
        controller.update(tab.id, path)
    }

    // A restored tab may point at a folder that no longer exists: fall back to the nearest one that does.
    LaunchedEffect(currentPath) {
        if (!current.isDirectory) {
            navigate(generateSequence(current) { it.parentFile }.firstOrNull { it.isDirectory }?.path ?: root.dir.path)
        }
    }

    val listing by produceState<Listing>(Listing.Loading, currentPath, filesPrefs, changeTick) {
        value = withContext(Dispatchers.IO) { readDirectory(File(currentPath), filesPrefs) }
    }
    val entries = (listing as? Listing.Loaded)?.entries.orEmpty()
    val selectedFiles = entries.filter { it.path in selection }.map { it.file }

    // File and folder search below the current folder. null = still searching.
    val results by produceState<List<File>?>(null, query, currentPath, searchOpen) {
        if (!searchOpen || query.isBlank()) {
            value = emptyList()
            return@produceState
        }
        value = null
        delay(250)
        value = searchFiles(listOf(current), query.trim(), limit = 300, budgetMs = 8_000)
    }
    fun closeSearch() {
        searchOpen = false
        query = ""
    }

    // Back clears the selection first, then walks up; only the focused pane reacts.
    BackHandler(enabled = focused && (selection.isNotEmpty() || searchOpen || currentPath != root.dir.path)) {
        when {
            selection.isNotEmpty() -> selection = emptySet()
            searchOpen -> closeSearch()
            else -> navigate(current.parent ?: root.dir.path)
        }
    }

    val crumbs = remember(currentPath, root) {
        val relative = currentPath.removePrefix(root.dir.path).split('/').filter { it.isNotEmpty() }
        buildList {
            add(root.label to root.dir)
            var dir = root.dir
            relative.forEach { part ->
                dir = File(dir, part)
                add(part to dir)
            }
        }
    }

    CompositionLocalProvider(LocalViewConfiguration provides tapConfig) {
    Column(Modifier.fillMaxSize()) {
        if (selection.isEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LazyRow(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    itemsIndexed(crumbs) { index, (label, dir) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { navigate(dir.path) }) { Text(label) }
                            if (index < crumbs.lastIndex) Text("›")
                        }
                    }
                }
                TextButton(onClick = { if (searchOpen) closeSearch() else searchOpen = true }) { Text("Search") }
                TextButton(onClick = { dialog = PaneDialog.NewFolder }) { Text("+ Folder") }
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("${selection.size} selected", Modifier.padding(horizontal = 8.dp))
                TextButton(onClick = { selection = entries.map { it.path }.toSet() }) { Text("All") }
                TextButton(onClick = {
                    FileOps.clipboard.value = Clipboard(selectedFiles, cut = false)
                    selection = emptySet()
                }) { Text("Copy") }
                TextButton(onClick = {
                    FileOps.clipboard.value = Clipboard(selectedFiles, cut = true)
                    selection = emptySet()
                }) { Text("Cut") }
                TextButton(onClick = {
                    FileOps.trash(context, selectedFiles, roots)
                    selection = emptySet()
                }) { Text("Trash") }
                Box {
                    TextButton(onClick = { moreOpen = true }) { Text("More") }
                    DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                        if (selectedFiles.size == 1) {
                            DropdownMenuItem(
                                text = { Text("Rename") },
                                onClick = {
                                    moreOpen = false
                                    dialog = PaneDialog.Rename(selectedFiles.first())
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(if (selectedFiles.first().isDirectory) "Properties" else "Details") },
                                onClick = {
                                    moreOpen = false
                                    val target = selectedFiles.first()
                                    if (target.isDirectory) {
                                        entries.firstOrNull { it.path in selection }?.let { dialog = PaneDialog.Properties(it) }
                                    } else {
                                        dialog = PaneDialog.Details(target)
                                    }
                                },
                            )
                            if (selectedFiles.first().isFile) {
                                DropdownMenuItem(
                                    text = { Text("Open with other app") },
                                    onClick = {
                                        moreOpen = false
                                        context.openFile(selectedFiles.first())
                                    },
                                )
                            }
                        }
                        DropdownMenuItem(
                            text = { Text("Delete permanently") },
                            onClick = {
                                moreOpen = false
                                if (selectedFiles.isNotEmpty()) dialog = PaneDialog.ConfirmDelete(selectedFiles)
                            },
                        )
                    }
                }
                TextButton(onClick = { selection = emptySet() }) { Text("✕") }
            }
        }

        if (searchOpen && selection.isEmpty()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Search this folder and its subfolders") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (searchOpen && query.isNotBlank()) {
                val found = results
                when {
                    found == null -> Text("Searching…", Modifier.align(Alignment.Center))
                    found.isEmpty() -> Text("No matches", Modifier.align(Alignment.Center))
                    else -> LazyColumn(Modifier.fillMaxSize()) {
                        items(found, key = { it.path }) { file ->
                            SearchRow(
                                file = file,
                                base = current,
                                onClick = {
                                    if (file.isDirectory) {
                                        closeSearch()
                                        navigate(file.path)
                                    } else {
                                        context.openForView(file)
                                    }
                                },
                                // Long-press: jump to the folder that contains it.
                                onLongClick = {
                                    closeSearch()
                                    navigate(file.parent ?: root.dir.path)
                                },
                            )
                        }
                    }
                }
            } else when (val state = listing) {
                Listing.Loading -> Unit
                Listing.Unreadable -> Text("Can't read this folder", Modifier.align(Alignment.Center))
                is Listing.Loaded ->
                    if (state.entries.isEmpty()) {
                        Text("Empty folder", Modifier.align(Alignment.Center))
                    } else {
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(state.entries, key = { it.path }) { entry ->
                                FileRow(
                                    entry = entry,
                                    selected = entry.path in selection,
                                    highlighted = entry.path == highlighted,
                                    onClick = {
                                        when {
                                            selection.isNotEmpty() -> selection = selection.toggle(entry.path)
                                            entry.isDirectory -> navigate(entry.path)
                                            else -> highlighted = entry.path
                                        }
                                    },
                                    // Folders keep their single tap; a double tap only exists on files, outside selection mode.
                                    onDoubleClick = if (entry.isDirectory || selection.isNotEmpty()) {
                                        null
                                    } else {
                                        { context.openFileDoubleTap(entry.file, filesPrefs.doubleTapOpenWith) }
                                    },
                                    onLongClick = { selection = selection.toggle(entry.path) },
                                )
                            }
                        }
                    }
            }
        }

        clipboard?.let { clip ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.secondaryContainer)
                    .padding(horizontal = 12.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "${if (clip.cut) "Move" else "Copy"} ${clip.files.size} item(s)",
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { FileOps.paste(context, current) }) { Text("Paste here") }
                TextButton(onClick = { FileOps.clipboard.value = null }) { Text("Cancel") }
            }
        }
    }
    }

    when (val d = dialog) {
        null -> Unit
        is PaneDialog.Rename -> NameDialog(
            title = "Rename",
            initial = d.file.name,
            confirmLabel = "Rename",
            onConfirm = { name ->
                FileOps.rename(context, d.file, name)
                selection = emptySet()
                dialog = null
            },
            onDismiss = { dialog = null },
        )
        PaneDialog.NewFolder -> NameDialog(
            title = "New folder",
            initial = "",
            confirmLabel = "Create",
            onConfirm = { name ->
                FileOps.newFolder(context, current, name)
                dialog = null
            },
            onDismiss = { dialog = null },
        )
        is PaneDialog.ConfirmDelete -> ConfirmDialog(
            title = "Delete permanently?",
            message = "${d.files.size} item(s) will be deleted for good. This can't be undone.",
            confirmLabel = "Delete",
            onConfirm = {
                FileOps.deleteForever(context, d.files)
                selection = emptySet()
                dialog = null
            },
            onDismiss = { dialog = null },
        )
        is PaneDialog.Properties -> PropertiesDialog(entry = d.entry, onDismiss = { dialog = null })
        is PaneDialog.Details -> DetailsDialog(file = d.file, onDismiss = { dialog = null })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRow(
    entry: FileEntry,
    selected: Boolean,
    highlighted: Boolean,
    onClick: () -> Unit,
    onDoubleClick: (() -> Unit)?,
    onLongClick: () -> Unit,
) {
    val context = LocalContext.current
    val date = remember(entry.modified) {
        DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(entry.modified))
    }
    val subtitle = if (entry.isDirectory) date else "${Formatter.formatShortFileSize(context, entry.size)} · $date"

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                when {
                    selected -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    highlighted -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                    else -> Color.Transparent
                }
            )
            .combinedClickable(onClick = onClick, onDoubleClick = onDoubleClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painter = painterResource(if (entry.isDirectory) R.drawable.ic_folder else R.drawable.ic_file),
            contentDescription = null,
            modifier = Modifier.size(36.dp),
        )
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (selected) Text("✓", style = MaterialTheme.typography.titleMedium)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SearchRow(file: File, base: File, onClick: () -> Unit, onLongClick: () -> Unit) {
    val relative = file.parentFile?.path?.removePrefix(base.path)?.trimStart('/').orEmpty()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painter = painterResource(if (file.isDirectory) R.drawable.ic_folder else R.drawable.ic_file),
            contentDescription = null,
            modifier = Modifier.size(36.dp),
        )
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(file.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                text = relative.ifEmpty { "In this folder" },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** Full-screen details (file info, and for images camera, location and all EXIF tags). Same screen as the Gallery's. */
@Composable
private fun DetailsDialog(file: File, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.windowInsetsPadding(WindowInsets.systemBars)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = file.name,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = onDismiss) { Text("Close") }
                }
                HorizontalDivider()
                MediaDetailsScreen(file, Modifier.weight(1f))
            }
        }
    }
}

private data class FolderStats(val size: Long, val items: Int)

@Composable
private fun PropertiesDialog(entry: FileEntry, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val modified = remember(entry.modified) {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(entry.modified))
    }
    // Folder size needs a walk of the whole tree: do it in the background, and stop if the dialog closes.
    val folderStats by produceState<FolderStats?>(null, entry.path) {
        if (entry.isDirectory) {
            value = withContext(Dispatchers.IO) {
                var size = 0L
                var count = 0
                val walk = entry.file.walkTopDown().onEnter { !Files.isSymbolicLink(it.toPath()) }
                for (file in walk) {
                    ensureActive()
                    if (file != entry.file) count++
                    if (file.isFile) size += file.length()
                }
                FolderStats(size, count)
            }
        }
    }

    val type = if (entry.isDirectory) "Folder" else mimeTypeOf(entry.file) ?: "File"
    val size = if (entry.isDirectory) {
        folderStats?.let { Formatter.formatFileSize(context, it.size) } ?: "Calculating…"
    } else {
        Formatter.formatFileSize(context, entry.size)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(entry.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PropertyRow("Location", entry.file.parent ?: "/")
                PropertyRow("Type", type)
                PropertyRow("Size", size)
                if (entry.isDirectory) {
                    PropertyRow("Contains", folderStats?.let { "${it.items} items" } ?: "Calculating…")
                }
                PropertyRow("Modified", modified)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun PropertyRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value)
    }
}

@Composable
internal fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = { onConfirm(text.trim()) }, enabled = text.isNotBlank()) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Used for everything irreversible. Never skipped. */
@Composable
internal fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
