package com.personal.suite.feature.files

import android.os.StatFs
import android.text.format.Formatter
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.File

/** Storage volumes with usage, plus shortcuts to the usual folders. Tapping one opens it in the Files page. */
@Composable
internal fun StoragePage(roots: List<StorageRoot>, onOpenPath: (String) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val primary = roots.first().dir
    val shortcuts = remember(primary) {
        listOf("Download", "DCIM", "Pictures", "Movies", "Music", "Documents")
            .map { File(primary, it) }
            .filter { it.isDirectory }
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(roots, key = { it.dir.path }) { storage ->
            val stats = remember(storage) {
                runCatching { StatFs(storage.dir.path).let { it.totalBytes to it.availableBytes } }.getOrNull()
            }
            Card(Modifier.fillMaxWidth().clickable { onOpenPath(storage.dir.path) }) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(storage.label, style = MaterialTheme.typography.titleMedium)
                    if (stats != null) {
                        val (total, free) = stats
                        val used = total - free
                        LinearProgressIndicator(
                            progress = { if (total > 0) used.toFloat() / total else 0f },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Text(
                            text = "${Formatter.formatFileSize(context, used)} used of " +
                                "${Formatter.formatFileSize(context, total)} · ${Formatter.formatFileSize(context, free)} free",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
        item { Text("Quick access", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp)) }
        items(shortcuts, key = { it.path }) { dir ->
            Card(Modifier.fillMaxWidth().clickable { onOpenPath(dir.path) }) {
                Text(dir.name, Modifier.padding(16.dp))
            }
        }
    }
}
