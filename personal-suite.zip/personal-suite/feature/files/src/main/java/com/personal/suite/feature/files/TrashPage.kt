package com.personal.suite.feature.files

import android.text.format.Formatter
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

private sealed interface TrashConfirm {
    data class Delete(val items: List<TrashItem>) : TrashConfirm
    data object Empty : TrashConfirm
}

/** Deleted files from every volume. Restore is instant; anything permanent asks first. */
@Composable
internal fun TrashPage(roots: List<StorageRoot>, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val changeTick by FileOps.changes.collectAsState()
    val trashItems by produceState(emptyList<TrashItem>(), changeTick) {
        value = withContext(Dispatchers.IO) { FileOps.listTrash(roots) }
    }
    var selected by remember { mutableStateOf(emptySet<String>()) }
    var confirm by remember { mutableStateOf<TrashConfirm?>(null) }

    LaunchedEffect(trashItems) {
        selected = selected.filter { id -> trashItems.any { it.id == id } }.toSet()
    }
    val selectedItems = trashItems.filter { it.id in selected }

    Column(modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(
                onClick = {
                    FileOps.restore(context, selectedItems)
                    selected = emptySet()
                },
                enabled = selectedItems.isNotEmpty(),
            ) { Text("Restore") }
            TextButton(
                onClick = { confirm = TrashConfirm.Delete(selectedItems) },
                enabled = selectedItems.isNotEmpty(),
            ) { Text("Delete permanently") }
            TextButton(
                onClick = { confirm = TrashConfirm.Empty },
                enabled = trashItems.isNotEmpty(),
            ) { Text("Empty trashcan") }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (trashItems.isEmpty()) {
                Text("Trashcan is empty", Modifier.align(Alignment.Center))
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(trashItems, key = { it.id }) { item ->
                        TrashRow(
                            item = item,
                            selected = item.id in selected,
                            onClick = {
                                selected = if (item.id in selected) selected - item.id else selected + item.id
                            },
                        )
                    }
                }
            }
        }
    }

    when (val c = confirm) {
        null -> Unit
        is TrashConfirm.Delete -> ConfirmDialog(
            title = "Delete permanently?",
            message = "${c.items.size} item(s) will be deleted for good. This can't be undone.",
            confirmLabel = "Delete",
            onConfirm = {
                FileOps.deleteTrashItems(context, c.items)
                selected = emptySet()
                confirm = null
            },
            onDismiss = { confirm = null },
        )
        TrashConfirm.Empty -> ConfirmDialog(
            title = "Empty trashcan?",
            message = "All ${trashItems.size} item(s) will be deleted for good. This can't be undone.",
            confirmLabel = "Empty",
            onConfirm = {
                FileOps.emptyTrash(context, roots)
                selected = emptySet()
                confirm = null
            },
            onDismiss = { confirm = null },
        )
    }
}

@Composable
private fun TrashRow(item: TrashItem, selected: Boolean, onClick: () -> Unit) {
    val context = LocalContext.current
    val date = remember(item.deletedAt) {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(item.deletedAt))
    }
    val size = if (item.size >= 0) Formatter.formatShortFileSize(context, item.size) else "Folder"

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                text = "$size · $date",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = "From " + (File(item.originalPath).parent ?: "/"),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (selected) Text("✓", style = MaterialTheme.typography.titleMedium)
    }
}
