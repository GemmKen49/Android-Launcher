package com.personal.suite.feature.files

import android.content.Context
import android.media.MediaScannerConnection
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** Files waiting to be pasted. Shared by all tabs and panes, so you can copy from one pane into the other. */
data class Clipboard(val files: List<File>, val cut: Boolean)

internal class OpOutcome(val ok: Int, val failed: Int, val touched: List<String>)

/** A file in the trashcan. It lives in `<volume>/.SuiteTrash/<id>` with its details in `<id>.meta`. */
internal data class TrashItem(
    val id: String,
    val payload: File,
    val meta: File,
    val originalPath: String,
    val deletedAt: Long,
    val name: String,
    val isDirectory: Boolean,
    val size: Long, // -1 for folders
)

private const val TRASH_DIR = ".SuiteTrash"

/**
 * All file changes run here on an app-wide scope (so rotating or leaving the screen can't cut a copy short),
 * report back through [busy] / [changes], and refresh the media library for touched paths.
 */
internal object FileOps {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Label of the running operation (shown as a progress dialog), or null. */
    val busy = MutableStateFlow<String?>(null)

    /** Bumped after every change; listings reload when it changes. */
    val changes = MutableStateFlow(0)

    val clipboard = MutableStateFlow<Clipboard?>(null)

    private fun start(context: Context, busyLabel: String?, work: () -> OpOutcome) {
        val app = context.applicationContext
        scope.launch {
            if (busyLabel != null) busy.value = busyLabel
            val outcome = try {
                work()
            } catch (e: Exception) {
                OpOutcome(0, 1, emptyList())
            }
            if (outcome.touched.isNotEmpty()) {
                MediaScannerConnection.scanFile(app, outcome.touched.take(300).toTypedArray(), null, null)
            }
            changes.value += 1
            busy.value = null
            withContext(Dispatchers.Main) {
                val text = buildString {
                    append(outcome.ok).append(" done")
                    if (outcome.failed > 0) append(", ").append(outcome.failed).append(" failed")
                }
                Toast.makeText(app, text, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun batch(files: List<File>, destination: File?, op: (File) -> Boolean): OpOutcome {
        var ok = 0
        var failed = 0
        val touched = mutableListOf<String>()
        for (file in files) {
            if (op(file)) {
                ok++
                touched += file.path
                if (destination != null) touched += File(destination, file.name).path
            } else {
                failed++
            }
        }
        return OpOutcome(ok, failed, touched)
    }

    // ---- helpers ----

    private fun uniqueTarget(dir: File, name: String, isDirectory: Boolean): File {
        val first = File(dir, name)
        if (!first.exists()) return first
        val parsed = File(name)
        val base = if (isDirectory) name else parsed.nameWithoutExtension
        val extension = if (isDirectory || parsed.extension.isEmpty()) "" else "." + parsed.extension
        var index = 1
        while (true) {
            val candidate = File(dir, "$base ($index)$extension")
            if (!candidate.exists()) return candidate
            index++
        }
    }

    private fun isInside(child: File, parent: File) = child.path == parent.path || child.path.startsWith(parent.path + "/")

    private fun copyInto(src: File, dstDir: File): Boolean {
        if (isInside(dstDir, src)) return false // a folder can't be copied into itself
        val target = uniqueTarget(dstDir, src.name, src.isDirectory)
        return try {
            src.copyRecursively(target, overwrite = false)
        } catch (e: Exception) {
            false
        }
    }

    /** Rename when possible (instant); otherwise copy then delete (other volume). */
    private fun moveFile(src: File, target: File): Boolean {
        if (src.renameTo(target)) return true
        return try {
            src.copyRecursively(target, overwrite = false) && src.deleteRecursively()
        } catch (e: Exception) {
            false
        }
    }

    private fun moveInto(src: File, dstDir: File): Boolean {
        if (src.parentFile?.path == dstDir.path) return true // already there
        if (isInside(dstDir, src)) return false
        return moveFile(src, uniqueTarget(dstDir, src.name, src.isDirectory))
    }

    private fun trashOne(file: File, roots: List<StorageRoot>): Boolean {
        val root = roots.rootOf(file) ?: return false
        val dir = File(root.dir, TRASH_DIR)
        if (isInside(file, dir)) return false
        if (!dir.isDirectory && !dir.mkdirs()) return false
        runCatching { File(dir, ".nomedia").let { if (!it.exists()) it.createNewFile() } }
        val id = UUID.randomUUID().toString()
        val meta = File(dir, "$id.meta")
        meta.writeText("${file.path}\n${System.currentTimeMillis()}\n${file.name}")
        if (moveFile(file, File(dir, id))) return true
        meta.delete()
        return false
    }

    // ---- operations ----

    fun paste(context: Context, destination: File) {
        val clip = clipboard.value ?: return
        start(context, if (clip.cut) "Moving…" else "Copying…") {
            val outcome = batch(clip.files, destination) {
                if (clip.cut) moveInto(it, destination) else copyInto(it, destination)
            }
            if (clip.cut) clipboard.value = null
            outcome
        }
    }

    fun trash(context: Context, files: List<File>, roots: List<StorageRoot>) =
        start(context, "Moving to trash…") { batch(files, null) { trashOne(it, roots) } }

    fun deleteForever(context: Context, files: List<File>) =
        start(context, "Deleting…") { batch(files, null) { it.deleteRecursively() } }

    fun rename(context: Context, file: File, newName: String) = start(context, null) {
        val parent = file.parentFile
        val valid = parent != null && newName.isNotBlank() && '/' !in newName
        val target = if (valid) File(parent, newName) else null
        val ok = target != null && !target.exists() && file.renameTo(target)
        OpOutcome(if (ok) 1 else 0, if (ok) 0 else 1, listOf(file.path, target?.path ?: file.path))
    }

    fun newFolder(context: Context, parent: File, name: String) = start(context, null) {
        val valid = name.isNotBlank() && '/' !in name
        val folder = File(parent, name)
        val ok = valid && !folder.exists() && folder.mkdir()
        OpOutcome(if (ok) 1 else 0, if (ok) 0 else 1, listOf(folder.path))
    }

    // ---- trashcan ----

    /** Blocking: call off the main thread. */
    fun listTrash(roots: List<StorageRoot>): List<TrashItem> =
        roots.flatMap { root ->
            val dir = File(root.dir, TRASH_DIR)
            dir.listFiles { file -> file.name.endsWith(".meta") }.orEmpty().mapNotNull { meta ->
                val id = meta.name.removeSuffix(".meta")
                val payload = File(dir, id)
                val lines = runCatching { meta.readLines() }.getOrNull()
                if (!payload.exists() || lines == null || lines.size < 3) {
                    null
                } else {
                    TrashItem(
                        id = id,
                        payload = payload,
                        meta = meta,
                        originalPath = lines[0],
                        deletedAt = lines[1].toLongOrNull() ?: 0L,
                        name = lines[2],
                        isDirectory = payload.isDirectory,
                        size = if (payload.isFile) payload.length() else -1L,
                    )
                }
            }
        }.sortedByDescending { it.deletedAt }

    fun restore(context: Context, items: List<TrashItem>) = start(context, "Restoring…") {
        var ok = 0
        var failed = 0
        val touched = mutableListOf<String>()
        for (item in items) {
            val original = File(item.originalPath)
            val parent = original.parentFile
            if (parent != null && (parent.isDirectory || parent.mkdirs())) {
                val target = uniqueTarget(parent, original.name, item.isDirectory)
                if (moveFile(item.payload, target)) {
                    item.meta.delete()
                    ok++
                    touched += target.path
                } else {
                    failed++
                }
            } else {
                failed++
            }
        }
        OpOutcome(ok, failed, touched)
    }

    private fun purge(items: List<TrashItem>): OpOutcome {
        var ok = 0
        var failed = 0
        for (item in items) {
            if (item.payload.deleteRecursively()) {
                item.meta.delete()
                ok++
            } else {
                failed++
            }
        }
        return OpOutcome(ok, failed, emptyList())
    }

    /** Permanent. The UI must confirm first. */
    fun deleteTrashItems(context: Context, items: List<TrashItem>) =
        start(context, "Deleting…") { purge(items) }

    /** Permanent. The UI must confirm first. */
    fun emptyTrash(context: Context, roots: List<StorageRoot>) =
        start(context, "Emptying trashcan…") { purge(listTrash(roots)) }
}
