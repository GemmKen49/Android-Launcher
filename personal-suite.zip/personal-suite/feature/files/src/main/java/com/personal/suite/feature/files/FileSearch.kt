package com.personal.suite.feature.files

import android.content.Context
import com.personal.suite.core.search.SearchCategory
import com.personal.suite.core.search.SearchProvider
import com.personal.suite.core.search.SearchResult
import com.personal.suite.core.search.matchScore
import com.personal.suite.core.storage.canManageAllFiles
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.file.Files

private fun shouldSkip(dir: File): Boolean {
    val path = dir.path
    return dir.name == ".SuiteTrash" ||
        path.endsWith("/Android/data") ||
        path.endsWith("/Android/obb") ||
        Files.isSymbolicLink(dir.toPath())
}

/**
 * Files and folders under [dirs] whose name contains [query] (case-insensitive). Stops at [limit] results
 * or after [budgetMs], and is cancelled promptly when the query changes.
 */
internal suspend fun searchFiles(dirs: List<File>, query: String, limit: Int, budgetMs: Long): List<File> =
    withContext(Dispatchers.IO) {
        val needle = query.lowercase()
        val deadline = System.nanoTime() + budgetMs * 1_000_000
        val found = ArrayList<File>()
        for (dir in dirs) {
            for (file in dir.walkTopDown().onEnter { !shouldSkip(it) }) {
                ensureActive()
                if (file != dir && file.name.lowercase().contains(needle)) {
                    found += file
                    if (found.size >= limit) return@withContext found
                }
                if (System.nanoTime() > deadline) return@withContext found
            }
        }
        found
    }

/**
 * Unified-search source for the Files filter. Opening a result goes through the File Manager:
 * folders open in a new tab, files open in the text editor or the matching app.
 */
class FilesSearchProvider(private val context: Context) : SearchProvider {
    override val id = "files"
    override val category = SearchCategory.Files
    override val shownByDefault = false
    override val isAvailable: Boolean get() = canManageAllFiles()

    override suspend fun search(query: String): List<SearchResult> {
        val q = query.trim()
        if (q.length < 2) return emptyList() // don't walk storage for a single letter
        return searchFiles(context.storageRoots().map { it.dir }, q, limit = 50, budgetMs = 1500).map { file ->
            SearchResult(
                key = "file:${file.path}",
                title = file.name,
                typeLabel = if (file.isDirectory) "Folder" else "File",
                subtitle = file.parent,
                score = matchScore(q, file.name),
                open = { ctx -> ctx.openInFiles(file) },
            )
        }
    }
}
