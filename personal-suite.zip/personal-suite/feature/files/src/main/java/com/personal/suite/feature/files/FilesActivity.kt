package com.personal.suite.feature.files

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.res.stringResource
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.design.TaskProbeScreen
import com.personal.suite.core.registry.AppEntry

/** Registry entry; :app collects these. */
val FilesApp = AppEntry(
    id = "files",
    labelRes = R.string.feature_files_label,
    iconRes = R.drawable.ic_files,
    activityClassName = FilesActivity::class.java.name,
)

/** Phase 1 placeholder, real UI comes in a later phase. */
class FilesActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuiteTheme {
                TaskProbeScreen(
                    activity = this,
                    title = stringResource(FilesApp.labelRes),
                    launchMode = "standard + NEW_TASK + own affinity",
                    currentId = FilesApp.id,
                )
            }
        }
    }
}
