package com.personal.suite.feature.files

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.registry.AppEntry

/** Registry entry; :app collects these. */
val FilesApp = AppEntry(
    id = "files",
    labelRes = R.string.feature_files_label,
    iconRes = R.drawable.ic_files,
    activityClassName = FilesActivity::class.java.name,
)

class FilesActivity : ComponentActivity() {

    private var hasAccess by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuiteTheme {
                FilesScreen(
                    hasAccess = hasAccess,
                    onRequestAccess = { requestAllFilesAccess() },
                    // Closing the last tab closes the window and removes it from Recents.
                    onAllTabsClosed = { finishAndRemoveTask() },
                )
            }
        }
    }

    // The user grants access in system settings, so re-check every time we come back.
    override fun onResume() {
        super.onResume()
        hasAccess = canManageAllFiles()
    }
}
