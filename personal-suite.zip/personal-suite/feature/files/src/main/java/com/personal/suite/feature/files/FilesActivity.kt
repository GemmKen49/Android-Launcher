package com.personal.suite.feature.files

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.registry.AppEntry
import com.personal.suite.core.storage.canManageAllFiles
import com.personal.suite.core.storage.requestAllFilesAccess

/** Registry entry; :app collects these. */
val FilesApp = AppEntry(
    id = "files",
    labelRes = R.string.feature_files_label,
    iconRes = R.drawable.ic_files,
    activityClassName = FilesActivity::class.java.name,
)

/** singleTop, so a search result can hand this already-open window a path through onNewIntent. */
class FilesActivity : ComponentActivity() {

    private var hasAccess by mutableStateOf(false)
    private var openRequest by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Only the first creation: a rotation must not re-open the same folder.
        if (savedInstanceState == null) openRequest = intent.getStringExtra(EXTRA_OPEN)
        setContent {
            SuiteTheme {
                FilesScreen(
                    hasAccess = hasAccess,
                    onRequestAccess = { requestAllFilesAccess() },
                    // Closing the last tab closes the window and removes it from Recents.
                    onAllTabsClosed = { finishAndRemoveTask() },
                    openRequest = openRequest,
                    onOpenRequestHandled = { openRequest = null },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra(EXTRA_OPEN)?.let { openRequest = it }
    }

    // The user grants access in system settings, so re-check every time we come back.
    override fun onResume() {
        super.onResume()
        hasAccess = canManageAllFiles()
    }
}
