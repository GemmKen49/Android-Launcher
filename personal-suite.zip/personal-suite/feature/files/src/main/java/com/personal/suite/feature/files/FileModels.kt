package com.personal.suite.feature.files

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import com.personal.suite.core.prefs.FilesPrefs
import com.personal.suite.core.prefs.SortBy
import com.personal.suite.core.tabs.Tab
import java.io.File

data class StorageRoot(val label: String, val dir: File)

data class FileEntry(val file: File, val isDirectory: Boolean, val size: Long, val modified: Long) {
    val name: String get() = file.name
    val path: String get() = file.path
}

internal sealed interface Listing {
    data object Loading : Listing
    data object Unreadable : Listing
    data class Loaded(val entries: List<FileEntry>) : Listing
}

/** The volume a path lives on (longest matching root). */
internal fun List<StorageRoot>.rootOf(file: File): StorageRoot? =
    filter { file.path == it.dir.path || file.path.startsWith(it.dir.path + "/") }
        .maxByOrNull { it.dir.path.length }

/** Tab title: the volume name at a volume's top, otherwise the folder name. */
internal fun tabTitle(tab: Tab, roots: List<StorageRoot>): String {
    val file = File(tab.data)
    return roots.firstOrNull { it.dir.path == file.path }?.label ?: file.name.ifEmpty { "/" }
}

/** Sorted by the user's quick settings. Blocking: call off the main thread. */
internal fun readDirectory(dir: File, prefs: FilesPrefs): Listing {
    val children = dir.listFiles() ?: return Listing.Unreadable
    val entries = children.asSequence()
        .filter { prefs.showHidden || !it.name.startsWith(".") }
        .map { FileEntry(it, it.isDirectory, if (it.isFile) it.length() else 0L, it.lastModified()) }
        .toList()

    val byField: Comparator<FileEntry> = when (prefs.sortBy) {
        SortBy.Name -> compareBy<FileEntry, String>(String.CASE_INSENSITIVE_ORDER) { it.name }
        SortBy.Date -> compareBy<FileEntry> { it.modified }
        SortBy.Size -> compareBy<FileEntry> { it.size }
    }
    val ordered = if (prefs.descending) byField.reversed() else byField
    val comparator = if (prefs.foldersFirst) compareBy<FileEntry> { !it.isDirectory }.then(ordered) else ordered
    return Listing.Loaded(entries.sortedWith(comparator))
}

/** Internal storage plus any mounted removable volume (SD card, USB). */
@Suppress("DEPRECATION")
fun Context.storageRoots(): List<StorageRoot> {
    val manager = getSystemService(StorageManager::class.java)
    val roots = manager.storageVolumes
        .filter { it.state == Environment.MEDIA_MOUNTED }
        .mapNotNull { volume ->
            val dir = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                volume.directory
            } else if (volume.isPrimary) {
                Environment.getExternalStorageDirectory()
            } else {
                null
            }
            dir?.let { StorageRoot(if (volume.isPrimary) "Internal storage" else volume.getDescription(this), it) }
        }
    return roots.ifEmpty { listOf(StorageRoot("Internal storage", Environment.getExternalStorageDirectory())) }
}

/** The File Manager needs "All files access", which only exists on Android 11+. */
fun canManageAllFiles(): Boolean =
    Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()

fun supportsAllFilesAccess(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

fun Context.requestAllFilesAccess() {
    try {
        startActivity(
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
        )
    } catch (e: ActivityNotFoundException) {
        startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
    }
}

fun mimeTypeOf(file: File): String? =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase())

fun Context.openFile(file: File) {
    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, mimeTypeOf(file) ?: "*/*")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(this, "No app can open ${file.name}", Toast.LENGTH_SHORT).show()
    }
}

/** Extra for FilesActivity: a path to show (folder -> new tab, file -> editor or matching app). */
const val EXTRA_OPEN = "com.personal.suite.files.OPEN"

internal const val MAX_EDIT_BYTES = 512L * 1024

private val TEXT_EXTENSIONS = setOf(
    "txt", "md", "markdown", "json", "xml", "html", "htm", "css", "js", "ts", "kt", "kts", "java", "py", "sh",
    "bash", "log", "csv", "tsv", "ini", "conf", "cfg", "yaml", "yml", "properties", "gradle", "toml", "c", "h",
    "cpp", "hpp", "rs", "go", "sql", "srt", "tex",
)

/** Small text-like files open in the built-in editor. */
internal fun isEditableText(file: File): Boolean {
    if (!file.isFile || file.length() > MAX_EDIT_BYTES) return false
    return file.extension.lowercase() in TEXT_EXTENSIONS || mimeTypeOf(file)?.startsWith("text/") == true
}

/** Text files open in the editor (inside the Files task); everything else in the app that handles it. */
fun Context.openForView(file: File) {
    if (isEditableText(file)) {
        startActivity(Intent(this, TextEditorActivity::class.java).putExtra(TextEditorActivity.EXTRA_PATH, file.path))
    } else {
        openFile(file)
    }
}

/** Opens the File Manager on [file] from anywhere in the suite (used by search results). */
fun Context.openInFiles(file: File) {
    startActivity(
        Intent(this, FilesActivity::class.java)
            .putExtra(EXTRA_OPEN, file.path)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}
