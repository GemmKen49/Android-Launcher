package com.personal.suite.feature.files

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

data class StorageRoot(val label: String, val dir: File)

data class FileEntry(val file: File, val isDirectory: Boolean, val size: Long, val modified: Long) {
    val name: String get() = file.name
    val path: String get() = file.path
}

internal sealed interface Listing {
    data object Loading : Listing
    data object Unreadable : Listing
    data class Loaded(val entries: List<FileEntry>) : Listing
}

/** Folders first, then names, case-insensitive. Blocking: call off the main thread. */
internal fun readDirectory(dir: File, showHidden: Boolean): Listing {
    val children = dir.listFiles() ?: return Listing.Unreadable
    val entries = children.asSequence()
        .filter { showHidden || !it.name.startsWith(".") }
        .map { FileEntry(it, it.isDirectory, if (it.isFile) it.length() else 0L, it.lastModified()) }
        .sortedWith(compareBy<FileEntry>({ !it.isDirectory }).thenBy(String.CASE_INSENSITIVE_ORDER) { it.name })
        .toList()
    return Listing.Loaded(entries)
}

/** Internal storage plus any mounted removable volume (SD card, USB). */
@Suppress("DEPRECATION")
fun Context.storageRoots(): List<StorageRoot> {
    val manager = getSystemService(StorageManager::class.java)
    val roots = manager.storageVolumes
        .filter { it.state == Environment.MEDIA_MOUNTED }
        .mapNotNull { volume ->
            val dir = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                volume.directory
            } else if (volume.isPrimary) {
                Environment.getExternalStorageDirectory()
            } else {
                null
            }
            dir?.let { StorageRoot(if (volume.isPrimary) "Internal storage" else volume.getDescription(this), it) }
        }
    return roots.ifEmpty { listOf(StorageRoot("Internal storage", Environment.getExternalStorageDirectory())) }
}

/** The File Manager needs "All files access", which only exists on Android 11+. */
fun canManageAllFiles(): Boolean =
    Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()

fun supportsAllFilesAccess(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

fun Context.requestAllFilesAccess() {
    try {
        startActivity(
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
        )
    } catch (e: ActivityNotFoundException) {
        startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
    }
}

fun mimeTypeOf(file: File): String? =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase())

fun Context.openFile(file: File) {
    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, mimeTypeOf(file) ?: "*/*")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(this, "No app can open ${file.name}", Toast.LENGTH_SHORT).show()
    }
}
