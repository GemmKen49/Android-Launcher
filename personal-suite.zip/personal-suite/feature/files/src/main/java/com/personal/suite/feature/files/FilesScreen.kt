package com.personal.suite.feature.files

import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.personal.suite.core.prefs.SuitePrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.file.Files
import java.text.DateFormat
import java.util.Date

@Composable
fun FilesScreen(hasAccess: Boolean, onRequestAccess: () -> Unit) {
    if (hasAccess) Browser() else PermissionScreen(onRequestAccess)
}

@Composable
private fun PermissionScreen(onRequestAccess: () -> Unit) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("All files access needed", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.size(12.dp))
            if (supportsAllFilesAccess()) {
                Text(
                    "Files browses and manages your storage directly. Allow \"All files access\" for this app in system settings, then come back.",
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.size(24.dp))
                Button(onClick = onRequestAccess) { Text("Open settings") }
            } else {
                Text("The file manager needs Android 11 or newer.", textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun Browser() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { SuitePrefs.get(context) }
    val roots = remember { context.storageRoots() }
    val showHidden by prefs.showHiddenFiles.collectAsState(initial = false)

    var currentPath by rememberSaveable { mutableStateOf(roots.first().dir.path) }
    var propertiesFor by remember { mutableStateOf<FileEntry?>(null) }

    val current = File(currentPath)
    val root = roots.firstOrNull { currentPath == it.dir.path || currentPath.startsWith(it.dir.path + "/") }
        ?: roots.first()

    val listing by produceState<Listing>(Listing.Loading, currentPath, showHidden) {
        value = Listing.Loading
        value = withContext(Dispatchers.IO) { readDirectory(File(currentPath), showHidden) }
    }

    // Back walks up the folder tree; at the top of a volume it leaves the app.
    BackHandler(enabled = currentPath != root.dir.path) {
        currentPath = current.parent ?: root.dir.path
    }

    val crumbs = remember(currentPath, root) {
        val relative = currentPath.removePrefix(root.dir.path).split('/').filter { it.isNotEmpty() }
        buildList {
            add(root.label to root.dir)
            var dir = root.dir
            relative.forEach { part ->
                dir = File(dir, part)
                add(part to dir)
            }
        }
    }

    Scaffold { padding ->
        Column(Modifier.padding(padding)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 12.dp, top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Files", style = MaterialTheme.typography.headlineSmall)
                FilterChip(
                    selected = showHidden,
                    onClick = { scope.launch { prefs.setShowHiddenFiles(!showHidden) } },
                    label = { Text("Hidden files") },
                )
            }

            if (roots.size > 1) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(roots, key = { it.dir.path }) { storage ->
                        FilterChip(
                            selected = storage == root,
                            onClick = { currentPath = storage.dir.path },
                            label = { Text(storage.label) },
                        )
                    }
                }
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                itemsIndexed(crumbs) { index, (label, dir) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { currentPath = dir.path }) { Text(label) }
                        if (index < crumbs.lastIndex) Text("›")
                    }
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (val state = listing) {
                    Listing.Loading -> Unit
                    Listing.Unreadable -> Text("Can't read this folder", Modifier.align(Alignment.Center))
                    is Listing.Loaded ->
                        if (state.entries.isEmpty()) {
                            Text("Empty folder", Modifier.align(Alignment.Center))
                        } else {
                            LazyColumn(Modifier.fillMaxSize()) {
                                items(state.entries, key = { it.path }) { entry ->
                                    FileRow(
                                        entry = entry,
                                        onClick = {
                                            if (entry.isDirectory) currentPath = entry.path else context.openFile(entry.file)
                                        },
                                        onLongClick = { propertiesFor = entry },
                                    )
                                }
                            }
                        }
                }
            }
        }
    }

    propertiesFor?.let { entry ->
        PropertiesDialog(entry = entry, onDismiss = { propertiesFor = null })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRow(entry: FileEntry, onClick: () -> Unit, onLongClick: () -> Unit) {
    val context = LocalContext.current
    val date = remember(entry.modified) {
        DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(entry.modified))
    }
    val subtitle = if (entry.isDirectory) date else "${Formatter.formatShortFileSize(context, entry.size)} · $date"

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painter = painterResource(if (entry.isDirectory) R.drawable.ic_folder else R.drawable.ic_file),
            contentDescription = null,
            modifier = Modifier.size(36.dp),
        )
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private data class FolderStats(val size: Long, val items: Int)

@Composable
private fun PropertiesDialog(entry: FileEntry, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val modified = remember(entry.modified) {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(entry.modified))
    }
    // Folder size needs a walk of the whole tree: do it in the background, and stop if the dialog closes.
    val folderStats by produceState<FolderStats?>(null, entry.path) {
        if (entry.isDirectory) {
            value = withContext(Dispatchers.IO) {
                var size = 0L
                var count = 0
                val walk = entry.file.walkTopDown().onEnter { !Files.isSymbolicLink(it.toPath()) }
                for (file in walk) {
                    ensureActive()
                    if (file != entry.file) count++
                    if (file.isFile) size += file.length()
                }
                FolderStats(size, count)
            }
        }
    }

    val type = if (entry.isDirectory) "Folder" else mimeTypeOf(entry.file) ?: "File"
    val size = if (entry.isDirectory) {
        folderStats?.let { Formatter.formatFileSize(context, it.size) } ?: "Calculating…"
    } else {
        Formatter.formatFileSize(context, entry.size)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(entry.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PropertyRow("Location", entry.file.parent ?: "/")
                PropertyRow("Type", type)
                PropertyRow("Size", size)
                if (entry.isDirectory) {
                    PropertyRow("Contains", folderStats?.let { "${it.items} items" } ?: "Calculating…")
                }
                PropertyRow("Modified", modified)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun PropertyRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value)
    }
}
