package com.personal.suite.feature.files

import androidx.annotation.DrawableRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.personal.suite.core.prefs.FilesPrefs
import com.personal.suite.core.prefs.SortBy
import com.personal.suite.core.prefs.SuitePrefs
import com.personal.suite.core.tabs.TabStrip
import com.personal.suite.core.tabs.TabbedContent
import com.personal.suite.core.tabs.rememberTabsController
import kotlinx.coroutines.launch

private enum class FilesPage(val label: String, @DrawableRes val icon: Int) {
    Files("Files", R.drawable.ic_nav_files),
    Storage("Storage", R.drawable.ic_nav_storage),
    Trash("Trashcan", R.drawable.ic_nav_trash),
}

@Composable
fun FilesScreen(hasAccess: Boolean, onRequestAccess: () -> Unit, onAllTabsClosed: () -> Unit) {
    if (hasAccess) FilesShell(onAllTabsClosed) else PermissionScreen(onRequestAccess)
}

@Composable
private fun PermissionScreen(onRequestAccess: () -> Unit) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("All files access needed", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.size(12.dp))
            if (supportsAllFilesAccess()) {
                Text(
                    "Files browses and manages your storage directly. Allow \"All files access\" for this app in system settings, then come back.",
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.size(24.dp))
                Button(onClick = onRequestAccess) { Text("Open settings") }
            } else {
                Text("The file manager needs Android 11 or newer.", textAlign = TextAlign.Center)
            }
        }
    }
}

/** Tabs (Files page only) + quick settings on top, the active page, and the bottom navigation. */
@Composable
private fun FilesShell(onAllTabsClosed: () -> Unit) {
    val context = LocalContext.current
    val roots = remember { context.storageRoots() }
    val controller = rememberTabsController(
        key = "files",
        newTabData = { roots.first().dir.path },
        onAllClosed = onAllTabsClosed,
    )
    var page by rememberSaveable { mutableStateOf(FilesPage.Files) }
    val busy by FileOps.busy.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar {
                FilesPage.entries.forEach { entry ->
                    NavigationBarItem(
                        selected = page == entry,
                        onClick = { page = entry },
                        icon = { Icon(painterResource(entry.icon), contentDescription = null) },
                        label = { Text(entry.label) },
                    )
                }
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (page == FilesPage.Files && controller != null) {
                    TabStrip(
                        controller = controller,
                        title = { tabTitle(it, roots) },
                        modifier = Modifier.weight(1f),
                    )
                } else {
                    Text(
                        text = page.label,
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 16.dp, top = 8.dp, bottom = 8.dp),
                    )
                }
                QuickSettings()
            }

            when (page) {
                FilesPage.Files ->
                    if (controller != null) {
                        TabbedContent(controller, Modifier.weight(1f)) { tab, focused ->
                            FilesPane(tab = tab, roots = roots, controller = controller, focused = focused)
                        }
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                FilesPage.Storage -> StoragePage(
                    roots = roots,
                    onOpenPath = { path ->
                        controller?.let { it.update(it.activeId, path) }
                        page = FilesPage.Files
                    },
                    modifier = Modifier.weight(1f),
                )
                FilesPage.Trash -> TrashPage(roots = roots, modifier = Modifier.weight(1f))
            }
        }
    }

    busy?.let { label ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(label) },
            text = { LinearProgressIndicator(Modifier.fillMaxWidth()) },
            confirmButton = {},
        )
    }
}

/** Top-right menu: hidden files and sorting. Stays open so several can be changed at once. */
@Composable
private fun QuickSettings() {
    val context = LocalContext.current
    val prefs = remember { SuitePrefs.get(context) }
    val scope = rememberCoroutineScope()
    val filesPrefs by prefs.filesPrefs.collectAsState(initial = FilesPrefs())
    var open by remember { mutableStateOf(false) }

    fun update(change: FilesPrefs.() -> FilesPrefs) {
        scope.launch { prefs.setFilesPrefs(filesPrefs.change()) }
    }

    Box {
        Text(
            text = "⚙",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier
                .clickable { open = true }
                .padding(horizontal = 16.dp, vertical = 10.dp),
        )
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            CheckItem("Show hidden files", filesPrefs.showHidden) { update { copy(showHidden = !showHidden) } }
            HorizontalDivider()
            SortBy.entries.forEach { sort ->
                CheckItem("Sort by ${sort.name.lowercase()}", filesPrefs.sortBy == sort) { update { copy(sortBy = sort) } }
            }
            CheckItem("Descending", filesPrefs.descending) { update { copy(descending = !descending) } }
            CheckItem("Folders first", filesPrefs.foldersFirst) { update { copy(foldersFirst = !foldersFirst) } }
        }
    }
}

@Composable
private fun CheckItem(label: String, checked: Boolean, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(label) },
        leadingIcon = { Text(if (checked) "✓" else " ") },
        onClick = onClick,
    )
}
