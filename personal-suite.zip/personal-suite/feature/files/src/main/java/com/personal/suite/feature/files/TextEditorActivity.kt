package com.personal.suite.feature.files

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.suite.core.design.SuiteTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Simple plain-text editor opened from the File Manager. Not a code editor: just edit and save. */
class TextEditorActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val path = intent.getStringExtra(EXTRA_PATH)
        if (path == null) {
            finish()
            return
        }
        setContent {
            SuiteTheme { TextEditorScreen(file = File(path), onClose = { finish() }) }
        }
    }

    companion object {
        const val EXTRA_PATH = "path"
    }
}

@Composable
private fun TextEditorScreen(file: File, onClose: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var original by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmClose by remember { mutableStateOf(false) }
    val dirty = original != null && text != original

    LaunchedEffect(file) {
        val result = withContext(Dispatchers.IO) {
            runCatching { if (file.length() > MAX_EDIT_BYTES) null else file.readText() }
        }
        val content = result.getOrNull()
        when {
            result.isFailure -> error = "Can't read this file"
            content == null -> error = "This file is too large to edit here"
            else -> {
                original = content
                text = content
            }
        }
    }

    suspend fun persist(): Boolean {
        val snapshot = text
        val ok = withContext(Dispatchers.IO) { runCatching { file.writeText(snapshot) }.isSuccess }
        if (ok) original = snapshot
        Toast.makeText(context, if (ok) "Saved" else "Couldn't save", Toast.LENGTH_SHORT).show()
        return ok
    }

    BackHandler(enabled = dirty) { confirmClose = true }

    Scaffold { padding ->
        Column(Modifier.padding(padding)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = file.name + if (dirty) " •" else "",
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { scope.launch { persist() } }, enabled = dirty) { Text("Save") }
                TextButton(onClick = { if (dirty) confirmClose = true else onClose() }) { Text("Close") }
            }
            HorizontalDivider()

            val problem = error
            when {
                problem != null -> Text(problem, Modifier.padding(24.dp))
                original == null -> Text("Loading…", Modifier.padding(24.dp))
                else -> BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    val viewport = maxHeight
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        BasicTextField(
                            value = text,
                            onValueChange = { text = it },
                            textStyle = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                            ),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = viewport)
                                .padding(12.dp),
                        )
                    }
                }
            }
        }
    }

    if (confirmClose) {
        AlertDialog(
            onDismissRequest = { confirmClose = false },
            title = { Text("Unsaved changes") },
            text = { Text("Save before closing?") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        if (persist()) onClose() else {
                            confirmClose = false
                        }
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = onClose) { Text("Discard") } },
        )
    }
}
