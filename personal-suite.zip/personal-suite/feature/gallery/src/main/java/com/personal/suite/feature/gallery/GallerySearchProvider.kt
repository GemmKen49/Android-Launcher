package com.personal.suite.feature.gallery

import android.content.Context
import com.personal.suite.core.registry.launchAppWithPath
import com.personal.suite.core.search.SearchCategory
import com.personal.suite.core.search.SearchProvider
import com.personal.suite.core.search.SearchResult
import com.personal.suite.core.search.matchScore
import com.personal.suite.core.storage.canManageAllFiles
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Unified-search source for the Images filter. Opening a result shows it in the Gallery. */
class GallerySearchProvider(private val context: Context) : SearchProvider {
    override val id = "images"
    override val category = SearchCategory.Images
    override val shownByDefault = false
    override val isAvailable: Boolean get() = canManageAllFiles()

    override suspend fun search(query: String): List<SearchResult> {
        val q = query.trim()
        if (q.length < 2) return emptyList()
        return withContext(Dispatchers.IO) { queryImages(context, nameLike = q, limit = 50) }.map { image ->
            SearchResult(
                key = "image:${image.path}",
                title = image.name,
                typeLabel = "Image",
                subtitle = File(image.path).parent,
                score = matchScore(q, image.name),
                open = { ctx -> ctx.launchAppWithPath("gallery", image.path) },
            )
        }
    }
}
