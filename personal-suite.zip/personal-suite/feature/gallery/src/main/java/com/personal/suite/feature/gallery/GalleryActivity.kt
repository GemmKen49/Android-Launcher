package com.personal.suite.feature.gallery

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.registry.AppEntry
import com.personal.suite.core.registry.EXTRA_OPEN_PATH
import com.personal.suite.core.storage.canManageAllFiles
import com.personal.suite.core.storage.requestAllFilesAccess

/** Registry entry; :app collects these. */
val GalleryApp = AppEntry(
    id = "gallery",
    labelRes = R.string.feature_gallery_label,
    iconRes = R.drawable.ic_gallery,
    activityClassName = GalleryActivity::class.java.name,
)

/** singleTask: a file path sent from another app (e.g. a double tap in Files) arrives through onNewIntent. */
class GalleryActivity : ComponentActivity() {

    private var hasAccess by mutableStateOf(false)
    private var resumeTick by mutableIntStateOf(0)
    private var openPath by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) openPath = intent.getStringExtra(EXTRA_OPEN_PATH)
        setContent {
            SuiteTheme {
                GalleryScreen(
                    hasAccess = hasAccess,
                    onRequestAccess = { requestAllFilesAccess() },
                    resumeTick = resumeTick,
                    openPath = openPath,
                    onOpenHandled = { openPath = null },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra(EXTRA_OPEN_PATH)?.let { openPath = it }
    }

    override fun onResume() {
        super.onResume()
        hasAccess = canManageAllFiles()
        resumeTick++
    }
}
