package com.personal.suite.feature.gallery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.res.stringResource
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.design.TaskProbeScreen
import com.personal.suite.core.registry.AppEntry

/** Registry entry; :app collects these. */
val GalleryApp = AppEntry(
    id = "gallery",
    labelRes = R.string.feature_gallery_label,
    iconRes = R.drawable.ic_gallery,
    activityClassName = GalleryActivity::class.java.name,
)

/** Phase 1 placeholder, real UI comes in a later phase. */
class GalleryActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuiteTheme {
                TaskProbeScreen(
                    activity = this,
                    title = stringResource(GalleryApp.labelRes),
                    launchMode = "singleTask + NEW_TASK + own affinity",
                    currentId = GalleryApp.id,
                )
            }
        }
    }
}
