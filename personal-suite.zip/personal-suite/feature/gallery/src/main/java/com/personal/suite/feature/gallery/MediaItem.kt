package com.personal.suite.feature.gallery

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val path: String,
    val name: String,
    val dateMs: Long,
    val width: Int,
    val height: Int,
    val size: Long,
    val mime: String,
    val bucketId: Long,
    val bucketName: String,
)

/**
 * Images on the device (MediaStore), newest first. [nameLike] keeps only names containing the text,
 * [limit] stops early. Blocking: call off the main thread.
 */
internal fun queryImages(context: Context, nameLike: String? = null, limit: Int = Int.MAX_VALUE): List<MediaItem> {
    val images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Images.Media._ID,
        MediaStore.Images.Media.DISPLAY_NAME,
        MediaStore.Images.Media.DATE_TAKEN,
        MediaStore.Images.Media.DATE_MODIFIED,
        MediaStore.Images.Media.SIZE,
        MediaStore.Images.Media.WIDTH,
        MediaStore.Images.Media.HEIGHT,
        MediaStore.Images.Media.MIME_TYPE,
        MediaStore.Images.Media.BUCKET_ID,
        MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
        MediaStore.Images.Media.DATA,
    )
    // The File Manager's trashcan folder must not show up as an album.
    val selection = buildString {
        append("${MediaStore.Images.Media.DATA} NOT LIKE ?")
        if (nameLike != null) append(" AND ${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?")
    }
    val args = if (nameLike != null) arrayOf("%/.SuiteTrash/%", "%$nameLike%") else arrayOf("%/.SuiteTrash/%")

    val result = ArrayList<MediaItem>()
    context.contentResolver.query(images, projection, selection, args, null)?.use { cursor ->
        val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
        val takenColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
        val modifiedColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)
        val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
        val widthColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
        val heightColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
        val mimeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
        val bucketIdColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
        val bucketColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
        val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)

        while (cursor.moveToNext() && result.size < limit) {
            val taken = cursor.getLong(takenColumn)
            val date = if (taken > 0) taken else cursor.getLong(modifiedColumn) * 1000
            val id = cursor.getLong(idColumn)
            result += MediaItem(
                id = id,
                uri = ContentUris.withAppendedId(images, id),
                path = cursor.getString(dataColumn).orEmpty(),
                name = cursor.getString(nameColumn).orEmpty(),
                dateMs = date,
                width = cursor.getInt(widthColumn),
                height = cursor.getInt(heightColumn),
                size = cursor.getLong(sizeColumn),
                mime = cursor.getString(mimeColumn).orEmpty(),
                bucketId = cursor.getLong(bucketIdColumn),
                bucketName = cursor.getString(bucketColumn).orEmpty().ifEmpty { "Unknown" },
            )
        }
    }
    return result.filter { it.path.isNotEmpty() }.sortedByDescending { it.dateMs }
}
