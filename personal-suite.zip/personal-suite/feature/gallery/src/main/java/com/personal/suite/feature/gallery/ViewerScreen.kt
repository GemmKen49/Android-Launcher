package com.personal.suite.feature.gallery

import android.content.Context
import android.content.Intent
import android.graphics.ImageDecoder
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.util.addPointerInputChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.personal.suite.core.media.MediaDetailsScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date
import kotlin.math.abs
import kotlin.math.roundToInt

internal data class ViewerRequest(val items: List<MediaItem>, val index: Int)

/** Position of the details sheet: 0 = hidden, 1 = fully up. It follows the finger. */
internal class SheetController(private val scope: CoroutineScope) {

    var progress by mutableFloatStateOf(0f)
        private set

    private var job: Job? = null

    fun dragBy(fraction: Float) {
        job?.cancel()
        progress = (progress + fraction).coerceIn(0f, 1f)
    }

    fun release(velocityY: Float, openThreshold: Float = 0.4f) {
        settle(
            when {
                velocityY < -800f -> true
                velocityY > 800f -> false
                else -> progress >= openThreshold
            }
        )
    }

    fun settle(open: Boolean) {
        job?.cancel()
        job = scope.launch {
            animate(progress, if (open) 1f else 0f, animationSpec = tween(220)) { value, _ -> progress = value }
        }
    }
}

/** Swipe up anywhere (when [enabled]) to bring the details sheet up; swipe down on the free part to send it back. */
private fun Modifier.sheetSwipe(controller: SheetController, enabled: () -> Boolean): Modifier =
    pointerInput(controller) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            if (!enabled()) return@awaitEachGesture
            val tracker = VelocityTracker()
            tracker.addPointerInputChange(down)
            val slop = viewConfiguration.touchSlop
            var totalX = 0f
            var totalY = 0f
            var dragging = false

            while (true) {
                val event = awaitPointerEvent()
                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                if (change.isConsumed || !change.pressed) break
                tracker.addPointerInputChange(change)
                val delta = change.positionChange()
                if (!dragging) {
                    totalX += delta.x
                    totalY += delta.y
                    if (abs(totalY) > slop && abs(totalY) > abs(totalX)) {
                        dragging = true
                    } else if (abs(totalX) > slop) {
                        break // horizontal: that is the pager's
                    }
                }
                if (dragging) {
                    change.consume()
                    controller.dragBy(-delta.y / (size.height * 0.6f))
                }
            }
            if (dragging) controller.release(tracker.calculateVelocity().y)
        }
    }

/**
 * Full-screen viewer over [items]. Swipe sideways for the next image, pinch or double-tap to zoom,
 * tap to hide the bars, swipe up for the details and metadata.
 */
@Composable
internal fun Viewer(items: List<MediaItem>, startIndex: Int, onClose: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val sheet = remember { SheetController(scope) }
    val pagerState = rememberPagerState(initialPage = startIndex.coerceIn(0, items.lastIndex)) { items.size }
    var barsVisible by remember { mutableStateOf(true) }
    var zoomedPage by remember { mutableIntStateOf(-1) }
    val zoomed = zoomedPage == pagerState.currentPage
    // The gesture block outlives recompositions, so it must read the latest value through State.
    val zoomedNow by rememberUpdatedState(zoomed)
    val sheetOpen by remember { derivedStateOf { sheet.progress > 0f } }

    BackHandler { if (sheetOpen) sheet.settle(false) else onClose() }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .sheetSwipe(sheet) { !zoomedNow },
    ) {
        HorizontalPager(
            state = pagerState,
            userScrollEnabled = !zoomed && !sheetOpen,
            beyondViewportPageCount = 1,
            key = { page -> items[page].path },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    // The image lifts and shrinks as the details come up.
                    translationY = -sheet.progress * size.height * 0.18f
                    val scale = 1f - 0.15f * sheet.progress
                    scaleX = scale
                    scaleY = scale
                },
        ) { page ->
            ZoomableImage(
                item = items[page],
                onZoomChanged = { isZoomed ->
                    if (isZoomed) zoomedPage = page else if (zoomedPage == page) zoomedPage = -1
                },
                onTap = { barsVisible = !barsVisible },
            )
        }

        val current = items[pagerState.currentPage]

        if (barsVisible && !sheetOpen) {
            TopBar(
                item = current,
                onBack = onClose,
                onInfo = { sheet.settle(true) },
                onShare = { share(context, current) },
                modifier = Modifier.align(Alignment.TopCenter),
            )
        }

        if (sheetOpen) DetailsSheet(item = current, sheet = sheet)
    }
}

@Composable
private fun TopBar(item: MediaItem, onBack: () -> Unit, onInfo: () -> Unit, onShare: () -> Unit, modifier: Modifier) {
    val date = remember(item.dateMs) {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(item.dateMs))
    }
    val white = ButtonDefaults.textButtonColors(contentColor = Color.White)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.65f), Color.Transparent)))
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        TextButton(onClick = onBack, colors = white) { Text("‹ Back") }
        Column(Modifier.weight(1f)) {
            Text(item.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
            Text(date, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
        }
        TextButton(onClick = onInfo, colors = white) { Text("Info") }
        TextButton(onClick = onShare, colors = white) { Text("Share") }
    }
}

/** The details sheet: the same screen the File Manager shows. Drag its header down to put it away. */
@Composable
private fun BoxScope.DetailsSheet(item: MediaItem, sheet: SheetController) {
    val density = LocalDensity.current
    val screenHeightPx = with(density) { LocalConfiguration.current.screenHeightDp.dp.toPx() }

    Surface(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .fillMaxHeight(0.82f)
            .graphicsLayer { translationY = (1f - sheet.progress) * size.height },
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        color = MaterialTheme.colorScheme.surface,
    ) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onVerticalDrag = { _, dy -> sheet.dragBy(-dy / (screenHeightPx * 0.6f)) },
                            onDragEnd = { sheet.release(0f, openThreshold = 0.8f) },
                            onDragCancel = { sheet.release(0f, openThreshold = 0.8f) },
                        )
                    }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(width = 40.dp, height = 4.dp)
                        .background(MaterialTheme.colorScheme.outline, RoundedCornerShape(2.dp)),
                )
            }
            MediaDetailsScreen(File(item.path), Modifier.weight(1f))
        }
    }
}

/**
 * One image. Pinch (two fingers) or double-tap to zoom; once zoomed, one finger pans.
 * At normal size one-finger drags are left alone so swiping to the next image and up for details still work.
 */
@Composable
private fun ZoomableImage(item: MediaItem, onZoomChanged: (Boolean) -> Unit, onTap: () -> Unit) {
    // Start with the cached thumbnail, then swap in the sharp decode.
    val bitmap by produceState<ImageBitmap?>(ThumbCache.cache.get(item.id), item.path) {
        val full = withContext(Dispatchers.IO) { decodeScaled(item.path, 2560) }
        if (full != null) value = full
    }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var box by remember { mutableStateOf(IntSize.Zero) }

    fun transform(zoomChange: Float, pan: Offset, centroid: Offset) {
        val old = scale
        val new = (old * zoomChange).coerceIn(1f, 6f)
        val cx = centroid.x - box.width / 2f
        val cy = centroid.y - box.height / 2f
        val ratio = new / old
        val maxX = box.width * (new - 1f) / 2f
        val maxY = box.height * (new - 1f) / 2f
        offsetX = (cx - ratio * (cx - offsetX) + pan.x).coerceIn(-maxX, maxX)
        offsetY = (cy - ratio * (cy - offsetY) + pan.y).coerceIn(-maxY, maxY)
        scale = new
        onZoomChanged(new > 1.01f)
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { box = it }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { point ->
                        if (scale > 1.01f) {
                            scale = 1f
                            offsetX = 0f
                            offsetY = 0f
                            onZoomChanged(false)
                        } else {
                            transform(2.5f, Offset.Zero, point)
                        }
                    },
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.count { it.pressed }
                        if (pressed >= 2 || scale > 1.01f) {
                            val zoomChange = event.calculateZoom()
                            val pan = event.calculatePan()
                            val centroid = event.calculateCentroid(useCurrent = false)
                            if (centroid != Offset.Unspecified) transform(zoomChange, pan, centroid)
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
    ) {
        bitmap?.let {
            Image(
                bitmap = it,
                contentDescription = item.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offsetX
                        translationY = offsetY
                    },
            )
        }
    }
}

/** Decodes with the right orientation, shrunk so the longest side is at most [maxSide]. */
private fun decodeScaled(path: String, maxSide: Int): ImageBitmap? =
    try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(File(path))) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val longest = maxOf(info.size.width, info.size.height)
            if (longest > maxSide) {
                val factor = maxSide.toFloat() / longest
                decoder.setTargetSize(
                    (info.size.width * factor).roundToInt().coerceAtLeast(1),
                    (info.size.height * factor).roundToInt().coerceAtLeast(1),
                )
            }
        }.asImageBitmap()
    } catch (e: Exception) {
        null
    }

private fun share(context: Context, item: MediaItem) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(item.path))
    val send = Intent(Intent.ACTION_SEND)
        .setType(item.mime.ifEmpty { "image/*" })
        .putExtra(Intent.EXTRA_STREAM, uri)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    context.startActivity(Intent.createChooser(send, null))
}
