package com.personal.suite.feature.gallery

import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.activity.compose.BackHandler
import androidx.annotation.DrawableRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.personal.suite.core.prefs.LocalAppearance
import com.personal.suite.core.storage.AllFilesAccessScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private enum class GalleryPage(val label: String, @DrawableRes val icon: Int) {
    Photos("Photos", R.drawable.ic_nav_photos),
    Albums("Albums", R.drawable.ic_nav_albums),
}

@Composable
fun GalleryScreen(
    hasAccess: Boolean,
    onRequestAccess: () -> Unit,
    resumeTick: Int,
    openPath: String?,
    onOpenHandled: () -> Unit,
) {
    if (hasAccess) {
        GalleryContent(resumeTick, openPath, onOpenHandled)
    } else {
        AllFilesAccessScreen("Gallery", onRequestAccess)
    }
}

@Composable
private fun GalleryContent(resumeTick: Int, openPath: String?, onOpenHandled: () -> Unit) {
    val context = LocalContext.current
    val columns = LocalAppearance.current.galleryColumns
    // Reloaded each time the Gallery comes back to the front, so changes made in Files show up.
    val media by produceState<List<MediaItem>?>(null, resumeTick) {
        value = withContext(Dispatchers.IO) { queryImages(context) }
    }
    var page by rememberSaveable { mutableStateOf(GalleryPage.Photos) }
    var albumId by rememberSaveable { mutableStateOf<Long?>(null) }
    var viewer by remember { mutableStateOf<ViewerRequest?>(null) }

    val all = media.orEmpty()
    val albums = remember(all) {
        all.groupBy { it.bucketId }
            .map { (id, list) -> Album(id, list.first().bucketName, list) }
            .sortedBy { it.name.lowercase() }
    }
    val openAlbum = albums.firstOrNull { it.id == albumId }

    // Another part of the suite asked to show an image: open it among the images of its folder.
    LaunchedEffect(openPath, media) {
        val path = openPath ?: return@LaunchedEffect
        val list = media ?: return@LaunchedEffect
        val index = list.indexOfFirst { it.path == path }
        if (index >= 0) {
            val siblings = list.filter { it.bucketId == list[index].bucketId }
            viewer = ViewerRequest(siblings, siblings.indexOfFirst { it.path == path })
        } else {
            val file = File(path)
            if (file.isFile) viewer = ViewerRequest(listOf(adHocItem(file)), 0)
        }
        onOpenHandled()
    }

    BackHandler(enabled = viewer == null && openAlbum != null) { albumId = null }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    GalleryPage.entries.forEach { entry ->
                        NavigationBarItem(
                            selected = page == entry,
                            onClick = {
                                page = entry
                                albumId = null
                            },
                            icon = { Icon(painterResource(entry.icon), contentDescription = null) },
                            label = { Text(entry.label) },
                        )
                    }
                }
            },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when {
                    media == null -> Text("Loading…", Modifier.align(Alignment.Center))
                    all.isEmpty() -> Text("No images found", Modifier.align(Alignment.Center))
                    page == GalleryPage.Photos ->
                        PhotosGrid(all, columns, onOpen = { viewer = ViewerRequest(all, it) })
                    openAlbum != null -> Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "‹",
                                style = MaterialTheme.typography.headlineMedium,
                                modifier = Modifier
                                    .clickable { albumId = null }
                                    .padding(horizontal = 16.dp, vertical = 4.dp),
                            )
                            Text(openAlbum.name, style = MaterialTheme.typography.titleLarge)
                        }
                        PhotosGrid(
                            items = openAlbum.items,
                            columns = columns,
                            onOpen = { viewer = ViewerRequest(openAlbum.items, it) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                    else -> AlbumsGrid(albums, onOpen = { albumId = it.id })
                }
            }
        }

        viewer?.let { request ->
            Viewer(items = request.items, startIndex = request.index, onClose = { viewer = null })
        }
    }
}

/** An image that MediaStore doesn't know yet (just saved): show it anyway, straight from its file. */
private fun adHocItem(file: File) = MediaItem(
    id = -1L,
    uri = Uri.fromFile(file),
    path = file.path,
    name = file.name,
    dateMs = file.lastModified(),
    width = 0,
    height = 0,
    size = file.length(),
    mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()).orEmpty(),
    bucketId = 0L,
    bucketName = file.parentFile?.name.orEmpty(),
)
