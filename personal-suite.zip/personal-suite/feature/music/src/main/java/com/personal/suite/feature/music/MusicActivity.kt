package com.personal.suite.feature.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.res.stringResource
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.design.TaskProbeScreen
import com.personal.suite.core.registry.AppEntry

/** Registry entry; :app collects these. */
val MusicApp = AppEntry(
    id = "music",
    labelRes = R.string.feature_music_label,
    iconRes = R.drawable.ic_music,
    activityClassName = MusicActivity::class.java.name,
)

/** Phase 1 placeholder, real UI comes in a later phase. */
class MusicActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuiteTheme {
                TaskProbeScreen(
                    activity = this,
                    title = stringResource(MusicApp.labelRes),
                    launchMode = "singleTop + NEW_TASK + own affinity",
                    currentId = MusicApp.id,
                )
            }
        }
    }
}
