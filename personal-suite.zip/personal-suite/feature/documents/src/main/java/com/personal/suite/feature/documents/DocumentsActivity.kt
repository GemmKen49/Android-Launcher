package com.personal.suite.feature.documents

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.res.stringResource
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.design.TaskProbeScreen
import com.personal.suite.core.registry.AppEntry

/** Registry entry; :app collects these. */
val DocumentsApp = AppEntry(
    id = "documents",
    labelRes = R.string.feature_documents_label,
    iconRes = R.drawable.ic_documents,
    activityClassName = DocumentsActivity::class.java.name,
)

/** Phase 4 placeholder, real UI comes in a later phase. */
class DocumentsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuiteTheme {
                TaskProbeScreen(
                    activity = this,
                    title = stringResource(DocumentsApp.labelRes),
                    launchMode = "standard + NEW_TASK + own affinity",
                    currentId = DocumentsApp.id,
                )
            }
        }
    }
}
