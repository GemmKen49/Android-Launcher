package com.personal.suite.feature.terminal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.res.stringResource
import com.personal.suite.core.design.SuiteTheme
import com.personal.suite.core.design.TaskProbeScreen
import com.personal.suite.core.registry.AppEntry

/** Registry entry; :app collects these. */
val TerminalApp = AppEntry(
    id = "terminal",
    labelRes = R.string.feature_terminal_label,
    iconRes = R.drawable.ic_terminal,
    activityClassName = TerminalActivity::class.java.name,
)

/** Phase 4 placeholder, real UI comes in a later phase. */
class TerminalActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuiteTheme {
                TaskProbeScreen(
                    activity = this,
                    title = stringResource(TerminalApp.labelRes),
                    launchMode = "standard + NEW_TASK + own affinity",
                    currentId = TerminalApp.id,
                )
            }
        }
    }
}
