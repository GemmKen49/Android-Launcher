package com.personal.suite.core.tabs

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import com.personal.suite.core.prefs.SuitePrefs
import kotlinx.coroutines.flow.first

/**
 * Loads the saved tab session for [key] (restoring the last open tab and split state) and
 * returns a controller, or null while loading. Every change is saved automatically.
 */
@Composable
fun rememberTabsController(
    key: String,
    newTabData: () -> String,
    onAllClosed: () -> Unit,
): TabsController? {
    val context = LocalContext.current
    val prefs = remember { SuitePrefs.get(context) }
    val currentNewTabData by rememberUpdatedState(newTabData)
    val currentOnAllClosed by rememberUpdatedState(onAllClosed)

    val controller by produceState<TabsController?>(null, key) {
        val initial = parseTabsSession(prefs.tabsSession(key).first()) ?: newTabsSession(currentNewTabData())
        value = TabsController(
            initial = initial,
            newTabData = { currentNewTabData() },
            onSessionChanged = { prefs.saveTabsSession(key, it.toJson()) },
            onAllClosed = { currentOnAllClosed() },
        )
    }
    return controller
}
