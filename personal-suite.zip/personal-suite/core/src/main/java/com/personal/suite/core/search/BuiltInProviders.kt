package com.personal.suite.core.search

import android.content.Context
import com.personal.suite.core.apps.AppCatalog
import com.personal.suite.core.apps.LauncherItem
import com.personal.suite.core.apps.launchItem
import com.personal.suite.core.prefs.SuitePrefs
import kotlinx.coroutines.flow.first

private fun LauncherItem.toResult(score: Int) = SearchResult(
    key = key,
    title = label,
    score = score,
    item = this,
    open = { context -> context.launchItem(this) },
)

/**
 * Installed apps. Hidden apps are left out of an empty query (so opening search doesn't reveal them)
 * but can still be found by typing.
 */
class AppsProvider(private val context: Context) : SearchProvider {
    override val id = "apps"
    override val category = SearchCategory.Apps
    override val shownByDefault = true

    override suspend fun search(query: String): List<SearchResult> {
        val hidden = if (query.isBlank()) SuitePrefs.get(context).hiddenApps.first() else emptySet()
        return AppCatalog.get(context).items.value
            .filterIsInstance<LauncherItem.Installed>()
            .filter { it.key !in hidden }
            .mapNotNull { item -> matchScore(query, item.label).takeIf { it > 0 }?.let(item::toResult) }
    }
}

/** Built-in apps (Files, Gallery, ...). Only part of the default search, not of any filter. */
class ShortcutsProvider(private val context: Context) : SearchProvider {
    override val id = "shortcuts"
    override val category: SearchCategory? = null
    override val shownByDefault = true

    override suspend fun search(query: String): List<SearchResult> {
        val hidden = if (query.isBlank()) SuitePrefs.get(context).hiddenApps.first() else emptySet()
        return AppCatalog.get(context).items.value
            .filterIsInstance<LauncherItem.Internal>()
            .filter { it.key !in hidden }
            .mapNotNull { item -> matchScore(query, item.label).takeIf { it > 0 }?.let(item::toResult) }
    }
}

/** Reserves a filter for a feature that doesn't exist yet. Its chip stays disabled; replace it with the real provider later. */
class PlaceholderSearchProvider(override val category: SearchCategory) : SearchProvider {
    override val id = "placeholder:${category.name}"
    override val shownByDefault = false
    override val isAvailable = false

    override suspend fun search(query: String): List<SearchResult> = emptyList()
}
