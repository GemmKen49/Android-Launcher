package com.personal.suite.core.design

import android.app.Activity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.personal.suite.core.registry.AppRegistry
import com.personal.suite.core.registry.launchApp

/**
 * Phase 1 diagnostic screen used to validate task separation in Recents.
 * Shows the task id and instance id so duplicate tasks/instances are visible,
 * plus a per-instance counter to confirm state is independent per app.
 * Replaced by real UIs in later phases.
 */
@Composable
fun TaskProbeScreen(
    activity: Activity,
    title: String,
    launchMode: String,
    currentId: String? = null,
    extras: @Composable ColumnScope.() -> Unit = {},
) {
    val context = LocalContext.current
    var taps by rememberSaveable { mutableIntStateOf(0) }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(title, style = MaterialTheme.typography.headlineMedium)
            Text("Launch mode: $launchMode")
            Text("Task ID: ${activity.taskId}")
            Text("Instance: ${Integer.toHexString(System.identityHashCode(activity))}")
            Text("Intent flags: 0x${Integer.toHexString(activity.intent.flags)}")
            Button(onClick = { taps++ }) { Text("Taps (per-instance state): $taps") }
            extras()
            HorizontalDivider()
            Text("Open", style = MaterialTheme.typography.titleMedium)
            AppRegistry.entries.filter { it.id != currentId }.forEach { entry ->
                Button(onClick = { context.launchApp(entry) }) {
                    Text(stringResource(entry.labelRes))
                }
            }
        }
    }
}
