package com.personal.suite.core.tabs

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.util.UUID

/** One tab. [data] is whatever the app needs to restore the page (the File Manager stores a folder path). */
data class Tab(val id: String, val data: String)

/** [panes] are the tab ids on screen: one = normal view, two = split view (top, bottom). */
data class TabsSession(
    val tabs: List<Tab>,
    val panes: List<String>,
    val focusedPane: Int,
)

fun TabsSession.toJson(): String = JSONObject().apply {
    put("tabs", JSONArray().also { array ->
        tabs.forEach { array.put(JSONObject().put("id", it.id).put("data", it.data)) }
    })
    put("panes", JSONArray(panes))
    put("focused", focusedPane)
}.toString()

fun parseTabsSession(json: String?): TabsSession? {
    if (json == null) return null
    return try {
        val root = JSONObject(json)
        val tabArray = root.getJSONArray("tabs")
        val tabs = (0 until tabArray.length()).map {
            val tab = tabArray.getJSONObject(it)
            Tab(tab.getString("id"), tab.getString("data"))
        }
        val paneArray = root.getJSONArray("panes")
        val panes = (0 until paneArray.length())
            .map { paneArray.getString(it) }
            .filter { id -> tabs.any { it.id == id } }
            .take(2)
        if (tabs.isEmpty() || panes.isEmpty()) {
            null
        } else {
            TabsSession(tabs, panes, root.optInt("focused", 0).coerceIn(0, panes.lastIndex))
        }
    } catch (e: JSONException) {
        null
    }
}

fun newTabsSession(firstTabData: String): TabsSession {
    val tab = Tab(UUID.randomUUID().toString(), firstTabData)
    return TabsSession(listOf(tab), listOf(tab.id), 0)
}

/**
 * Tab and split-view logic, independent of what a tab shows.
 * Every change is reported through [onSessionChanged] so the app can save it.
 */
class TabsController(
    initial: TabsSession,
    private val newTabData: () -> String,
    private val onSessionChanged: (TabsSession) -> Unit,
    private val onAllClosed: () -> Unit,
) {
    var session by mutableStateOf(initial)
        private set

    /** Set while the user has to pick which split pane a tab should replace. */
    var pendingSplitId by mutableStateOf<String?>(null)
        private set

    val activeId: String get() = session.panes[session.focusedPane]
    val isSplit: Boolean get() = session.panes.size == 2

    private fun commit(next: TabsSession) {
        session = next
        onSessionChanged(next)
    }

    private fun newId() = UUID.randomUUID().toString()

    /** Shows [id] in the focused pane (or just focuses the pane already showing it). */
    fun select(id: String) {
        val s = session
        val shownIn = s.panes.indexOf(id)
        commit(
            if (shownIn >= 0) {
                s.copy(focusedPane = shownIn)
            } else {
                s.copy(panes = s.panes.toMutableList().also { it[s.focusedPane] = id })
            }
        )
    }

    fun focusPane(index: Int) {
        if (index in session.panes.indices && index != session.focusedPane) {
            commit(session.copy(focusedPane = index))
        }
    }

    fun update(id: String, data: String) {
        val s = session
        if (s.tabs.none { it.id == id && it.data != data }) return
        commit(s.copy(tabs = s.tabs.map { if (it.id == id) it.copy(data = data) else it }))
    }

    /** A fresh page, added at the end. */
    fun newTab() = insert(session.tabs.size, Tab(newId(), newTabData()))

    /** A new tab at the end showing [data] (e.g. a folder another app asked to open). */
    fun openNewTab(data: String) = insert(session.tabs.size, Tab(newId(), data))

    /** A copy of [id], placed right after it. */
    fun duplicate(id: String) {
        val index = session.tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        insert(index + 1, Tab(newId(), session.tabs[index].data))
    }

    private fun insert(index: Int, tab: Tab) {
        val s = session
        val tabs = s.tabs.toMutableList().also { it.add(index.coerceIn(0, it.size), tab) }
        val panes = s.panes.toMutableList().also { it[s.focusedPane] = tab.id }
        commit(s.copy(tabs = tabs, panes = panes))
    }

    /** Closing the last tab closes the window. */
    fun close(id: String) {
        val s = session
        val index = s.tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        val tabs = s.tabs.filter { it.id != id }
        if (tabs.isEmpty()) {
            onSessionChanged(TabsSession(emptyList(), emptyList(), 0))
            onAllClosed()
            return
        }
        if (id !in s.panes) {
            commit(s.copy(tabs = tabs))
            return
        }
        val paneIndex = s.panes.indexOf(id)
        val other = s.panes.firstOrNull { it != id }
        val neighbours = s.tabs.drop(index + 1) + s.tabs.take(index).reversed()
        val replacement = neighbours.firstOrNull { it.id != other }
        if (replacement == null) {
            // Only the other pane's tab is left: leave split view.
            commit(TabsSession(tabs, listOf(other ?: tabs.first().id), 0))
        } else {
            commit(s.copy(tabs = tabs, panes = s.panes.toMutableList().also { it[paneIndex] = replacement.id }))
        }
    }

    fun closeOthers(id: String) {
        val keep = session.tabs.firstOrNull { it.id == id } ?: return
        commit(TabsSession(listOf(keep), listOf(keep.id), 0))
    }

    /** Split view: the first request splits, later requests ask which pane to replace. */
    fun requestSplit(id: String) {
        if (isSplit) pendingSplitId = id else openInSplit(id)
    }

    fun cancelSplit() {
        pendingSplitId = null
    }

    private fun openInSplit(id: String) {
        val s = session
        val current = s.panes[0]
        if (id == current) {
            val index = s.tabs.indexOfFirst { it.id == id }
            val copy = Tab(newId(), s.tabs[index].data)
            val tabs = s.tabs.toMutableList().also { it.add(index + 1, copy) }
            commit(s.copy(tabs = tabs, panes = listOf(current, copy.id), focusedPane = 1))
        } else {
            commit(s.copy(panes = listOf(current, id), focusedPane = 1))
        }
    }

    fun replacePane(paneIndex: Int, id: String) {
        pendingSplitId = null
        val s = session
        if (s.panes.size != 2 || paneIndex !in 0..1) return
        val panes = s.panes.toMutableList()
        val other = 1 - paneIndex
        if (panes[other] == id) panes[other] = panes[paneIndex] // swap instead of showing a tab twice
        panes[paneIndex] = id
        commit(s.copy(panes = panes, focusedPane = paneIndex))
    }

    fun closeSplit() {
        val s = session
        if (s.panes.size == 2) commit(s.copy(panes = listOf(activeId), focusedPane = 0))
    }
}
