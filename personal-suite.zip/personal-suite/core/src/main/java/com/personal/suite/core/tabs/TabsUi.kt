package com.personal.suite.core.tabs

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/** Browser-style tab strip with a "+" menu (new tab / duplicate to the right). Long-press a tab for more. */
@Composable
fun TabStrip(
    controller: TabsController,
    title: (Tab) -> String,
    modifier: Modifier = Modifier,
) {
    val session = controller.session
    var newMenuOpen by remember { mutableStateOf(false) }

    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        LazyRow(
            modifier = Modifier.weight(1f, fill = false),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items(session.tabs, key = { it.id }) { tab ->
                TabChip(tab = tab, label = title(tab), controller = controller)
            }
        }
        Box {
            Text(
                text = "+",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier
                    .clickable { newMenuOpen = true }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
            DropdownMenu(expanded = newMenuOpen, onDismissRequest = { newMenuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("New tab") },
                    onClick = {
                        newMenuOpen = false
                        controller.newTab()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Duplicate current tab to the right") },
                    onClick = {
                        newMenuOpen = false
                        controller.duplicate(controller.activeId)
                    },
                )
            }
        }
    }

    controller.pendingSplitId?.let { id ->
        AlertDialog(
            onDismissRequest = { controller.cancelSplit() },
            title = { Text("Split view is full") },
            text = {
                Column {
                    Text("Which pane should show this tab?")
                    TextButton(onClick = { controller.replacePane(0, id) }) { Text("Replace top pane") }
                    TextButton(onClick = { controller.replacePane(1, id) }) { Text("Replace bottom pane") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { controller.cancelSplit() }) { Text("Cancel") } },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TabChip(tab: Tab, label: String, controller: TabsController) {
    val session = controller.session
    var menuOpen by remember { mutableStateOf(false) }

    val focused = tab.id == controller.activeId
    val inOtherPane = controller.isSplit && tab.id in session.panes && !focused
    val container = when {
        focused -> MaterialTheme.colorScheme.primaryContainer
        inOtherPane -> MaterialTheme.colorScheme.secondaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }

    Box {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(container)
                .combinedClickable(
                    onClick = { controller.select(tab.id) },
                    onLongClick = { menuOpen = true },
                )
                .padding(start = 12.dp, end = 2.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 120.dp),
            )
            Text(
                text = "×",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier
                    .clickable { controller.close(tab.id) }
                    .padding(horizontal = 8.dp, vertical = 2.dp),
            )
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(
                text = { Text("Duplicate to the right") },
                onClick = {
                    menuOpen = false
                    controller.duplicate(tab.id)
                },
            )
            DropdownMenuItem(
                text = { Text("Open in split view") },
                onClick = {
                    menuOpen = false
                    controller.requestSplit(tab.id)
                },
            )
            if (controller.isSplit) {
                DropdownMenuItem(
                    text = { Text("Close split view") },
                    onClick = {
                        menuOpen = false
                        controller.closeSplit()
                    },
                )
            }
            if (session.tabs.size > 1) {
                DropdownMenuItem(
                    text = { Text("Close other tabs") },
                    onClick = {
                        menuOpen = false
                        controller.closeOthers(tab.id)
                    },
                )
            }
            DropdownMenuItem(
                text = { Text("Close tab") },
                onClick = {
                    menuOpen = false
                    controller.close(tab.id)
                },
            )
        }
    }
}

/**
 * Shows the active tab, or two tabs one above the other in split view.
 * Touching a pane focuses it. [content] draws one tab; each tab keeps its own state.
 */
@Composable
fun TabbedContent(
    controller: TabsController,
    modifier: Modifier = Modifier,
    content: @Composable (tab: Tab, focused: Boolean) -> Unit,
) {
    val session = controller.session
    val split = session.panes.size == 2

    Column(modifier) {
        session.panes.forEachIndexed { index, id ->
            val tab = session.tabs.firstOrNull { it.id == id } ?: return@forEachIndexed
            val focused = index == session.focusedPane
            if (index == 1) HorizontalDivider()
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(index, split) {
                        if (split) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                controller.focusPane(index)
                            }
                        }
                    }
                    .border(2.dp, if (split && focused) MaterialTheme.colorScheme.primary else Color.Transparent),
            ) {
                key(tab.id) { content(tab, focused) }
            }
        }
    }
}
