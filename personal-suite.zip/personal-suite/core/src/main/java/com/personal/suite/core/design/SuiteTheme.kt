package com.personal.suite.core.design

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.personal.suite.core.prefs.Appearance
import com.personal.suite.core.prefs.LocalAppearance
import com.personal.suite.core.prefs.SuitePrefs
import com.personal.suite.core.prefs.ThemeMode

@Composable
fun SuiteTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { SuitePrefs.get(context) }
    val mode by remember { prefs.themeMode }.collectAsState(initial = ThemeMode.System)
    val appearance by remember { prefs.appearance }.collectAsState(initial = Appearance())
    val dark = when (mode) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Light -> false
        ThemeMode.Dark -> true
    }
    val colors = when {
        appearance.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    CompositionLocalProvider(LocalAppearance provides appearance) {
        MaterialTheme(colorScheme = colors, content = content)
    }
}
