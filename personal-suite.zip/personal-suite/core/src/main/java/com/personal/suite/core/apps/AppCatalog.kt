package com.personal.suite.core.apps

import android.content.Context
import android.content.pm.LauncherApps
import android.os.Process
import android.os.UserHandle
import com.personal.suite.core.registry.AppRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Installed launcher apps (current user only) plus registered built-in apps, sorted by label.
 * Updates itself when packages are installed, removed or changed.
 */
class AppCatalog private constructor(private val context: Context) {

    private val launcherApps = context.getSystemService(LauncherApps::class.java)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _items = MutableStateFlow<List<LauncherItem>>(emptyList())

    val items: StateFlow<List<LauncherItem>> = _items.asStateFlow()

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String, user: UserHandle) = refresh()
        override fun onPackageAdded(packageName: String, user: UserHandle) = refresh()
        override fun onPackageChanged(packageName: String, user: UserHandle) = refresh()
        override fun onPackagesAvailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = refresh()
        override fun onPackagesUnavailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = refresh()
    }

    init {
        launcherApps.registerCallback(callback)
        refresh()
    }

    fun refresh() {
        scope.launch {
            val installed = launcherApps.getActivityList(null, Process.myUserHandle())
                .filter { it.componentName.packageName != context.packageName }
                .map { LauncherItem.Installed(it.label.toString(), it.componentName) }
            val internal = AppRegistry.entries.map {
                LauncherItem.Internal(context.getString(it.labelRes), it)
            }
            _items.value = (installed + internal).sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
        }
    }

    companion object {
        @Volatile
        private var instance: AppCatalog? = null

        fun get(context: Context): AppCatalog =
            instance ?: synchronized(this) {
                instance ?: AppCatalog(context.applicationContext).also { instance = it }
            }
    }
}
