package com.personal.suite.core.apps

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val iconCache = LruCache<String, ImageBitmap>(256)

/** Loads the item's icon off the main thread and caches it. */
@Composable
fun AppIcon(item: LauncherItem, modifier: Modifier = Modifier, size: Dp = 56.dp) {
    val context = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }
    val icon by produceState<ImageBitmap?>(initialValue = iconCache.get(item.key), item.key) {
        if (value == null) {
            value = withContext(Dispatchers.Default) {
                loadIcon(context, item, px).also { iconCache.put(item.key, it) }
            }
        }
    }
    val bitmap = icon
    if (bitmap != null) {
        Image(bitmap = bitmap, contentDescription = null, modifier = modifier.size(size))
    } else {
        Spacer(modifier.size(size))
    }
}

private fun loadIcon(context: Context, item: LauncherItem, px: Int): ImageBitmap {
    val drawable: Drawable = when (item) {
        is LauncherItem.Installed ->
            try {
                context.packageManager.getActivityIcon(item.component)
            } catch (e: PackageManager.NameNotFoundException) {
                context.packageManager.defaultActivityIcon
            }
        is LauncherItem.Internal -> requireNotNull(context.getDrawable(item.entry.iconRes))
    }
    val bitmap = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
    drawable.setBounds(0, 0, px, px)
    drawable.draw(Canvas(bitmap))
    return bitmap.asImageBitmap()
}
