package com.personal.suite.core.search

import android.content.Context
import com.personal.suite.core.apps.LauncherItem
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.util.concurrent.CopyOnWriteArrayList

enum class SearchCategory(val label: String) {
    Apps("Apps"),
    Files("Files"),
    Images("Images"),
    Videos("Videos"),
    Music("Music"),
    Documents("Documents"),
}

/**
 * One search hit. [item] is set for app/shortcut hits (gives an icon and the launcher's long-press actions).
 * [open] performs the navigation, so other content types can supply their own destination.
 * [key] must be unique across providers (prefix it with the provider's content type).
 * [typeLabel] is shown at the right of the row ("App", "File", "Image", ...).
 */
data class SearchResult(
    val key: String,
    val title: String,
    val typeLabel: String,
    val subtitle: String? = null,
    val score: Int,
    val item: LauncherItem? = null,
    val open: (Context) -> Unit,
)

/**
 * A source of search results. Features register one with [SearchRegistry]; the engine never changes.
 * - [category] is the filter that selects this provider (null = only used by the default, unfiltered search).
 * - [shownByDefault] = included when no filter is selected.
 * - [isAvailable] = false for placeholders whose feature does not exist yet (their filter chip is disabled).
 */
interface SearchProvider {
    val id: String
    val category: SearchCategory?
    val shownByDefault: Boolean
    val isAvailable: Boolean get() = true

    suspend fun search(query: String): List<SearchResult>
}

object SearchRegistry {
    private val registered = CopyOnWriteArrayList<SearchProvider>()

    val providers: List<SearchProvider> get() = registered.toList()

    fun register(provider: SearchProvider) {
        registered.add(provider)
    }

    fun isAvailable(category: SearchCategory): Boolean =
        registered.any { it.isAvailable && it.category == category }
}

object SearchEngine {
    /**
     * No filters selected: providers marked shownByDefault (apps + built-in shortcuts).
     * Filters selected: providers whose category is selected (several filters combine).
     */
    suspend fun search(query: String, filters: Set<SearchCategory>): List<SearchResult> {
        val active = SearchRegistry.providers.filter { provider ->
            val category = provider.category
            provider.isAvailable &&
                if (filters.isEmpty()) provider.shownByDefault else (category != null && category in filters)
        }
        return coroutineScope { active.map { async { it.search(query) } }.awaitAll() }
            .flatten()
            .sortedWith(compareByDescending<SearchResult> { it.score }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.title })
    }
}

/** 0 = no match. Exact > prefix > word-prefix > substring. A blank query matches everything equally. */
fun matchScore(query: String, text: String): Int {
    val q = query.trim().lowercase()
    if (q.isEmpty()) return 1
    val t = text.lowercase()
    return when {
        t == q -> 100
        t.startsWith(q) -> 80
        t.split(' ', '-', '_', '.').any { it.startsWith(q) } -> 60
        t.contains(q) -> 40
        else -> 0
    }
}
