package com.personal.suite.core.registry

import android.content.Context
import android.content.Intent
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/** A built-in application: one Activity entry point that gets its own Android task. */
data class AppEntry(
    val id: String,
    @StringRes val labelRes: Int,
    @DrawableRes val iconRes: Int,
    val activityClassName: String,
)

/** Filled once by the :app module at startup. Launcher, drawer and search read from here. */
object AppRegistry {
    var entries: List<AppEntry> = emptyList()
        private set

    fun register(entries: List<AppEntry>) {
        this.entries = entries
    }
}

/** Explicit-intent launch. The task each app lands in is decided by its manifest (affinity/launchMode). */
fun Context.launchApp(entry: AppEntry) {
    startActivity(
        Intent()
            .setClassName(packageName, entry.activityClassName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

/** Extra carrying a file path to an app that can show it (the Gallery opens that image). */
const val EXTRA_OPEN_PATH = "com.personal.suite.OPEN_PATH"

/** Starts the built-in app [appId] and asks it to show [path]. False if there is no such app. */
fun Context.launchAppWithPath(appId: String, path: String): Boolean {
    val entry = AppRegistry.entries.firstOrNull { it.id == appId } ?: return false
    startActivity(
        Intent()
            .setClassName(packageName, entry.activityClassName)
            .putExtra(EXTRA_OPEN_PATH, path)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
    return true
}
