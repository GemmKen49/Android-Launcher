package com.personal.suite.core.registry

import android.content.Context
import android.content.Intent
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/** A built-in application: one Activity entry point that gets its own Android task. */
data class AppEntry(
    val id: String,
    @StringRes val labelRes: Int,
    @DrawableRes val iconRes: Int,
    val activityClassName: String,
)

/** Filled once by the :app module at startup. Launcher, drawer and search read from here. */
object AppRegistry {
    var entries: List<AppEntry> = emptyList()
        private set

    fun register(entries: List<AppEntry>) {
        this.entries = entries
    }
}

/** Explicit-intent launch. The task each app lands in is decided by its manifest (affinity/launchMode). */
fun Context.launchApp(entry: AppEntry) {
    startActivity(
        Intent()
            .setClassName(packageName, entry.activityClassName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}
