package com.personal.suite.core.media

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.net.Uri
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.lang.reflect.Modifier as ReflectModifier
import java.text.DateFormat
import java.util.Date
import kotlin.math.roundToInt

data class DetailRow(val label: String, val value: String)

data class DetailSection(val title: String, val rows: List<DetailRow>)

/** Everything shown on the details screen. [allTags] is every EXIF tag found in the file. */
data class MediaDetails(
    val sections: List<DetailSection>,
    val latLong: DoubleArray?,
    val allTags: List<DetailRow>,
)

private val exifTagNames: List<String> by lazy {
    ExifInterface::class.java.fields
        .filter { ReflectModifier.isStatic(it.modifiers) && it.name.startsWith("TAG_") && it.type == String::class.java }
        .mapNotNull { it.get(null) as? String }
        .filter { it != "MakerNote" }
        .distinct()
        .sorted()
}

private fun MutableList<DetailRow>.add(label: String, value: String?) {
    if (!value.isNullOrBlank()) add(DetailRow(label, value.trim()))
}

private fun orientationName(value: Int): String? = when (value) {
    ExifInterface.ORIENTATION_NORMAL -> "Normal"
    ExifInterface.ORIENTATION_ROTATE_90 -> "Rotated 90°"
    ExifInterface.ORIENTATION_ROTATE_180 -> "Rotated 180°"
    ExifInterface.ORIENTATION_ROTATE_270 -> "Rotated 270°"
    ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> "Mirrored"
    ExifInterface.ORIENTATION_FLIP_VERTICAL -> "Flipped"
    ExifInterface.ORIENTATION_TRANSPOSE -> "Transposed"
    ExifInterface.ORIENTATION_TRANSVERSE -> "Transversed"
    else -> null
}

private fun exposureText(seconds: Double): String =
    if (seconds <= 0.0) "" else if (seconds < 1.0) "1/${(1.0 / seconds).roundToInt()} s" else "${"%.1f".format(seconds)} s"

/** Blocking: call off the main thread. Works for any file; image files add image, camera and location sections. */
fun loadDetails(context: Context, file: File): MediaDetails {
    val sections = mutableListOf<DetailSection>()
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase())
    val dateFormat = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM)

    val fileRows = mutableListOf<DetailRow>()
    fileRows.add("Name", file.name)
    fileRows.add("Location", file.parent)
    fileRows.add("Type", mime ?: if (file.isDirectory) "Folder" else null)
    fileRows.add("Size", "${Formatter.formatFileSize(context, file.length())} (${"%,d".format(file.length())} bytes)")
    fileRows.add("Modified", dateFormat.format(Date(file.lastModified())))
    sections += DetailSection("File", fileRows)

    if (mime?.startsWith("image/") != true) return MediaDetails(sections, null, emptyList())

    val exif = runCatching { ExifInterface(file.absolutePath) }.getOrNull()

    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    runCatching { BitmapFactory.decodeFile(file.absolutePath, bounds) }
    var width = bounds.outWidth
    var height = bounds.outHeight
    if ((width <= 0 || height <= 0) && exif != null) {
        width = exif.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, 0)
        height = exif.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, 0)
    }
    val imageRows = mutableListOf<DetailRow>()
    if (width > 0 && height > 0) {
        imageRows.add("Dimensions", "$width × $height")
        imageRows.add("Megapixels", "${"%.1f".format(width * height / 1_000_000.0)} MP")
    }
    exif?.let {
        imageRows.add("Taken", it.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL))
        imageRows.add("Digitized", it.getAttribute(ExifInterface.TAG_DATETIME_DIGITIZED))
        imageRows.add("Orientation", orientationName(it.getAttributeInt(ExifInterface.TAG_ORIENTATION, 0)))
        imageRows.add("Description", it.getAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION))
        imageRows.add("Artist", it.getAttribute(ExifInterface.TAG_ARTIST))
        imageRows.add("Copyright", it.getAttribute(ExifInterface.TAG_COPYRIGHT))
    }
    if (imageRows.isNotEmpty()) sections += DetailSection("Image", imageRows)

    var latLong: DoubleArray? = null
    if (exif != null) {
        val camera = mutableListOf<DetailRow>()
        camera.add("Make", exif.getAttribute(ExifInterface.TAG_MAKE))
        camera.add("Model", exif.getAttribute(ExifInterface.TAG_MODEL))
        camera.add("Lens", exif.getAttribute("LensModel"))
        exif.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0.0).takeIf { it > 0 }?.let { camera.add("Aperture", "f/${"%.1f".format(it)}") }
        exposureText(exif.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0.0)).takeIf { it.isNotEmpty() }?.let { camera.add("Exposure", it) }
        camera.add("ISO", exif.getAttribute("PhotographicSensitivity") ?: exif.getAttribute("ISOSpeedRatings"))
        exif.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, 0.0).takeIf { it > 0 }?.let { camera.add("Focal length", "${"%.1f".format(it)} mm") }
        camera.add("Focal length (35mm)", exif.getAttribute(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM))
        val flash = exif.getAttributeInt(ExifInterface.TAG_FLASH, -1)
        if (flash >= 0) camera.add("Flash", if (flash and 1 == 1) "Fired" else "Did not fire")
        camera.add("White balance", exif.getAttribute(ExifInterface.TAG_WHITE_BALANCE))
        camera.add("Exposure program", exif.getAttribute(ExifInterface.TAG_EXPOSURE_PROGRAM))
        camera.add("Metering mode", exif.getAttribute(ExifInterface.TAG_METERING_MODE))
        camera.add("Software", exif.getAttribute(ExifInterface.TAG_SOFTWARE))
        if (camera.isNotEmpty()) sections += DetailSection("Camera", camera)

        // The framework ExifInterface reports coordinates through an output array.
        val coordinates = FloatArray(2)
        if (exif.getLatLong(coordinates)) {
            latLong = doubleArrayOf(coordinates[0].toDouble(), coordinates[1].toDouble())
        }
        latLong?.let { position ->
            val altitude = exif.getAltitude(Double.NaN)
            val location = mutableListOf<DetailRow>()
            location.add("Latitude", "%.6f".format(position[0]))
            location.add("Longitude", "%.6f".format(position[1]))
            if (!altitude.isNaN()) location.add("Altitude", "${altitude.roundToInt()} m")
            sections += DetailSection("Location", location)
        }
    }

    val allTags = exif?.let {
        exifTagNames.mapNotNull { tag ->
            it.getAttribute(tag)?.takeIf { value -> value.isNotBlank() }?.let { value -> DetailRow(tag, value.take(300)) }
        }
    }.orEmpty()

    return MediaDetails(sections, latLong, allTags)
}

/** Loads and shows the details of [file]. The same screen is used by the Gallery viewer and the File Manager. */
@Composable
fun MediaDetailsScreen(file: File, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val details by produceState<MediaDetails?>(null, file.path) {
        value = withContext(Dispatchers.IO) { loadDetails(context, file) }
    }
    val loaded = details
    if (loaded == null) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Loading…") }
    } else {
        MediaDetailsContent(loaded, modifier)
    }
}

@Composable
fun MediaDetailsContent(details: MediaDetails, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var showAll by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        details.sections.forEach { section ->
            item(key = "section:${section.title}") {
                Text(
                    text = section.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
            items(section.rows, key = { "${section.title}:${it.label}" }) { DetailLine(it) }
        }

        details.latLong?.let { position ->
            item(key = "map") {
                OutlinedButton(onClick = { context.openInMaps(position[0], position[1]) }) { Text("Open in maps") }
            }
        }

        if (details.allTags.isNotEmpty()) {
            item(key = "all-toggle") {
                TextButton(onClick = { showAll = !showAll }) {
                    Text(if (showAll) "Hide all EXIF tags" else "All EXIF tags (${details.allTags.size})")
                }
            }
            if (showAll) items(details.allTags, key = { "tag:${it.label}" }) { DetailLine(it) }
        }
    }
}

@Composable
private fun DetailLine(row: DetailRow) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = row.label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(128.dp),
        )
        Text(row.value, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
    }
}

private fun Context.openInMaps(latitude: Double, longitude: Double) {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude")))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(this, "No maps app installed", Toast.LENGTH_SHORT).show()
    }
}
