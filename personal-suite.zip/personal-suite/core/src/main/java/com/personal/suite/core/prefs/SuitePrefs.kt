package com.personal.suite.core.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

enum class ThemeMode {
    System, Light, Dark;

    fun next(): ThemeMode = entries[(ordinal + 1) % entries.size]
}

enum class SortBy { Name, Date, Size }

/** File manager quick settings. */
data class FilesPrefs(
    val showHidden: Boolean = false,
    val sortBy: SortBy = SortBy.Name,
    val descending: Boolean = false,
    val foldersFirst: Boolean = true,
)

private val Context.suiteDataStore by preferencesDataStore(name = "suite_prefs")

/** Shared settings for every app in the suite (one process, one DataStore). */
class SuitePrefs private constructor(private val store: DataStore<Preferences>) {

    val themeMode: Flow<ThemeMode> = store.data.map { prefs ->
        ThemeMode.entries.firstOrNull { it.name == prefs[THEME_MODE] } ?: ThemeMode.System
    }

    /** Keys of items hidden from the launcher's app drawer (see LauncherItem.key). */
    val hiddenApps: Flow<Set<String>> = store.data.map { it[HIDDEN] ?: emptySet() }

    /** Ordered keys pinned to the dock. null = never customized (launcher applies defaults). */
    val pinnedKeys: Flow<List<String>?> = store.data.map { prefs ->
        prefs[PINNED]?.let { if (it.isEmpty()) emptyList() else it.split('\n') }
    }

    /** Widgets placed on the home screen, in order (older saves that only stored ids are upgraded on read). */
    val widgets: Flow<List<WidgetPlacement>> = store.data.map { prefs -> currentPlacements(prefs) }

    val appearance: Flow<Appearance> = store.data.map { p ->
        val d = Appearance()
        Appearance(
            dynamicColor = p[A_DYNAMIC] ?: d.dynamicColor,
            clockMonospace = p[A_CLOCK_MONO] ?: d.clockMonospace,
            clockSize = p[A_CLOCK_SIZE] ?: d.clockSize,
            clockDigitWidth = p[A_CLOCK_DIGIT_W] ?: d.clockDigitWidth,
            clockLineGap = p[A_CLOCK_GAP] ?: d.clockLineGap,
            clockSecondsScale = p[A_CLOCK_SEC_SCALE] ?: d.clockSecondsScale,
            clockShowSeconds = p[A_CLOCK_SECONDS] ?: d.clockShowSeconds,
            clockShowDate = p[A_CLOCK_DATE] ?: d.clockShowDate,
            clockVerticalBias = p[A_CLOCK_BIAS] ?: d.clockVerticalBias,
            dockIconSize = p[A_DOCK_ICON] ?: d.dockIconSize,
            drawerColumns = p[A_DRAWER_COLUMNS] ?: d.drawerColumns,
            drawerIconSize = p[A_DRAWER_ICON] ?: d.drawerIconSize,
            cardOpacity = p[A_CARD_OPACITY] ?: d.cardOpacity,
            cardCornerRadius = p[A_CARD_RADIUS] ?: d.cardCornerRadius,
            drawerScrim = p[A_SCRIM] ?: d.drawerScrim,
            widgetColumns = p[A_WIDGET_COLUMNS] ?: d.widgetColumns,
            widgetGap = p[A_WIDGET_GAP] ?: d.widgetGap,
        )
    }

    val filesPrefs: Flow<FilesPrefs> = store.data.map { p ->
        FilesPrefs(
            showHidden = p[F_HIDDEN] ?: false,
            sortBy = SortBy.entries.firstOrNull { it.name == p[F_SORT] } ?: SortBy.Name,
            descending = p[F_DESC] ?: false,
            foldersFirst = p[F_FOLDERS_FIRST] ?: true,
        )
    }

    /** Saved tab session of one app (JSON), see core.tabs. */
    fun tabsSession(key: String): Flow<String?> = store.data.map { it[stringPreferencesKey("tabs_$key")] }

    /** Fire-and-forget on an app-wide scope so a final save survives the window closing. */
    fun saveTabsSession(key: String, json: String) {
        appScope.launch { store.edit { it[stringPreferencesKey("tabs_$key")] = json } }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        store.edit { it[THEME_MODE] = mode.name }
    }

    suspend fun setHidden(key: String, hidden: Boolean) {
        store.edit {
            val current = it[HIDDEN] ?: emptySet()
            it[HIDDEN] = if (hidden) current + key else current - key
        }
    }

    suspend fun setPinned(keys: List<String>) {
        store.edit { it[PINNED] = keys.joinToString("\n") }
    }

    suspend fun addWidget(id: Int) {
        store.edit { it[PLACEMENTS] = encodePlacements(currentPlacements(it) + WidgetPlacement(id)) }
    }

    suspend fun removeWidget(id: Int) {
        store.edit { it[PLACEMENTS] = encodePlacements(currentPlacements(it).filter { w -> w.id != id }) }
    }

    suspend fun updateWidget(placement: WidgetPlacement) {
        store.edit { prefs ->
            prefs[PLACEMENTS] = encodePlacements(
                currentPlacements(prefs).map { w -> if (w.id == placement.id) placement else w }
            )
        }
    }

    suspend fun setAppearance(a: Appearance) {
        store.edit { p ->
            p[A_DYNAMIC] = a.dynamicColor
            p[A_CLOCK_MONO] = a.clockMonospace
            p[A_CLOCK_SIZE] = a.clockSize
            p[A_CLOCK_DIGIT_W] = a.clockDigitWidth
            p[A_CLOCK_GAP] = a.clockLineGap
            p[A_CLOCK_SEC_SCALE] = a.clockSecondsScale
            p[A_CLOCK_SECONDS] = a.clockShowSeconds
            p[A_CLOCK_DATE] = a.clockShowDate
            p[A_CLOCK_BIAS] = a.clockVerticalBias
            p[A_DOCK_ICON] = a.dockIconSize
            p[A_DRAWER_COLUMNS] = a.drawerColumns
            p[A_DRAWER_ICON] = a.drawerIconSize
            p[A_CARD_OPACITY] = a.cardOpacity
            p[A_CARD_RADIUS] = a.cardCornerRadius
            p[A_SCRIM] = a.drawerScrim
            p[A_WIDGET_COLUMNS] = a.widgetColumns
            p[A_WIDGET_GAP] = a.widgetGap
        }
    }

    suspend fun setFilesPrefs(f: FilesPrefs) {
        store.edit { p ->
            p[F_HIDDEN] = f.showHidden
            p[F_SORT] = f.sortBy.name
            p[F_DESC] = f.descending
            p[F_FOLDERS_FIRST] = f.foldersFirst
        }
    }

    companion object {
        private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        private val THEME_MODE = stringPreferencesKey("theme_mode")
        private val HIDDEN = stringSetPreferencesKey("hidden_apps")
        private val PINNED = stringPreferencesKey("pinned_items")
        private val WIDGETS = stringPreferencesKey("widget_ids") // old format: ids only
        private val PLACEMENTS = stringPreferencesKey("widget_placements")

        private val A_DYNAMIC = booleanPreferencesKey("a_dynamic_color")
        private val A_CLOCK_MONO = booleanPreferencesKey("a_clock_mono")
        private val A_CLOCK_SIZE = floatPreferencesKey("a_clock_size")
        private val A_CLOCK_DIGIT_W = floatPreferencesKey("a_clock_digit_w")
        private val A_CLOCK_GAP = floatPreferencesKey("a_clock_gap")
        private val A_CLOCK_SEC_SCALE = floatPreferencesKey("a_clock_sec_scale")
        private val A_CLOCK_SECONDS = booleanPreferencesKey("a_clock_seconds")
        private val A_CLOCK_DATE = booleanPreferencesKey("a_clock_date")
        private val A_CLOCK_BIAS = floatPreferencesKey("a_clock_bias")
        private val A_DOCK_ICON = floatPreferencesKey("a_dock_icon")
        private val A_DRAWER_COLUMNS = intPreferencesKey("a_drawer_columns")
        private val A_DRAWER_ICON = floatPreferencesKey("a_drawer_icon")
        private val A_CARD_OPACITY = floatPreferencesKey("a_card_opacity")
        private val A_CARD_RADIUS = floatPreferencesKey("a_card_radius")
        private val A_SCRIM = floatPreferencesKey("a_scrim")
        private val A_WIDGET_COLUMNS = intPreferencesKey("a_widget_columns")
        private val A_WIDGET_GAP = floatPreferencesKey("a_widget_gap")

        private val F_HIDDEN = booleanPreferencesKey("show_hidden_files")
        private val F_SORT = stringPreferencesKey("files_sort")
        private val F_DESC = booleanPreferencesKey("files_desc")
        private val F_FOLDERS_FIRST = booleanPreferencesKey("files_folders_first")

        private fun currentPlacements(prefs: Preferences): List<WidgetPlacement> =
            prefs[PLACEMENTS]?.let(::decodePlacements) ?: parseIds(prefs[WIDGETS]).map { WidgetPlacement(it) }

        private fun parseIds(raw: String?): List<Int> = raw?.split(',')?.mapNotNull { it.toIntOrNull() } ?: emptyList()

        fun get(context: Context): SuitePrefs = SuitePrefs(context.applicationContext.suiteDataStore)
    }
}
