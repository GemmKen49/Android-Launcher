package com.personal.suite.core.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode {
    System, Light, Dark;

    fun next(): ThemeMode = entries[(ordinal + 1) % entries.size]
}

private val Context.suiteDataStore by preferencesDataStore(name = "suite_prefs")

/** Shared settings for every app in the suite (one process, one DataStore). */
class SuitePrefs private constructor(private val store: DataStore<Preferences>) {

    val themeMode: Flow<ThemeMode> = store.data.map { prefs ->
        ThemeMode.entries.firstOrNull { it.name == prefs[THEME_MODE] } ?: ThemeMode.System
    }

    /** Keys of items hidden from the launcher's app drawer (see LauncherItem.key). */
    val hiddenApps: Flow<Set<String>> = store.data.map { it[HIDDEN] ?: emptySet() }

    /** Ordered keys pinned to the home screen. null = never customized (launcher applies defaults). */
    val pinnedKeys: Flow<List<String>?> = store.data.map { prefs ->
        prefs[PINNED]?.let { if (it.isEmpty()) emptyList() else it.split('\n') }
    }

    val gridColumns: Flow<Int> = store.data.map { it[GRID_COLUMNS] ?: DEFAULT_COLUMNS }

    suspend fun setThemeMode(mode: ThemeMode) {
        store.edit { it[THEME_MODE] = mode.name }
    }

    suspend fun setHidden(key: String, hidden: Boolean) {
        store.edit {
            val current = it[HIDDEN] ?: emptySet()
            it[HIDDEN] = if (hidden) current + key else current - key
        }
    }

    suspend fun setPinned(keys: List<String>) {
        store.edit { it[PINNED] = keys.joinToString("\n") }
    }

    suspend fun setGridColumns(columns: Int) {
        store.edit { it[GRID_COLUMNS] = columns.coerceIn(MIN_COLUMNS, MAX_COLUMNS) }
    }

    companion object {
        const val DEFAULT_COLUMNS = 4
        const val MIN_COLUMNS = 3
        const val MAX_COLUMNS = 6

        private val THEME_MODE = stringPreferencesKey("theme_mode")
        private val HIDDEN = stringSetPreferencesKey("hidden_apps")
        private val PINNED = stringPreferencesKey("pinned_items")
        private val GRID_COLUMNS = intPreferencesKey("grid_columns")

        fun get(context: Context): SuitePrefs = SuitePrefs(context.applicationContext.suiteDataStore)
    }
}
