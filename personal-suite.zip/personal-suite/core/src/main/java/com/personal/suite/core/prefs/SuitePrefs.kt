package com.personal.suite.core.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode {
    System, Light, Dark;

    fun next(): ThemeMode = entries[(ordinal + 1) % entries.size]
}

private val Context.suiteDataStore by preferencesDataStore(name = "suite_prefs")

/** Shared settings for every app in the suite (one process, one DataStore). */
class SuitePrefs private constructor(private val store: DataStore<Preferences>) {

    val themeMode: Flow<ThemeMode> = store.data.map { prefs ->
        ThemeMode.entries.firstOrNull { it.name == prefs[THEME_MODE] } ?: ThemeMode.System
    }

    /** Keys of items hidden from the launcher's app drawer (see LauncherItem.key). */
    val hiddenApps: Flow<Set<String>> = store.data.map { it[HIDDEN] ?: emptySet() }

    /** Ordered keys pinned to the home screen. null = never customized (launcher applies defaults). */
    val pinnedKeys: Flow<List<String>?> = store.data.map { prefs ->
        prefs[PINNED]?.let { if (it.isEmpty()) emptyList() else it.split('\n') }
    }

    /** Android widget ids placed on the home screen, in order. */
    val widgetIds: Flow<List<Int>> = store.data.map { prefs -> parseIds(prefs[WIDGETS]) }

    suspend fun setThemeMode(mode: ThemeMode) {
        store.edit { it[THEME_MODE] = mode.name }
    }

    suspend fun setHidden(key: String, hidden: Boolean) {
        store.edit {
            val current = it[HIDDEN] ?: emptySet()
            it[HIDDEN] = if (hidden) current + key else current - key
        }
    }

    suspend fun setPinned(keys: List<String>) {
        store.edit { it[PINNED] = keys.joinToString("\n") }
    }

    suspend fun addWidget(id: Int) {
        store.edit { it[WIDGETS] = (parseIds(it[WIDGETS]) + id).joinToString(",") }
    }

    suspend fun removeWidget(id: Int) {
        store.edit { it[WIDGETS] = (parseIds(it[WIDGETS]) - id).joinToString(",") }
    }

    companion object {
        private val THEME_MODE = stringPreferencesKey("theme_mode")
        private val HIDDEN = stringSetPreferencesKey("hidden_apps")
        private val PINNED = stringPreferencesKey("pinned_items")
        private val WIDGETS = stringPreferencesKey("widget_ids")

        private fun parseIds(raw: String?): List<Int> = raw?.split(',')?.mapNotNull { it.toIntOrNull() } ?: emptyList()

        fun get(context: Context): SuitePrefs = SuitePrefs(context.applicationContext.suiteDataStore)
    }
}
