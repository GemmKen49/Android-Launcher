package com.personal.suite.core.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode {
    System, Light, Dark;

    fun next(): ThemeMode = entries[(ordinal + 1) % entries.size]
}

private val Context.suiteDataStore by preferencesDataStore(name = "suite_prefs")

/** Shared settings for every app in the suite (one process, one DataStore). */
class SuitePrefs private constructor(private val store: DataStore<Preferences>) {

    val themeMode: Flow<ThemeMode> = store.data.map { prefs ->
        ThemeMode.entries.firstOrNull { it.name == prefs[THEME_MODE] } ?: ThemeMode.System
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        store.edit { it[THEME_MODE] = mode.name }
    }

    companion object {
        private val THEME_MODE = stringPreferencesKey("theme_mode")

        fun get(context: Context): SuitePrefs = SuitePrefs(context.applicationContext.suiteDataStore)
    }
}
