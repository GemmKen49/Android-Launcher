package com.personal.suite.core.apps

import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.net.Uri
import android.os.Process
import android.provider.Settings
import android.widget.Toast
import com.personal.suite.core.registry.AppEntry
import com.personal.suite.core.registry.launchApp

/** Anything the launcher (and later, search) can show and open: an installed app or a built-in app. */
sealed class LauncherItem {
    abstract val key: String
    abstract val label: String

    data class Installed(override val label: String, val component: ComponentName) : LauncherItem() {
        override val key: String get() = "app:${component.flattenToString()}"
    }

    data class Internal(override val label: String, val entry: AppEntry) : LauncherItem() {
        override val key: String get() = "internal:${entry.id}"
    }
}

fun Context.launchItem(item: LauncherItem) {
    try {
        when (item) {
            is LauncherItem.Installed ->
                getSystemService(LauncherApps::class.java)
                    .startMainActivity(item.component, Process.myUserHandle(), null, null)
            is LauncherItem.Internal -> launchApp(item.entry)
        }
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(this, "Can't open ${item.label}", Toast.LENGTH_SHORT).show()
    } catch (e: SecurityException) {
        Toast.makeText(this, "Can't open ${item.label}", Toast.LENGTH_SHORT).show()
    }
}

fun Context.openAppInfo(item: LauncherItem.Installed) {
    startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", item.component.packageName, null))
    )
}
