package com.personal.suite.core.prefs

import androidx.compose.runtime.compositionLocalOf

/** User-adjustable look of the suite. The defaults are the current design. Edited in Settings. */
data class Appearance(
    val dynamicColor: Boolean = true,
    // Home clock
    val clockMonospace: Boolean = true, // every digit sits in its own fixed-width cell, so no digit ever shifts its neighbour
    val clockSize: Float = 72f, // sp, hours and minutes
    val clockDigitWidth: Float = 0.62f, // cell width as a fraction of the font size
    val clockLineGap: Float = 4f, // dp between hours, minutes and seconds
    val clockSecondsScale: Float = 0.5f, // seconds size relative to hours and minutes
    val clockShowSeconds: Boolean = true,
    val clockShowDate: Boolean = true,
    val clockVerticalBias: Float = 0.2f, // -1 = top, 1 = bottom
    // Dock
    val dockIconSize: Float = 44f, // dp
    // Drawer
    val drawerColumns: Int = 2,
    val drawerIconSize: Float = 40f, // dp
    val cardOpacity: Float = 0.75f,
    val cardCornerRadius: Float = 16f, // dp
    val drawerScrim: Float = 0.45f,
    // Home widgets
    val widgetColumns: Int = 1, // 1..4; several widgets can share a row
    val widgetGap: Float = 12f, // dp
)

val LocalAppearance = compositionLocalOf { Appearance() }

/**
 * A widget on the home screen. [span] = columns it occupies (0 = the smallest the widget allows),
 * [heightDp] = 0 means the widget's own default height. Both are clamped to the widget's declared limits.
 */
data class WidgetPlacement(val id: Int, val span: Int = 0, val heightDp: Int = 0)

internal fun encodePlacements(list: List<WidgetPlacement>): String =
    list.joinToString(";") { "${it.id},${it.span},${it.heightDp}" }

internal fun decodePlacements(raw: String?): List<WidgetPlacement> =
    raw?.split(';')?.mapNotNull { part ->
        val fields = part.split(',')
        val id = fields.getOrNull(0)?.toIntOrNull() ?: return@mapNotNull null
        WidgetPlacement(id, fields.getOrNull(1)?.toIntOrNull() ?: 0, fields.getOrNull(2)?.toIntOrNull() ?: 0)
    } ?: emptyList()
