package com.personal.suite.core.prefs

import androidx.compose.runtime.compositionLocalOf

/** User-adjustable look of the suite. The defaults are the current design. Edited in launcher settings. */
data class Appearance(
    val dynamicColor: Boolean = true,
    // Home clock
    val clockMonospace: Boolean = true,
    val clockSize: Float = 72f, // sp, hours and minutes
    val clockLineSpacing: Float = 0.85f, // line height as a fraction of the font size
    val clockShowSeconds: Boolean = true,
    val clockShowDate: Boolean = true,
    val clockVerticalBias: Float = 0.2f, // -1 = top, 1 = bottom
    // Dock
    val dockIconSize: Float = 44f, // dp
    // Drawer
    val drawerColumns: Int = 2,
    val drawerIconSize: Float = 40f, // dp
    val cardOpacity: Float = 0.75f,
    val cardCornerRadius: Float = 16f, // dp
    val drawerScrim: Float = 0.45f,
)

val LocalAppearance = compositionLocalOf { Appearance() }
