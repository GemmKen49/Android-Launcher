package com.personal.suite.core.storage

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/** The File Manager and the Gallery read storage directly, which needs "All files access" (Android 11+). */
fun canManageAllFiles(): Boolean =
    Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()

fun supportsAllFilesAccess(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

fun Context.requestAllFilesAccess() {
    try {
        startActivity(
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
        )
    } catch (e: ActivityNotFoundException) {
        startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
    }
}

/** Shown by an app until the user has granted the access. [appName] is for the wording only. */
@Composable
fun AllFilesAccessScreen(appName: String, onRequestAccess: () -> Unit) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("All files access needed", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.size(12.dp))
            if (supportsAllFilesAccess()) {
                Text(
                    "$appName reads your storage directly. Allow \"All files access\" for this app in system settings, then come back.",
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.size(24.dp))
                Button(onClick = onRequestAccess) { Text("Open settings") }
            } else {
                Text("$appName needs Android 11 or newer.", textAlign = TextAlign.Center)
            }
        }
    }
}
