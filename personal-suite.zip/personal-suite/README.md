# personal-suite

Personal Android launcher and built-in app suite. One APK; each built-in app is its own Activity
with its own task affinity, so it shows up separately in Recents.

## Modules

| Module | Role |
| --- | --- |
| `:app` | Manifest, launcher (HOME) and settings Activities, app registration |
| `:core` | Theme, shared prefs (DataStore), app registry, installed-app catalog, search (providers, engine), tabs/split-view framework, appearance settings |
| `:feature:*` | One module per built-in app; each declares its own Activity and `AppEntry` |

`minSdk 29`, `targetSdk 36`. Kotlin, Jetpack Compose, Material 3.

## Build

Open in Android Studio and sync. To generate the Gradle wrapper (jar and scripts), run the `wrapper`
task from the Gradle tool window (Tasks > build setup) and commit the result.

## Adding a built-in app

1. Create `:feature:<name>` with an Activity (own `taskAffinity` in its manifest) and an `AppEntry`.
2. Add the module to `settings.gradle.kts` and `:app`'s dependencies.
3. Add its entry to the list in `SuiteApplication`.
